<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$rivimaara = 0;
	$rivimaara_yhteensa = "";

	if(!tarkista_parametri("aihe",true,"numero")
	|| !tarkista_parametri("sisalto",true,"teksti")
	|| !tarkista_parametri("lahettaja",true,"teksti")
	|| !tarkista_parametri("alkupvm",true,"pvm")
	|| !tarkista_parametri("loppupvm",true,"pvm")
	|| !tarkista_parametri("kuitattu",true,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$aiheWhere = "";
	$sisaltoWhere = "";
	$lahettajaWhere = "";
	$alkupvmWhere = "";
	$loppupvmWhere = "";
	$kuitattuWhere = "";
	
	if($_POST["aihe"] != "") {
		$aiheWhere = " AND aihe = '" . $_POST['aihe'] . "'";
	}
	
	if($_POST["sisalto"] != "") {
		$sisaltoWhere = " AND sisalto LIKE '%" . $_POST["sisalto"]  . "%'";
	}
	
	if($_POST["lahettaja"] != "") {
		$lahettajaWhere = " AND lahettaja LIKE '%" . $_POST["lahettaja"]  . "%'";
	}
	
	if($_POST["alkupvm"] != "") {
		$alkupvmWhere = " AND DATE(aikaleima) >= '" . kaanna_fi_pvm($_POST["alkupvm"]) . "'";
	}
	
	if($_POST["loppupvm"] != "") {
		$loppupvmWhere = " AND DATE(aikaleima) <= '" . kaanna_fi_pvm($_POST["loppupvm"]) . "'";
	}

	if($_POST["kuitattu"] != "") {
		if($_POST['kuitattu'] == "1") {
			$kuitattuWhere = " AND kuitattu IS NOT NULL";
		}
		else if($_POST['kuitattu'] == "0") {
			$kuitattuWhere = " AND kuitattu IS NULL";
		}
	}
	
	if($aiheWhere != "" || $sisaltoWhere != "" || $lahettajaWhere != "" || $alkupvmWhere != "" || $loppupvmWhere != "" || $kuitattuWhere != "") {
		$sql = "SELECT COUNT(viesti_id) AS lukumaara FROM viesti";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$rivimaara_yhteensa = $rivi["lukumaara"];
		}
	}
	
	$sql = "SELECT viesti_id, aihe, sisalto, lahettaja, aikaleima, kuitattu FROM viesti" . preg_replace("/AND/","WHERE", $aiheWhere . $sisaltoWhere . $lahettajaWhere . $alkupvmWhere . $loppupvmWhere . $kuitattuWhere,1) . " ORDER BY aikaleima DESC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$viesti_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	for($i = 0; $i < sizeOf($viesti_tiedot); $i++)
	{
		$rivi_tieto["viesti_id"] = $viesti_tiedot[$i]["viesti_id"];
		$rivi_tieto["aihe"] = $viesti_tiedot[$i]["aihe"];
		$rivi_tieto["sisalto"] = $viesti_tiedot[$i]["sisalto"];
		$rivi_tieto["lahettaja"] = $viesti_tiedot[$i]["lahettaja"];
		$rivi_tieto["aikaleima"] = palauta_aikaleima_fi($viesti_tiedot[$i]["aikaleima"]);
		if($viesti_tiedot[$i]["kuitattu"] != null) {
			$rivi_tieto["kuitattu"] = palauta_aikaleima_fi($viesti_tiedot[$i]["kuitattu"]);
		}
		else {
			$rivi_tieto["kuitattu"] = "";
		}
		$rivimaara++;
		
		array_push($rivi_tiedot,$rivi_tieto);
	}

	if($rivimaara_yhteensa == "") {
		$rivimaara_yhteensa = $rivimaara;
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	$tiedot["lukumaarat"]["rivimaara_yhteensa"] = $rivimaara_yhteensa;
	$tiedot["lukumaarat"]["rivimaara"] = $rivimaara;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>