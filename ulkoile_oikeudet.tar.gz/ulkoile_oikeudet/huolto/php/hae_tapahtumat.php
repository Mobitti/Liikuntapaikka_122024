<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$rivimaara = 0;
	$rivimaara_yhteensa = "";

	if(!tarkista_parametri("tyyppi",true,"numero")
	|| !tarkista_parametri("kohde_id",true,"id")
	|| !tarkista_parametri("kuvaus",true,"teksti")
	|| !tarkista_parametri("alkupvm",true,"pvm")
	|| !tarkista_parametri("loppupvm",true,"pvm")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$tyyppiWhere = "";
	$kohdeWhere = "";
	$kuvausWhere = "";
	$alkupvmWhere = "";
	$loppupvmWhere = "";
	
	if($_POST["tyyppi"] != "") {
		$tyyppiWhere = " AND tyyppi = '" . $_POST['tyyppi'] . "'";
	}
	
	if($_POST["kohde_id"] != "") {
		$kohdeWhere = " AND kohde_id = '" . $_POST['kohde_id'] . "'";
	}
	
	if($_POST["kuvaus"] != "") {
		$kuvausWhere = " AND kuvaus LIKE '%" . $_POST["kuvaus"]  . "%'";
	}
	
	if($_POST["alkupvm"] != "") {
		$alkupvmWhere = " AND DATE(aikaleima) >= '" . kaanna_fi_pvm($_POST["alkupvm"]) . "'";
	}
	
	if($_POST["loppupvm"] != "") {
		$loppupvmWhere = " AND DATE(aikaleima) <= '" . kaanna_fi_pvm($_POST["loppupvm"]) . "'";
	}

	
	if($tyyppiWhere != "" || $kohdeWhere != "" || $kuvausWhere != "" || $alkupvmWhere != "" || $loppupvmWhere != "") {
		$sql = "SELECT COUNT(tapahtuma_id) AS lukumaara FROM tapahtuma";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$rivimaara_yhteensa = $rivi["lukumaara"];
		}
	}
	
//	$sql = "SELECT tapahtuma_id, tyyppi, kohde_id, (SELECT nimi FROM kohde WHERE kohde.kohde_id = tapahtuma.kohde_id) AS kohde_nimi, kuvaus, aikaleima FROM tapahtuma WHERE tapahtuma.aikaleima <= DATE_SUB(NOW(), INTERVAL 1) ORDER BY aikaleima DESC";
	$sql = "SELECT tapahtuma_id, tyyppi, kohde_id, (SELECT nimi FROM kohde WHERE kohde.kohde_id = tapahtuma.kohde_id) AS kohde_nimi, kuvaus, aikaleima FROM tapahtuma";
	//. preg_replace("/AND/","WHERE", $tyyppiWhere . $kohdeWhere . $kuvausWhere,1) . " AND tapahtuma.aikaleima <= DATE_SUB(NOW(), INTERVAL 1) ORDER BY aikaleima DESC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$tapahtuma_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	for($i = 0; $i < sizeOf($tapahtuma_tiedot); $i++)
	{
		$rivi_tieto["tapahtuma_id"] = $tapahtuma_tiedot[$i]["tapahtuma_id"];
		$rivi_tieto["tyyppi"] = $tapahtuma_tiedot[$i]["tyyppi"];
		$rivi_tieto["kohde_id"] = $tapahtuma_tiedot[$i]["kohde_id"];
		$rivi_tieto["kohde_nimi"] = $tapahtuma_tiedot[$i]["kohde_nimi"];
		$rivi_tieto["kuvaus"] = $tapahtuma_tiedot[$i]["kuvaus"];
		$rivi_tieto["aikaleima"] = palauta_aikaleima_fi($tapahtuma_tiedot[$i]["aikaleima"]);
		$rivimaara++;
		
		array_push($rivi_tiedot,$rivi_tieto);
	}

	if($rivimaara_yhteensa == "") {
		$rivimaara_yhteensa = $rivimaara;
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	$tiedot["lukumaarat"]["rivimaara_yhteensa"] = $rivimaara_yhteensa;
	$tiedot["lukumaarat"]["rivimaara"] = $rivimaara;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>