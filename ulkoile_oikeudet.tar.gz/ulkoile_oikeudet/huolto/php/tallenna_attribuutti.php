<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$jarjestysluku = 1;

	if(!tarkista_parametri("attribuutti_id",true,"id")
	|| !tarkista_parametri("nimi",false,"teksti")
	|| !tarkista_parametri("kuvaus",false,"teksti")
	|| !tarkista_parametri("tyyppi",false,"id")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["attribuutti_id"] == "") {
		$sql = "SELECT attribuutti_id FROM attribuutti WHERE nimi = :nimi AND kuvaus = :kuvaus AND tyyppi = :tyyppi";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":kuvaus", $_POST["kuvaus"]);
		$arvot->bindParam(":tyyppi", $_POST["tyyppi"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Attribuutti on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "SELECT COUNT(*) AS lkm FROM attribuutti";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$jarjestysluku = $rivi['lkm'] + 1;
		}
		
		$sql = "INSERT INTO attribuutti (attribuutti_id, nimi, kuvaus, tyyppi, jarjestysluku) VALUES (NULL, :nimi, :kuvaus, :tyyppi, :jarjestysluku)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":kuvaus", $_POST["kuvaus"]);
		$arvot->bindParam(":tyyppi", $_POST["tyyppi"]);
		$arvot->bindParam(":jarjestysluku", $jarjestysluku);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Attribuutti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}
	else {
		$sql = "SELECT attribuutti_id FROM attribuutti WHERE nimi = :nimi AND kuvaus = :kuvaus AND tyyppi = :tyyppi AND attribuutti_id != :attribuutti_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":kuvaus", $_POST["kuvaus"]);
		$arvot->bindParam(":tyyppi", $_POST["tyyppi"]);
		$arvot->bindParam(":attribuutti_id", $_POST["attribuutti_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Attribuutti on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "UPDATE attribuutti SET nimi = :nimi, kuvaus = :kuvaus, tyyppi = :tyyppi WHERE attribuutti_id = :attribuutti_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":kuvaus", $_POST["kuvaus"]);
		$arvot->bindParam(":tyyppi", $_POST["tyyppi"]);
		$arvot->bindParam(":attribuutti_id", $_POST["attribuutti_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Attribuutti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>