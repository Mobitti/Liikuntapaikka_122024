<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("aineistotunnus",false,"teksti")
	|| !tarkista_parametri("koordinaatit",true,"teksti")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["aineistotunnus"] != "") {
		$sql = "DELETE FROM aineisto WHERE aineistotunnus = :aineistotunnus";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->execute();
		
		$jarjestysluku = 1;
		
		if($_POST["koordinaatit"] != "") {
			for($i = 0; $i < sizeOf($_POST["koordinaatit"]); $i++)
			{
				$leveysaste = $_POST["koordinaatit"][$i][1];
				$pituusaste = $_POST["koordinaatit"][$i][0];

				$sql = "INSERT INTO aineisto (aineisto_id, jarjestysluku, leveysaste, pituusaste, aineistotunnus) VALUES (NULL, :jarjestysluku, :leveysaste, :pituusaste, :aineistotunnus)";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":jarjestysluku", $jarjestysluku);
				$arvot->bindParam(":leveysaste", $leveysaste);
				$arvot->bindParam(":pituusaste", $pituusaste);
				$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
				$arvot->execute();
				$jarjestysluku++;
			}
			
			$rivi_tieto["nimi"] = "Aineisto";
			$rivi_tieto["kpl"] = $jarjestysluku - 1;
			array_push($rivi_tiedot,$rivi_tieto);
		}
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>