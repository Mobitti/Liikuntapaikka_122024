<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("aineisto_id",true,"id")
	|| !tarkista_parametri("jarjestysluku",false,"numero")
	|| !tarkista_parametri("leveysaste",false,"teksti")
	|| !tarkista_parametri("pituusaste",false,"teksti")
	|| !tarkista_parametri("aineistotunnus",false,"teksti")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["aineisto_id"] == "") {
		$sql = "SELECT aineisto_id FROM aineisto WHERE jarjestysluku = :jarjestysluku AND aineistotunnus = :aineistotunnus";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":jarjestysluku", $_POST["jarjestysluku"]);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Aineisto annetulla järjestysluvulla on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "INSERT INTO aineisto (aineisto_id, jarjestysluku, leveysaste, pituusaste, aineistotunnus) VALUES (NULL, :jarjestysluku, :leveysaste, :pituusaste, :aineistotunnus)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":jarjestysluku", $_POST["jarjestysluku"]);
		$arvot->bindParam(":leveysaste", $_POST["leveysaste"]);
		$arvot->bindParam(":pituusaste", $_POST["pituusaste"]);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Aineisto";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}
	else {
		$sql = "SELECT aineisto_id FROM aineisto WHERE jarjestysluku = :jarjestysluku AND aineistotunnus = :aineistotunnus AND aineisto_id != :aineisto_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":jarjestysluku", $_POST["jarjestysluku"]);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->bindParam(":aineisto_id", $_POST["aineisto_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Aineisto annetulla järjestysluvulla on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "UPDATE aineisto SET jarjestysluku = :jarjestysluku, leveysaste = :leveysaste, pituusaste = :pituusaste, aineistotunnus = :aineistotunnus WHERE aineisto_id = :aineisto_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":jarjestysluku", $_POST["jarjestysluku"]);
		$arvot->bindParam(":leveysaste", $_POST["leveysaste"]);
		$arvot->bindParam(":pituusaste", $_POST["pituusaste"]);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->bindParam(":aineisto_id", $_POST["aineisto_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Aineisto";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>