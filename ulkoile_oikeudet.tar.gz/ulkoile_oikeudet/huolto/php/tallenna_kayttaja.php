<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$salasanaPaivitys = "";

	if(!tarkista_parametri("kayttaja_id",true,"id")
	|| !tarkista_parametri("nimi",false,"teksti")
	|| !tarkista_parametri("puhelin",true,"puhelin")
	|| !tarkista_parametri("sahkoposti",true,"sahkoposti")
	|| !tarkista_parametri("tunnus",false,"teksti")
	|| !tarkista_parametri("salasana",true,"teksti")
	|| !tarkista_parametri("ryhma",true,"teksti")
	|| !tarkista_parametri("oikeudet",true,"teksti")
	|| !tarkista_parametri("kohteet",true,"teksti")
	|| !tarkista_parametri("aktiivinen",false,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["kayttaja_id"] == "") {
		$sql = "SELECT kayttaja_id FROM kayttaja WHERE nimi = :nimi";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Käyttäjä on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "INSERT INTO kayttaja (kayttaja_id, nimi, puhelin, sahkoposti, tunnus, salasana, ryhma, aktiivinen) 
				VALUES (NULL, :nimi, :puhelin, :sahkoposti, :tunnus, SHA2(:salasana,512), :ryhma, :aktiivinen)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":puhelin", $_POST["puhelin"]);
		$arvot->bindParam(":sahkoposti", $_POST["sahkoposti"]);
		$arvot->bindParam(":tunnus", $_POST["tunnus"]);
		$arvot->bindParam(":salasana", $_POST["salasana"]);
		$arvot->bindParam(":ryhma", $_POST["ryhma"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->execute();
		$kayttaja_id = $yhteys->lastInsertId();
		
		$rivi_tieto["nimi"] = "Käyttäjä";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		if($kayttaja_id != "") {
			for($i = 0; $i < sizeOf($_POST["oikeudet"]); $i++)
			{
				$oikeus_id = $_POST["oikeudet"][$i];
				
				if($oikeus_id != "") {
					$sql = "INSERT INTO kayttaja_oikeus (kayttaja_oikeus_id, kayttaja_id, oikeus_id) VALUES (NULL, :kayttaja_id, :oikeus_id)";
					$arvot = $yhteys->prepare($sql);
					$arvot->bindParam(":kayttaja_id", $kayttaja_id);
					$arvot->bindParam(":oikeus_id", $oikeus_id);
					$arvot->execute();
					$rivi_tieto["nimi"] = "Käyttäjä_Oikeus";
					$rivi_tieto["kpl"] = $arvot->rowCount();
					array_push($rivi_tiedot,$rivi_tieto);
				}
			}
			
			for($i = 0; $i < sizeOf($_POST["kohteet"]); $i++)
			{
				$kohde_id = $_POST["kohteet"][$i];
				
				if($kohde_id != "") {
					$sql = "INSERT INTO kayttaja_kohde (kayttaja_kohde_id, kayttaja_id, kohde_id) VALUES (NULL, :kayttaja_id, :kohde_id)";
					$arvot = $yhteys->prepare($sql);
					$arvot->bindParam(":kayttaja_id", $kayttaja_id);
					$arvot->bindParam(":kohde_id", $kohde_id);
					$arvot->execute();
					$rivi_tieto["nimi"] = "Käyttäjä_Kohde";
					$rivi_tieto["kpl"] = $arvot->rowCount();
					array_push($rivi_tiedot,$rivi_tieto);
				}
			}
		}
	}
	else {
		$sql = "SELECT kayttaja_id FROM kayttaja WHERE nimi = :nimi AND kayttaja_id != :kayttaja_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":kayttaja_id", $_POST["kayttaja_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Käyttäjä on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		if($_POST["salasana"] != "") {
			$salasanaPaivitys = ", salasana = SHA2('" . $_POST["salasana"] . "',512)";
		} 
		
		$sql = "UPDATE kayttaja SET nimi = :nimi, puhelin = :puhelin, sahkoposti = :sahkoposti, tunnus = :tunnus" . $salasanaPaivitys . ", ryhma = :ryhma, aktiivinen = :aktiivinen WHERE kayttaja_id = :kayttaja_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":puhelin", $_POST["puhelin"]);
		$arvot->bindParam(":sahkoposti", $_POST["sahkoposti"]);
		$arvot->bindParam(":tunnus", $_POST["tunnus"]);
		$arvot->bindParam(":ryhma", $_POST["ryhma"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->bindParam(":kayttaja_id", $_POST["kayttaja_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Käyttäjä";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM kayttaja_oikeus WHERE kayttaja_id = :kayttaja_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kayttaja_id", $_POST["kayttaja_id"]);
		$arvot->execute();
		
		for($i = 0; $i < sizeOf($_POST["oikeudet"]); $i++)
		{
			$oikeus_id = $_POST["oikeudet"][$i];
			
			if($oikeus_id != "") {
				$sql = "INSERT INTO kayttaja_oikeus (kayttaja_oikeus_id, kayttaja_id, oikeus_id) VALUES (NULL, :kayttaja_id, :oikeus_id)";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":kayttaja_id", $_POST["kayttaja_id"]);
				$arvot->bindParam(":oikeus_id", $oikeus_id);
				$arvot->execute();
				$rivi_tieto["nimi"] = "Käyttäjä Oikeus";
				$rivi_tieto["kpl"] = $arvot->rowCount();
				array_push($rivi_tiedot,$rivi_tieto);
			}
		}
		
		$sql = "DELETE FROM kayttaja_kohde WHERE kayttaja_id = :kayttaja_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kayttaja_id", $_POST["kayttaja_id"]);
		$arvot->execute();
		
		for($i = 0; $i < sizeOf($_POST["kohteet"]); $i++)
		{
			$kohde_id = $_POST["kohteet"][$i];
			
			if($kohde_id != "") {
				$sql = "INSERT INTO kayttaja_kohde (kayttaja_kohde_id, kayttaja_id, kohde_id) VALUES (NULL, :kayttaja_id, :kohde_id)";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":kayttaja_id", $_POST["kayttaja_id"]);
				$arvot->bindParam(":kohde_id", $kohde_id);
				$arvot->execute();
				$rivi_tieto["nimi"] = "Käyttäjä Kohde";
				$rivi_tieto["kpl"] = $arvot->rowCount();
				array_push($rivi_tiedot,$rivi_tieto);
			}
		}
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>