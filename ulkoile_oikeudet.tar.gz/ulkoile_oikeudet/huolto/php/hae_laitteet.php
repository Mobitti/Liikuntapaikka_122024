<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$rivimaara = 0;
	$rivimaara_yhteensa = "";

	if(!tarkista_parametri("laitetunnus",true,"teksti")
	|| !tarkista_parametri("kuvaus",true,"teksti")
	|| !tarkista_parametri("attribuutit",true,"teksti")
	|| !tarkista_parametri("aktiivinen",true,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$laitetunnusWhere = "";
	$kuvausWhere = "";
	$laiteattribuuttiWhere = "";
	$attribuuttiWhere = "";
	$aktiivinenWhere = "";
	
	if($_POST["laitetunnus"] != "") {
		$laitetunnusWhere = " AND laitetunnus LIKE '%" . $_POST["laitetunnus"]  . "%'";
	}
	
	if($_POST["kuvaus"] != "") {
		$kuvausWhere = " AND kuvaus LIKE '%" . $_POST["kuvaus"]  . "%'";
	}
	
	if($_POST["attribuutit"] != "") {
		for($i = 0; $i < sizeOf($_POST["attribuutit"]); $i++)
		{
			$kohde_id = $_POST["attribuutit"][$i]["tieto1"];
			$attribuutti_id = $_POST["attribuutit"][$i]["tieto2"];
			$paivitysvali = $_POST["attribuutit"][$i]["tieto2"];
			
			if($kohde_id != "") {
				$laiteattribuuttiWhere .= " AND kohde_id = '". $kohde_id . "'";
			}
			
			if($attribuutti_id != "") {
				$laiteattribuuttiWhere .= " AND attribuutti_id = '". $attribuutti_id . "'";
			}
			
			if($paivitysvali != "") {
				$laiteattribuuttiWhere .= " AND paivitysvali = '" . $paivitysvali . "'";
			}

			if($laiteattribuuttiWhere != "") {
				$attribuuttiWhere = " AND laite_id IN(SELECT laite_id FROM laite_kohde_attribuutti" . preg_replace("/AND/","WHERE",$laiteattribuuttiWhere,1) . ")";
			}
		}
	}
	
	if($_POST["aktiivinen"] != "") {
		$aktiivinenWhere = " AND aktiivinen = '" . $_POST["aktiivinen"]  . "'";
	}
	
	if($laitetunnusWhere != "" || $kuvausWhere != "" || $attribuuttiWhere != "" || $aktiivinenWhere != "") {
		$sql = "SELECT COUNT(laite_id) AS lukumaara FROM laite";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$rivimaara_yhteensa = $rivi["lukumaara"];
		}
	}
	
	$sql = "SELECT laite_id, laitetunnus, kuvaus, aktiivinen FROM laite" . preg_replace("/AND/","WHERE", $laitetunnusWhere . $kuvausWhere . $attribuuttiWhere . $aktiivinenWhere,1) . " ORDER BY laitetunnus ASC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$laite_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	for($i = 0; $i < sizeOf($laite_tiedot); $i++)
	{
		$sql = "SELECT laite_kohde_attribuutti_id, kohde_id, (SELECT nimi FROM kohde WHERE kohde.kohde_id = laite_kohde_attribuutti.kohde_id) AS kohde_nimi,
				attribuutti_id, (SELECT nimi FROM attribuutti WHERE attribuutti.attribuutti_id = laite_kohde_attribuutti.attribuutti_id) AS attribuuttti_nimi, 
				paivitysvali FROM laite_kohde_attribuutti WHERE laite_id = :laite_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":laite_id", $laite_tiedot[$i]["laite_id"]);
		$arvot->execute();
		$laite_kohde_attribuutit = $arvot->fetchAll(PDO::FETCH_ASSOC);
		
		$rivi_tieto["laite_id"] = $laite_tiedot[$i]["laite_id"];
		$rivi_tieto["laitetunnus"] = $laite_tiedot[$i]["laitetunnus"];
		$rivi_tieto["kuvaus"] = $laite_tiedot[$i]["kuvaus"];
		$rivi_tieto["attribuutit"] = $laite_kohde_attribuutit;
		$rivi_tieto["aktiivinen"] = $laite_tiedot[$i]["aktiivinen"];
		$rivimaara++;
		
		array_push($rivi_tiedot,$rivi_tieto);
	}

	if($rivimaara_yhteensa == "") {
		$rivimaara_yhteensa = $rivimaara;
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	$tiedot["lukumaarat"]["rivimaara_yhteensa"] = $rivimaara_yhteensa;
	$tiedot["lukumaarat"]["rivimaara"] = $rivimaara;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>