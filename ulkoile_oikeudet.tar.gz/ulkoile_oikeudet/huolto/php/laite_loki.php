<?php
require_once "config.php";

try
{
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$aikaleima =  date("Y-m-d H:i:s");
	$laite = "Testilaite";
	$postData = file_get_contents("php://input");

	$sql = "INSERT INTO laite_loki (id, aikaleima, laite, arvot) VALUES (NULL, :aikaleima, :laite, :arvot)";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":aikaleima", $aikaleima);
	$arvot->bindParam(":laite", $laite);
	$arvot->bindParam(":arvot", $postData);
	$arvot->execute();
	
	$yhteys = null; 
	$arvot = null;
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
}
?>