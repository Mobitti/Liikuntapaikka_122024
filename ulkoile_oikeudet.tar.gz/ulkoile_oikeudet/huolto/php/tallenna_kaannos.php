<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("kaannos_id",true,"id")
	|| !tarkista_parametri("kieli",false,"teksti")
	|| !tarkista_parametri("tyyppi",false,"teksti")
	|| !tarkista_parametri("kaannoskohde",false,"teksti")
	|| !tarkista_parametri("teksti",false,"teksti")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["kaannos_id"] == "") {
		$sql = "INSERT INTO kaannos (kaannos_id, kieli, tyyppi, kaannoskohde, teksti) VALUES (NULL, :kieli, :tyyppi, :kaannoskohde, :teksti)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kieli", $_POST["kieli"]);
		$arvot->bindParam(":tyyppi", $_POST["tyyppi"]);
		$arvot->bindParam(":kaannoskohde", $_POST["kaannoskohde"]);
		$arvot->bindParam(":teksti", $_POST["teksti"]);
		$arvot->execute();
		$huoltoviesti_id = $yhteys->lastInsertId();
		
		$rivi_tieto["nimi"] = "Käännös";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}
	else {
		$sql = "UPDATE kaannos SET kieli = :kieli, tyyppi = :tyyppi, kaannoskohde = :kaannoskohde, teksti = :teksti WHERE kaannos_id = :kaannos_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kieli", $_POST["kieli"]);
		$arvot->bindParam(":tyyppi", $_POST["tyyppi"]);
		$arvot->bindParam(":kaannoskohde", $_POST["kaannoskohde"]);
		$arvot->bindParam(":teksti", $_POST["teksti"]);
		$arvot->bindParam(":kaannos_id", $_POST["kaannos_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Käännös";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>