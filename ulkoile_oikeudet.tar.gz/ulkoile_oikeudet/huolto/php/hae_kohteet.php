<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$rivimaara = 0;
	$rivimaara_yhteensa = "";

	if(!tarkista_parametri("kategoria_id",true,"id")
	|| !tarkista_parametri("nimi",true,"teksti")
	|| !tarkista_parametri("kuvaus",true,"teksti")
	|| !tarkista_parametri("attribuutit",true,"teksti")
	|| !tarkista_parametri("tila_id",true,"id")
	|| !tarkista_parametri("aineistotunnus",true,"teksti")
	|| !tarkista_parametri("aktiivinen",true,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$kategoriaWhere = "";
	$nimiWhere = "";
	$kuvausWhere = "";
	$attribuutitWhere = "";
	$tilaWhere = "";
	$aineistotunnusWhere = "";
	$aktiivinenWhere = "";
	
	if($_POST["kategoria_id"] != "") {
		$kategoriaWhere = " AND kategoria_id = '" . $_POST["kategoria_id"]  . "'";
	}
	
	if($_POST["nimi"] != "") {
		$nimiWhere = " AND nimi LIKE '%" . $_POST["nimi"]  . "%'";
	}
	
	if($_POST["kuvaus"] != "") {
		$kuvausWhere = " AND kuvaus LIKE '%" . $_POST["kuvaus"]  . "%'";
	}
	
	if($_POST["attribuutit"] != "") {
		$attribuutitWhere = " AND kohde_id IN(SELECT kohde_id FROM kohde_attribuutti WHERE attribuutti_id IN(" . $_POST["attribuutit"] . "))";
	}
	
	if($_POST["tila_id"] != "") {
		$tilaWhere = " AND tila_id = '" . $_POST["tila_id"] . "'";
	}
	
	if($_POST["aineistotunnus"] != "") {
		$aineistotunnusWhere = " AND aineistotunnus LIKE '%" . $_POST["aineistotunnus"]  . "%'";
	}
	
	if($_POST["aktiivinen"] != "") {
		$aktiivinenWhere = " AND aktiivinen = '" . $_POST["aktiivinen"] . "'";
	}
	
	if($kategoriaWhere != "" || $nimiWhere != "" || $kuvausWhere != "" || $attribuutitWhere != "" || $tilaWhere != "" || $aineistotunnusWhere != "" || $aktiivinenWhere != "") {
		$sql = "SELECT COUNT(kohde_id) AS lukumaara FROM kohde";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$rivimaara_yhteensa = $rivi["lukumaara"];
		}
	}
	
	$sql = "SELECT kohde_id, kategoria_id, jarjestysluku, nimi, kuvaus, tila_id, aineistotunnus, aktiivinen FROM kohde" . preg_replace("/AND/","WHERE", $kategoriaWhere . $nimiWhere . $kuvausWhere . $attribuutitWhere . $tilaWhere . $aineistotunnusWhere . $aktiivinenWhere,1) . " ORDER BY (SELECT jarjestysluku FROM kategoria WHERE kategoria.kategoria_id = kohde.kategoria_id) ASC, jarjestysluku ASC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$kohde_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	for($i = 0; $i < sizeOf($kohde_tiedot); $i++)
	{
		$sql = "SELECT kohde_attribuutti_id, attribuutti_id, (SELECT nimi FROM attribuutti WHERE attribuutti.attribuutti_id = kohde_attribuutti.attribuutti_id) AS nimi, arvo FROM kohde_attribuutti WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $kohde_tiedot[$i]["kohde_id"]);
		$arvot->execute();
		$kohde_attribuutit = $arvot->fetchAll(PDO::FETCH_ASSOC);
		
		$rivi_tieto["kohde_id"] = $kohde_tiedot[$i]["kohde_id"];
		$rivi_tieto["kategoria_id"] = $kohde_tiedot[$i]["kategoria_id"];
		$rivi_tieto["jarjestysluku"] = $kohde_tiedot[$i]["jarjestysluku"];
		$rivi_tieto["nimi"] = $kohde_tiedot[$i]["nimi"];
		$rivi_tieto["kuvaus"] = $kohde_tiedot[$i]["kuvaus"];
		$rivi_tieto["attribuutit"] = $kohde_attribuutit;
		$rivi_tieto["tila_id"] = $kohde_tiedot[$i]["tila_id"];
		$rivi_tieto["aineistotunnus"] = $kohde_tiedot[$i]["aineistotunnus"];
		$rivi_tieto["aktiivinen"] = $kohde_tiedot[$i]["aktiivinen"];
		$rivimaara++;
		
		array_push($rivi_tiedot,$rivi_tieto);
	}

	if($rivimaara_yhteensa == "") {
		$rivimaara_yhteensa = $rivimaara;
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	$tiedot["lukumaarat"]["rivimaara_yhteensa"] = $rivimaara_yhteensa;
	$tiedot["lukumaarat"]["rivimaara"] = $rivimaara;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>