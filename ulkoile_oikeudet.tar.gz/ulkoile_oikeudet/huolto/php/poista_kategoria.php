<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("kategoria_id",false,"id") 
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$sql = "SELECT COUNT(kohde_id) AS lukumaara FROM kohde WHERE kategoria_id = :kategoria_id";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
	$arvot->execute();
	$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
	if($rivi != null) {
		if($rivi["lukumaara"] > 0) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Poisto epäonnistui. Poista ensin kategorian kohteet";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			$yhteys = null; 
			$arvot = null;
			return;
		}
	}
	
	if($_POST["kategoria_id"] != ""){
		$kategoria_jarjestysluku = "";
		$sql = "SELECT jarjestysluku, taso_id FROM kategoria WHERE kategoria_id = :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			if($rivi["taso_id"] != 0) {
				$tila_tieto["virhe"] = 1;
				$tila_tieto["viesti"] = "Poisto epäonnistui. Poista kategorian taso merkintä";
				$tiedot["tila"] = $tila_tieto;
				echo json_encode($tiedot);
				$yhteys = null; 
				$arvot = null;
				return;
			}
			$kategoria_jarjestysluku = $rivi["jarjestysluku"];
		}

		$sql = "DELETE FROM kategoria_tila WHERE kategoria_id = :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
		$arvot->execute();
		$rivi_tieto["nimi"] = "Kategoria_Tila";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		
		$sql = "DELETE FROM kategoria WHERE kategoria_id = :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
		$arvot->execute();
		$rivi_tieto["nimi"] = "Kategoria";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);

		if($kategoria_jarjestysluku != "") {
			$sql = "SELECT kategoria_id, jarjestysluku FROM kategoria WHERE jarjestysluku > :jarjestysluku";
			$arvot = $yhteys->prepare($sql);
			$arvot->bindParam(":jarjestysluku", $kategoria_jarjestysluku);
			$arvot->execute();
			$kategoria_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);

			for($i = 0; $i < sizeOf($kategoria_tiedot); $i++)
			{
				$kasiteltava_kategoria_jarjestysluku = $kategoria_tiedot[$i]["jarjestysluku"] - 1;
				$sql = "UPDATE kategoria SET jarjestysluku = :jarjestysluku WHERE kategoria_id = :kategoria_id";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":kategoria_id", $kategoria_tiedot[$i]["kategoria_id"]);
				$arvot->bindParam(":jarjestysluku", $kasiteltava_kategoria_jarjestysluku);
				$arvot->execute();
			}
		}
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "Poisto onnistui";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>