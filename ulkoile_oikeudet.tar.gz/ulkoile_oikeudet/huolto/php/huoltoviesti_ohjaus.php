<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$aikaleima =  date("Y-m-d H:i:s");
	$sms_tiedot = $_POST;
	$sms_viesti_id = $sms_tiedot["message_sid"];
	$sms_tili_id = $sms_tiedot["account_sid"];
	$sms_lahettaja = $sms_tiedot["from"];
	$sms_kenelle = $sms_tiedot["to"];
	$sms_teksti = $sms_tiedot["text"];
	$sms_tila = $sms_tiedot["status"];
	
	$onnistui = false;
	$palautus_viesti = "";
	
	if(sizeOf($sms_tiedot) <= 0) {
		exit;
	}
	
	if($sms_kenelle == $sms_lahettaja) {
		exit;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$sql = "INSERT INTO sms_loki (id, viesti_id, aikaleima, lahettaja, sisalto, tila) VALUES (NULL, :viesti_id, :aikaleima, :lahettaja, :sisalto, :tila)";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":viesti_id", $sms_viesti_id);
	$arvot->bindParam(":aikaleima", $aikaleima);
	$arvot->bindParam(":lahettaja", $sms_lahettaja);
	$arvot->bindParam(":sisalto", $sms_teksti);
	$arvot->bindParam(":tila", $sms_tila);
	$arvot->execute();
	
	$puhelin = "0" . substr($sms_lahettaja,3);
	$sql = "SELECT aktiivinen, (SELECT kayttaja_oikeus_id FROM kayttaja_oikeus WHERE kayttaja_oikeus.kayttaja_id = kayttaja.kayttaja_id AND oikeus_id = 6) AS sms_oikeus FROM kayttaja WHERE puhelin = :puhelin";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":puhelin", $puhelin);
	$arvot->execute();
	$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
	if($rivi == null) {
		$palautus_viesti = "Käyttäjää ei löytynyt.";
		laheta_viesti($sms_lahettaja,$palautus_viesti);
		$yhteys = null; 
		$arvot = null;
		exit;
	}
	else {
		if($rivi["aktiivinen"] == 0) {
			$palautus_viesti = "Tunnuksesi ei ole aktiivinen, ota yhteys järjestelmänylläpitoon.";
			laheta_viesti($sms_lahettaja,$palautus_viesti);
			$yhteys = null; 
			$arvot = null;
			exit;
		}
		else if($rivi["sms_oikeus"] == null) {
			$palautus_viesti = "Ei oikeuksia huoltoviesti ohjaukseen.";
			laheta_viesti($sms_lahettaja,$palautus_viesti);
			$yhteys = null; 
			$arvot = null;
			exit;
		}
	}

	$sql = "SELECT kohde_id, tila_id, (SELECT nimi FROM tila WHERE tila.tila_id = huoltoviesti.tila_id) AS tila_nimi, aktiivinen FROM huoltoviesti WHERE ohjaus = :ohjaus";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":ohjaus", $sms_teksti);
	$arvot->execute();
	$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
	if($rivi == null) {
		$palautus_viesti = "Virheellinen ohjaus";
	}
	else {
		if($rivi["aktiivinen"] == 0) {
			$palautus_viesti = "Valittu ohjaus ei ole aktiivinen";
		}
		else {
			$kohde_id = $rivi["kohde_id"];
			$asetettava_tila_nimi = $rivi["tila_nimi"];
			$asetettava_tila_id = $rivi["tila_id"];
			$tapahtumatyyppi = 1;
			
			$sql = "SELECT nimi, (SELECT nimi FROM tila WHERE tila.tila_id = kohde.tila_id) AS tila_nimi FROM kohde WHERE kohde_id = :kohde_id";
			$arvot = $yhteys->prepare($sql);
			$arvot->bindParam(":kohde_id", $kohde_id);
			$arvot->execute();
			$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
			if($rivi != null) {
				$kohde_nimi = $rivi["nimi"];
				$tila_nimi = $rivi["tila_nimi"];
				$kuvaus = "Vaihdettu tilasta '" . $tila_nimi . "' tilaan '" . $asetettava_tila_nimi . "' (Huoltoviesti)";
				
				$sql = "UPDATE kohde SET tila_id = :tila_id WHERE kohde_id = :kohde_id";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":tila_id", $asetettava_tila_id);
				$arvot->bindParam(":kohde_id", $kohde_id);
				$arvot->execute();
				
				$sql = "INSERT INTO tapahtuma (tapahtuma_id, tyyppi, kohde_id, kuvaus, aikaleima) VALUES (NULL, :tyyppi, :kohde_id, :kuvaus, :aikaleima)";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":tyyppi", $tapahtumatyyppi);
				$arvot->bindParam(":kohde_id", $kohde_id);
				$arvot->bindParam(":kuvaus", $kuvaus);
				$arvot->bindParam(":aikaleima", $aikaleima);
				$arvot->execute();
				
				$palautus_viesti = $kohde_nimi . " vaihdettu tilasta '" . $tila_nimi . "' tilaan '" . $asetettava_tila_nimi . "'";
			}
		}
	}
	
	$yhteys = null; 
	$arvot = null;
	
	laheta_viesti($sms_lahettaja,$palautus_viesti);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	laheta_viesti($sms_lahettaja,"Tietokantavirhe, ota yhteyttä järjestelmänylläpitoon");
}

function laheta_viesti($sms_lahettaja, $viesti)
{
	$osoite = "http://92.222.20.107/sms/infobip/laheta_sms.php";
	$tiedot = array("gsm" => $sms_lahettaja, "msg" => $viesti);
	$valinnat = array(
		"http" => array(
			"header"  => "Content-type: application/x-www-form-urlencoded\r\n",
			"method"  => "POST",
			"content" => http_build_query($tiedot),
		),
	);
	$tietovirta  = stream_context_create($valinnat);
	$palautus = file_get_contents($osoite, false, $tietovirta);
	return $palautus;
}
?>