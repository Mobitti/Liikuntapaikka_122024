<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("huoltoviesti_id",true,"id")
	|| !tarkista_parametri("kohde_id",false,"id")
	|| !tarkista_parametri("ohjaus",false,"teksti")
	|| !tarkista_parametri("aktiivinen",false,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["huoltoviesti_id"] == "") {
		$sql = "SELECT huoltoviesti_id FROM huoltoviesti WHERE ohjaus = :ohjaus";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":ohjaus", $_POST["ohjaus"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Huoltoviesti ohjaus on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "INSERT INTO huoltoviesti (huoltoviesti_id, kohde_id, tila_id, ohjaus, aktiivinen) VALUES (NULL, :kohde_id, :tila_id, :ohjaus, :aktiivinen)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->bindParam(":tila_id", $_POST["tila_id"]);
		$arvot->bindParam(":ohjaus", $_POST["ohjaus"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->execute();
		$huoltoviesti_id = $yhteys->lastInsertId();
		
		$rivi_tieto["nimi"] = "Huoltoviesti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}
	else {
		$sql = "SELECT huoltoviesti_id FROM huoltoviesti WHERE ohjaus = :ohjaus AND huoltoviesti_id != :huoltoviesti_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":ohjaus", $_POST["ohjaus"]);
		$arvot->bindParam(":huoltoviesti_id", $_POST["huoltoviesti_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Huoltoviesti ohjaus on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "UPDATE huoltoviesti SET kohde_id = :kohde_id, tila_id = :tila_id, ohjaus = :ohjaus, aktiivinen = :aktiivinen WHERE huoltoviesti_id = :huoltoviesti_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->bindParam(":tila_id", $_POST["tila_id"]);
		$arvot->bindParam(":ohjaus", $_POST["ohjaus"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->bindParam(":huoltoviesti_id", $_POST["huoltoviesti_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Huoltoviesti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>