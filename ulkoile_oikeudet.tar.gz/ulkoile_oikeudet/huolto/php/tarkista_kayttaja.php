<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("tunnus",true,"teksti") 
	|| !tarkista_parametri("salasana",true,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	if($_POST["tunnus"] == "") {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Tarkista tunnus.";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$kayttaja_oikeudet = array();
	$aikaleima = date("Y-m-d H:i:s");
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$sql = "SELECT kayttaja_id FROM kayttaja WHERE tunnus = :tunnus AND salasana = SHA2(:salasana,512)";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":tunnus", $_POST["tunnus"]);
	$arvot->bindParam(":salasana", $_POST["salasana"]);
	$arvot->execute();
	$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
	if($rivi != null) {
		$sql = "SELECT oikeus_id FROM kayttaja_oikeus WHERE kayttaja_id = :kayttaja_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kayttaja_id", $rivi["kayttaja_id"]);
		$arvot->execute();
		while($rivi = $arvot->fetch(PDO::FETCH_ASSOC))
		{
			array_push($kayttaja_oikeudet,$rivi["oikeus_id"]);
		}
		
		$rivi_tieto["oikeudet"] = $kayttaja_oikeudet;
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "INSERT INTO kirjautumisloki (kirjautumisloki_id, kayttaja, aikaleima, onnistui) VALUES(NULL, :kayttaja, :aikaleima, 1)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kayttaja", $_POST["tunnus"]);
		$arvot->bindParam(":aikaleima", $aikaleima);
		$arvot->execute();
		
		$tila_tieto["virhe"] = 0;
		$tila_tieto["viesti"] = "";
		$tiedot["tila"] = $tila_tieto;
		$tiedot["rivitiedot"] = $rivi_tiedot;
	}
	else {
		$sql = "INSERT INTO kirjautumisloki (kirjautumisloki_id, kayttaja, aikaleima, onnistui) VALUES(NULL, :kayttaja, :aikaleima, 0)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kayttaja", $_POST["tunnus"]);
		$arvot->bindParam(":aikaleima", $aikaleima);
		$arvot->execute();
		
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Tarkista tunnus ja salasana.";
		$tiedot["tila"] = $tila_tieto;
	}
	echo json_encode($tiedot);
	
	$yhteys = null; 
	$arvot = null;
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>