<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$rivimaara = 0;
	$rivimaara_yhteensa = "";

	if(!tarkista_parametri("jarjestysluku",true,"numero")
	|| !tarkista_parametri("leveysaste",true,"teksti")
	|| !tarkista_parametri("pituusaste",true,"teksti")
	|| !tarkista_parametri("aineistotunnus",true,"teksti")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$leveysasteWhere = "";
	$pituusasteWhere = "";
	$aineistotunnusWhere = "";
	
	if($_POST["leveysaste"] != "") {
		$leveysasteWhere = " AND leveysaste LIKE '%" . $_POST["leveysaste"]  . "%'";
	}
	
	if($_POST["pituusaste"] != "") {
		$pituusasteWhere = " AND pituusaste LIKE '%" . $_POST["pituusaste"]  . "%'";
	}
	
	if($_POST["aineistotunnus"] != "") {
		$aineistotunnusWhere = " AND aineistotunnus = '" . $_POST["aineistotunnus"]  . "'";
	}
	
	if($leveysasteWhere != "" || $pituusasteWhere != "" || $ainestotunnusWhere != "") {
		$sql = "SELECT COUNT(aineisto_id) AS lukumaara FROM aineisto";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$rivimaara_yhteensa = $rivi["lukumaara"];
		}
	}
	
	$sql = "SELECT aineisto_id, jarjestysluku, leveysaste, pituusaste, aineistotunnus FROM aineisto" . preg_replace("/AND/","WHERE", $leveysasteWhere . $pituusasteWhere . $aineistotunnusWhere,1) . " ORDER BY aineistotunnus ASC, jarjestysluku ASC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$aineisto_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	for($i = 0; $i < sizeOf($aineisto_tiedot); $i++)
	{		
		$rivi_tieto["aineisto_id"] = $aineisto_tiedot[$i]["aineisto_id"];
		$rivi_tieto["jarjestysluku"] = $aineisto_tiedot[$i]["jarjestysluku"];
		$rivi_tieto["leveysaste"] = $aineisto_tiedot[$i]["leveysaste"];
		$rivi_tieto["pituusaste"] = $aineisto_tiedot[$i]["pituusaste"];
		$rivi_tieto["aineistotunnus"] = $aineisto_tiedot[$i]["aineistotunnus"];
		$rivimaara++;
		
		array_push($rivi_tiedot,$rivi_tieto);
	}

	if($rivimaara_yhteensa == "") {
		$rivimaara_yhteensa = $rivimaara;
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	$tiedot["lukumaarat"]["rivimaara_yhteensa"] = $rivimaara_yhteensa;
	$tiedot["lukumaarat"]["rivimaara"] = $rivimaara;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>