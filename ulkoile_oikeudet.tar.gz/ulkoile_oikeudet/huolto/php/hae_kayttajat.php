<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$rivimaara = 0;
	$rivimaara_yhteensa = "";

	if(!tarkista_parametri("nimi",true,"teksti")
	|| !tarkista_parametri("puhelin",true,"teksti")
	|| !tarkista_parametri("sahkoposti",true,"teksti")
	|| !tarkista_parametri("tunnus",true,"teksti")
	|| !tarkista_parametri("ryhma",true,"teksti")
	|| !tarkista_parametri("oikeudet",true,"teksti")
	|| !tarkista_parametri("kohteet",true,"teksti")
	|| !tarkista_parametri("aktiivinen",true,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$nimiWhere = "";
	$puhelinWhere = "";
	$sahkopostiWhere = "";
	$tunnusWhere = "";
	$ryhmaWhere = "";
	$oikeudetWhere = "";
	$kohteetWhere = "";
	$aktiivinenWhere = "";
	
	if($_POST["nimi"] != "") {
		$nimiWhere = " AND nimi LIKE '%" . $_POST["nimi"]  . "%'";
	}
	
	if($_POST["puhelin"] != "") {
		$puhelinWhere = " AND puhelin LIKE '%" . $_POST["puhelin"]  . "%'";
	}
	
	if($_POST["sahkoposti"] != "") {
		$sahkopostiWhere = " AND sahkoposti LIKE '%" . $_POST["sahkoposti"]  . "%'";
	}
	
	if($_POST["tunnus"] != "") {
		$tunnusWhere = " AND tunnus LIKE '%" . $_POST["tunnus"]  . "%'";
	}
	
	if($_POST["ryhma"] != "") {
		$ryhmaWhere = " AND ryhma LIKE '%" . $_POST["ryhma"]  . "%'";
	}
	
	if($_POST["oikeudet"] != "") {
		$oikeudetWhere = " AND kayttaja_id IN(SELECT kayttaja_id FROM kayttaja_oikeus WHERE oikeus_id IN(" . $_POST["oikeudet"] . "))";
	}
	
	if($_POST["kohteet"] != "") {
		$kohteetWhere = " AND kayttaja_id IN(SELECT kayttaja_id FROM kayttaja_kohde WHERE kohde_id IN(" . $_POST["kohteet"] . "))";
	}
	
	if($_POST["aktiivinen"] != "") {
		$aktiivinenWhere = " AND aktiivinen = '" . $_POST["aktiivinen"]  . "'";
	}
	
	if($nimiWhere != "" || $puhelinWhere != "" || $sahkopostiWhere != "" || $tunnusWhere != "" || $ryhmaWhere != "" || $oikeudetWhere != "" || $kohteetWhere != "" || $aktiivinenWhere != "") {
		$sql = "SELECT COUNT(kayttaja_id) AS lukumaara FROM kayttaja";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$rivimaara_yhteensa = $rivi["lukumaara"];
		}
	}
	
	$sql = "SELECT kayttaja_id, nimi, puhelin, sahkoposti, tunnus, ryhma, aktiivinen FROM kayttaja " . preg_replace("/AND/","WHERE", $nimiWhere . $puhelinWhere . $sahkopostiWhere . $tunnusWhere . $ryhmaWhere . $oikeudetWhere . $kohteetWhere . $aktiivinenWhere,1) . " ORDER BY nimi ASC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$kayttaja_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	for($i = 0; $i < sizeOf($kayttaja_tiedot); $i++)
	{
		$sql = "SELECT kayttaja_oikeus_id, oikeus_id FROM kayttaja_oikeus WHERE kayttaja_id = :kayttaja_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kayttaja_id", $kayttaja_tiedot[$i]["kayttaja_id"]);
		$arvot->execute();
		$oikeudet = $arvot->fetchAll(PDO::FETCH_ASSOC);
		
		$sql = "SELECT kayttaja_kohde_id, kohde_id FROM kayttaja_kohde WHERE kayttaja_id = :kayttaja_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kayttaja_id", $kayttaja_tiedot[$i]["kayttaja_id"]);
		$arvot->execute();
		$kohteet = $arvot->fetchAll(PDO::FETCH_ASSOC);
		
		$rivi_tieto["kayttaja_id"] = $kayttaja_tiedot[$i]["kayttaja_id"];
		$rivi_tieto["nimi"] = $kayttaja_tiedot[$i]["nimi"];
		$rivi_tieto["puhelin"] = $kayttaja_tiedot[$i]["puhelin"];
		$rivi_tieto["sahkoposti"] = $kayttaja_tiedot[$i]["sahkoposti"];
		$rivi_tieto["tunnus"] = $kayttaja_tiedot[$i]["tunnus"];
		$rivi_tieto["ryhma"] = $kayttaja_tiedot[$i]["ryhma"];
		$rivi_tieto["oikeudet"] = $oikeudet;
		$rivi_tieto["kohteet"] = $kohteet;
		$rivi_tieto["aktiivinen"] = $kayttaja_tiedot[$i]["aktiivinen"];
		$rivimaara++;
		
		array_push($rivi_tiedot,$rivi_tieto);
	}

	if($rivimaara_yhteensa == "") {
		$rivimaara_yhteensa = $rivimaara;
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	$tiedot["lukumaarat"]["rivimaara_yhteensa"] = $rivimaara_yhteensa;
	$tiedot["lukumaarat"]["rivimaara"] = $rivimaara;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>