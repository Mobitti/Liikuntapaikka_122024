<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();

	if(!tarkista_parametri("kohde_id",true,"id")
	|| !tarkista_parametri("kategoria_id",false,"id")
	|| !tarkista_parametri("nimi",false,"teksti")
	|| !tarkista_parametri("kuvaus",true,"teksti")
	|| !tarkista_parametri("attribuutit",true,"teksti")
	|| !tarkista_parametri("tila_id",false,"id")
	|| !tarkista_parametri("aineistotunnus",false,"teksti")
	|| !tarkista_parametri("aktiivinen",false,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$jarjestysluku = 1;
	$tila_nimi = "";
	$asetettava_tila_nimi = "";
	$tapahtumatyyppi = 1;
	$kuvaus = "";
	$aikaleima =  date("Y-m-d H:i:s");
	
	if($_POST["kohde_id"] == "") {
		$sql = "SELECT kohde_id FROM kohde WHERE aineistotunnus = :aineistotunnus";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Kohde on jo olemassa, tarkista aineistotunnus";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "SELECT COUNT(*) AS lkm FROM kohde WHERE kategoria_id = kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$jarjestysluku = $rivi['lkm'] + 1;
		}
		
		$sql = "INSERT INTO kohde (kohde_id, kategoria_id, jarjestysluku, nimi, kuvaus, tila_id, aineistotunnus, aktiivinen) VALUES (NULL, :kategoria_id, :jarjestysluku, :nimi, :kuvaus, :tila_id, :aineistotunnus, :aktiivinen)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
		$arvot->bindParam(":jarjestysluku", $jarjestysluku);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":kuvaus", $_POST["kuvaus"]);
		$arvot->bindParam(":tila_id", $_POST["tila_id"]);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->execute();
		$kohde_id = $yhteys->lastInsertId();
		
		$rivi_tieto["nimi"] = "Kohde";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		if($kohde_id != "" && $kohde_id != null) {
			for($i = 0; $i < sizeOf($_POST["attribuutit"]); $i++)
			{
				$attribuutti_id = $_POST["attribuutit"][$i]["tieto1"];
				$attribuutti_arvo = $_POST["attribuutit"][$i]["tieto2"];
				
				if($attribuutti_id != "") {
					$sql = "INSERT INTO kohde_attribuutti (kohde_attribuutti_id, kohde_id, attribuutti_id, arvo) VALUES (NULL, :kohde_id, :attribuutti_id, :arvo)";
					$arvot = $yhteys->prepare($sql);
					$arvot->bindParam(":kohde_id", $kohde_id);
					$arvot->bindParam(":attribuutti_id", $attribuutti_id);
					$arvot->bindParam(":arvo", $attribuutti_arvo);
					$arvot->execute();
					$rivi_tieto["nimi"] = "Kohde Attribuutti";
					$rivi_tieto["kpl"] = $arvot->rowCount();
					array_push($rivi_tiedot,$rivi_tieto);
				}
			}
		}
	}
	else {
		$sql = "SELECT kohde_id FROM kohde WHERE aineistotunnus = :aineistotunnus AND kohde_id != :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Kohde on jo olemassa, tarkista aineistotunnus";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "SELECT nimi FROM tila WHERE tila_id = :tila_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":tila_id", $_POST["tila_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$asetettava_tila_nimi = $rivi["nimi"];
		}
		
		$sql = "SELECT (SELECT nimi FROM tila WHERE tila.tila_id = kohde.tila_id) AS tila_nimi FROM kohde WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_nimi = $rivi["tila_nimi"];
		}
		
		$sql = "UPDATE kohde SET kategoria_id = :kategoria_id, nimi = :nimi, kuvaus = :kuvaus, tila_id = :tila_id, aineistotunnus = :aineistotunnus, aktiivinen = :aktiivinen WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":kuvaus", $_POST["kuvaus"]);
		$arvot->bindParam(":tila_id", $_POST["tila_id"]);
		$arvot->bindParam(":aineistotunnus", $_POST["aineistotunnus"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Kohde";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM kohde_attribuutti WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();
		
		for($i = 0; $i < sizeOf($_POST["attribuutit"]); $i++)
		{
			$attribuutti_id = $_POST["attribuutit"][$i]["tieto1"];
			$attribuutti_arvo = $_POST["attribuutit"][$i]["tieto2"];
			
			if($attribuutti_id != "") {
				$sql = "INSERT INTO kohde_attribuutti (kohde_attribuutti_id, kohde_id, attribuutti_id, arvo) VALUES (NULL, :kohde_id, :attribuutti_id, :arvo)";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
				$arvot->bindParam(":attribuutti_id", $attribuutti_id);
				$arvot->bindParam(":arvo", $attribuutti_arvo);
				$arvot->execute();
				
				$rivi_tieto["nimi"] = "Kohde Attribuutti";
				$rivi_tieto["kpl"] = $arvot->rowCount();
				array_push($rivi_tiedot,$rivi_tieto);
			}
		}
		
		if($tila_nimi != $asetettava_tila_nimi) {
			$kuvaus = "Vaihdettu tilasta " . $tila_nimi . " tilaan " . $asetettava_tila_nimi;
		}
		else {
			$kuvaus = $asetettava_tila_nimi . " päivitetty";
		}
		
		$sql = "INSERT INTO tapahtuma (tapahtuma_id, tyyppi, kohde_id, kuvaus, aikaleima) VALUES (NULL, :tyyppi, :kohde_id, :kuvaus, :aikaleima)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":tyyppi", $tapahtumatyyppi);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->bindParam(":kuvaus", $kuvaus);
		$arvot->bindParam(":aikaleima", $aikaleima);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Tapahtuma";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>