<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();

	if(!tarkista_parametri("laite_id",true,"id")
	|| !tarkista_parametri("laitetunnus",false,"teksti")
	|| !tarkista_parametri("kuvaus",true,"teksti")
	|| !tarkista_parametri("aktiivinen",false,"totuusarvo")
	|| !tarkista_parametri("attribuutit",true,"teksti")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["laite_id"] == "") {
		$sql = "SELECT laite_id FROM laite WHERE laitetunnus = :laitetunnus";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":laitetunnus", $_POST["laitetunnus"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Laite on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "INSERT INTO laite (laite_id, laitetunnus, kuvaus, aktiivinen) VALUES (NULL, :laitetunnus, :kuvaus, :aktiivinen)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":laitetunnus", $_POST["laitetunnus"]);
		$arvot->bindParam(":kuvaus", $_POST["kuvaus"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->execute();
		$laite_id = $yhteys->lastInsertId();
		
		$rivi_tieto["nimi"] = "Laite";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		if($laite_id != "" && $laite_id != null) {
			for($i = 0; $i < sizeOf($_POST["attribuutit"]); $i++)
			{
				$attribuutti_id = $_POST["attribuutit"][$i]["tieto1"];
				$paivitysvali = $_POST["attribuutit"][$i]["tieto2"];
				
				if($attribuutti_id != "" && $paivitysvali != "") {
					$sql = "INSERT INTO laite_attribuutti (laite_attribuutti_id, laite_id, attribuutti_id, paivitysvali) VALUES (NULL, :laite_id, :attribuutti_id, :paivitysvali)";
					$arvot = $yhteys->prepare($sql);
					$arvot->bindParam(":laite_id", $laite_id);
					$arvot->bindParam(":attribuutti_id", $attribuutti_id);
					$arvot->bindParam(":paivitysvali", $paivitysvali);
					$arvot->execute();
					$rivi_tieto["nimi"] = "Laite_Attribuutti";
					$rivi_tieto["kpl"] = $arvot->rowCount();
					array_push($rivi_tiedot,$rivi_tieto);
				}
			}
		}
	}
	else {
		$sql = "SELECT laite_id FROM laite WHERE laitetunnus = :laitetunnus AND laite_id != :laite_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":laitetunnus", $_POST["laitetunnus"]);
		$arvot->bindParam(":laite_id", $_POST["laite_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Laite on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "UPDATE laite SET laitetunnus = :laitetunnus, kuvaus = :kuvaus, aktiivinen = :aktiivinen WHERE laite_id = :laite_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":laitetunnus", $_POST["laitetunnus"]);
		$arvot->bindParam(":kuvaus", $_POST["kuvaus"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->bindParam(":laite_id", $_POST["laite_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Laite";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM laite_attribuutti WHERE laite_id = :laite_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":laite_id", $_POST["laite_id"]);
		$arvot->execute();
		
		for($i = 0; $i < sizeOf($_POST["attribuutit"]); $i++)
		{
			$attribuutti_id = $_POST["attribuutit"][$i]["tieto1"];
			$paivitysvali = $_POST["attribuutit"][$i]["tieto2"];
			
			if($attribuutti_id != "" && $paivitysvali != "") {
				$sql = "INSERT INTO laite_attribuutti (laite_attribuutti_id, laite_id, attribuutti_id, paivitysvali) VALUES (NULL, :laite_id, :attribuutti_id, :paivitysvali)";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":laite_id", $_POST['laite_id']);
				$arvot->bindParam(":attribuutti_id", $attribuutti_id);
				$arvot->bindParam(":paivitysvali", $paivitysvali);
				$arvot->execute();
				$rivi_tieto["nimi"] = "Laite_Attribuutti";
				$rivi_tieto["kpl"] = $arvot->rowCount();
				array_push($rivi_tiedot,$rivi_tieto);
			}
		}
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>