<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("viesti_id",true,"id")
	|| !tarkista_parametri("aihe",false,"id")
	|| !tarkista_parametri("sisalto",false,"teksti")
	|| !tarkista_parametri("lahettaja",true,"teksti")
	|| !tarkista_parametri("aikaleima",false,"aikaleima")
	|| !tarkista_parametri("kuitattu",true,"aikaleima")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$aikaleima = kaanna_fi_aikaleima($_POST["aikaleima"]);
	$kuitattu = null;
	if($_POST["kuitattu"] != "") {
		$kuitattu = kaanna_fi_aikaleima($_POST["kuitattu"]);
	}
	
	if($_POST["viesti_id"] == "") {
		$sql = "INSERT INTO viesti (viesti_id, aihe, sisalto, lahettaja, aikaleima, kuitattu) VALUES (NULL, :aihe, :sisalto, :lahettaja, :aikaleima, :kuitattu)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":aihe", $_POST["aihe"]);
		$arvot->bindParam(":sisalto", $_POST["sisalto"]);
		$arvot->bindParam(":lahettaja", $_POST["lahettaja"]);
		$arvot->bindParam(":aikaleima", $aikaleima);
		$arvot->bindParam(":kuitattu", $kuitattu);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Viesti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}
	else {
		$sql = "UPDATE viesti SET aihe = :aihe, kuitattu = :kuitattu WHERE viesti_id = :viesti_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":aihe", $_POST["aihe"]);
		$arvot->bindParam(":kuitattu", $kuitattu);
		$arvot->bindParam(":viesti_id", $_POST["viesti_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Viesti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>