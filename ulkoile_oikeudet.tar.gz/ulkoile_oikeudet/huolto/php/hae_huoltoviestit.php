<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$rivimaara = 0;
	$rivimaara_yhteensa = "";

	if(!tarkista_parametri("kohde_id",true,"id")
	|| !tarkista_parametri("tila_id",true,"id")
	|| !tarkista_parametri("ohjaus",true,"teksti")
	|| !tarkista_parametri("aktiivinen",true,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$kohdeWhere = "";
	$tilaWhere = "";
	$ohjausWhere = "";
	$aktiivinenWhere = "";
	
	if($_POST["kohde_id"] != "") {
		$kohdeWhere = " AND kohde_id = '" . $_POST["kohde_id"]  . "'";
	}
	
	if($_POST["tila_id"] != "") {
		$tilaWhere = " AND tila_id = '" . $_POST["tila_id"]  . "'";
	}
	
	if($_POST["ohjaus"] != "") {
		$ohjausWhere = " AND ohjaus LIKE '%" . $_POST["ohjaus"]  . "%'";
	}
	
	if($_POST["aktiivinen"] != "") {
		$aktiivinenWhere = " AND aktiivinen = '" . $_POST["aktiivinen"]  . "'";
	}
	
	if($kohdeWhere != "" || $tilaWhere != "" || $ohjausWhere != "" || $aktiivinenWhere != "") {
		$sql = "SELECT COUNT(huoltoviesti_id) AS lukumaara FROM huoltoviesti";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$rivimaara_yhteensa = $rivi["lukumaara"];
		}
	}
	
	$sql = "SELECT huoltoviesti_id, kohde_id, (SELECT nimi FROM kohde WHERE kohde.kohde_id = huoltoviesti.kohde_id) AS kohde_nimi, tila_id, (SELECT nimi FROM tila WHERE tila.tila_id = huoltoviesti.tila_id) AS tila_nimi, ohjaus, aktiivinen FROM huoltoviesti" . preg_replace("/AND/","WHERE", $kohdeWhere . $tilaWhere . $ohjausWhere . $aktiivinenWhere,1) . " ORDER BY kohde_nimi, tila_nimi ASC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$huoltoviesti_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	for($i = 0; $i < sizeOf($huoltoviesti_tiedot); $i++)
	{
		$rivi_tieto["huoltoviesti_id"] = $huoltoviesti_tiedot[$i]["huoltoviesti_id"];
		$rivi_tieto["kohde_id"] = $huoltoviesti_tiedot[$i]["kohde_id"];
		$rivi_tieto["kohde_nimi"] = $huoltoviesti_tiedot[$i]["kohde_nimi"];
		$rivi_tieto["tila_id"] = $huoltoviesti_tiedot[$i]["tila_id"];
		$rivi_tieto["tila_nimi"] = $huoltoviesti_tiedot[$i]["tila_nimi"];
		$rivi_tieto["ohjaus"] = $huoltoviesti_tiedot[$i]["ohjaus"];
		$rivi_tieto["aktiivinen"] = $huoltoviesti_tiedot[$i]["aktiivinen"];
		$rivimaara++;
		
		array_push($rivi_tiedot,$rivi_tieto);
	}

	if($rivimaara_yhteensa == "") {
		$rivimaara_yhteensa = $rivimaara;
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	$tiedot["lukumaarat"]["rivimaara_yhteensa"] = $rivimaara_yhteensa;
	$tiedot["lukumaarat"]["rivimaara"] = $rivimaara;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>