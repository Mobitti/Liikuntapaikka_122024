<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$parametrit = array();
	
	array_push($parametrit,array("tila_id",tarkista_parametri("tila_id",true,"id")));
	array_push($parametrit,array("nimi",tarkista_parametri("nimi",false,"teksti")));
	array_push($parametrit,array("vari",tarkista_parametri("vari",false,"teksti")));
	array_push($parametrit,array("kayttaja",tarkista_parametri("kayttaja",false,"teksti")));
	
	if(!tarkista_parametrit($parametrit)) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		$tiedot["rivitiedot"] = $parametrit;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["tila_id"] == "") {
		$sql = "SELECT tila_id FROM tila WHERE nimi = :nimi";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Tila on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "INSERT INTO tila (tila_id, nimi, vari) VALUES (NULL, :nimi, :vari)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":vari", $_POST["vari"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Tila";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}
	else {
		$sql = "SELECT tila_id FROM tila WHERE nimi = :nimi AND tila_id != :tila_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":tila_id", $_POST["tila_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Tila on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "UPDATE tila SET nimi = :nimi, vari = :vari WHERE tila_id = :tila_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":vari", $_POST["vari"]);
		$arvot->bindParam(":tila_id", $_POST["tila_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Tila";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>