<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();

	if(!tarkista_parametri("valittu_kategoria_id",false,"id")
	|| !tarkista_parametri("vaihdettava_kategoria_id",false,"id")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$valittu_jarjestysluku = 0;
	$vaihdettava_jarjestysluku = 0;
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$sql = "SELECT kategoria_id, jarjestysluku FROM kategoria WHERE kategoria_id = :valittu_kategoria_id OR kategoria_id = :vaihdettava_kategoria_id";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":valittu_kategoria_id", $_POST["valittu_kategoria_id"]);
	$arvot->bindParam(":vaihdettava_kategoria_id", $_POST["vaihdettava_kategoria_id"]);
	$arvot->execute();
	while($rivi = $arvot->fetch(PDO::FETCH_ASSOC))
	{
		if($rivi["kategoria_id"] == $_POST["valittu_kategoria_id"]) {
			$valittu_jarjestysluku = $rivi["jarjestysluku"];
		}
		else if($rivi["kategoria_id"] == $_POST["vaihdettava_kategoria_id"]) {
			$vaihdettava_jarjestysluku = $rivi["jarjestysluku"];
		}
	}
	
	if($valittu_jarjestysluku != 0 && $vaihdettava_jarjestysluku != 0) {
		$sql = "UPDATE kategoria SET jarjestysluku = :jarjestysluku  WHERE kategoria_id = :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":jarjestysluku", $vaihdettava_jarjestysluku);
		$arvot->bindParam(":kategoria_id", $_POST["valittu_kategoria_id"]);
		$arvot->execute();
		
		$rivi_tieto["kpl"] = $arvot->rowCount();
	
		$sql = "UPDATE kategoria SET jarjestysluku = :jarjestysluku  WHERE kategoria_id = :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":jarjestysluku", $valittu_jarjestysluku);
		$arvot->bindParam(":kategoria_id", $_POST["vaihdettava_kategoria_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Vaihdettu kategorian järjestystä";
		$rivi_tieto["kpl"] += $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	
		$tila_tieto["virhe"] = 0;
		$tila_tieto["viesti"] = "";
	}
	else {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Kategorioiden järjestyksen vaihto epäonnistui";
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>