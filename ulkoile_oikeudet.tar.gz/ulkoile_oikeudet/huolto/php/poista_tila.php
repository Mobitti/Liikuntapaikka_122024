<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("tila_id",false,"id") 
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$sql = "SELECT COUNT(kategoria_tila_id) AS lukumaara FROM kategoria_tila WHERE tila_id = :tila_id";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":tila_id", $_POST["tila_id"]);
	$arvot->execute();
	$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
	if($rivi != null) {
		if($rivi["lukumaara"] > 0) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Poisto epäonnistui. Tila käytössä " . $rivi["lukumaara"] . " kategoriassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			$yhteys = null; 
			$arvot = null;
			return;
		}
	}
	
	if($_POST["tila_id"] != ""){
		$sql = "DELETE FROM tila WHERE tila_id = :tila_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":tila_id", $_POST["tila_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Tila";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "Poisto onnistui";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>