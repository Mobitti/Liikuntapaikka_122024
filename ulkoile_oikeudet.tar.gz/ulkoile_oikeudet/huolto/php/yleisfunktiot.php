<?php

function tarkista_parametri($muuttuja,$tyhja,$tyyppi)
{	
	if(array_key_exists($muuttuja,$_POST)) {
		if($tyhja == false && $_POST[$muuttuja] == "") { 
			return false;
		}
		else if($tyhja == true && $_POST[$muuttuja] == "") {
			return true;
		}		
		
		switch($tyyppi)
		{
			case "teksti": return tarkista_arvo($_POST[$muuttuja]); break;
			case "numero": return tarkista_numero($_POST[$muuttuja]); break;
			case "id": return tarkista_id($_POST[$muuttuja]); break;
			case "totuusarvo": return tarkista_totuusarvo($_POST[$muuttuja]); break;
			case "aikaleima": return tarkista_arvo($_POST[$muuttuja]); break;
			case "pvm": return tarkista_arvo($_POST[$muuttuja]); break;
			case "sahkoposti": return tarkista_arvo($_POST[$muuttuja]); break;
			case "puhelin": return tarkista_arvo($_POST[$muuttuja]); break;
			case "tietuekokoelma": return tarkista_arvo($_POST[$muuttuja]); break;
			case "väri": return tarkista_vari($_POST[$muuttuja]); break;
			
			default: return tarkista_arvo($_POST[$muuttuja]);
		}
	}

	return false;
}

function tarkista_parametrit($parametrit) 
{
	for($i = 0; $i < sizeOf($parametrit); $i++) 
	{
		if(!$parametrit[$i][1]) {
			return false;
		}
	}

	return true;
}

function tarkista_arvo($muuttuja)
{
	if($muuttuja != null) {
		return true;
	}
	
	return false;
}

function tarkista_id($muuttuja)
{
	if(ctype_digit($muuttuja) && $muuttuja > 0) {
		return true;
	}
	
	return false;
}

function tarkista_vari($muuttuja)
{
	if(substr($muuttuja,0,1) == "#") {
		if(ctype_xdigit(substr($muuttuja,0,1))) {
			return true;
		}
	}
	else {
		if(ctype_xdigit($muuttuja)) {
			return true;
		}
	}
	
	return false;
}

function tarkista_numero($muuttuja) 
{
	if(substr($muuttuja,0,1) == "-") {
		if(is_int(substr($muuttuja,1)) || ctype_digit(substr($muuttuja,1))) {
			return true;
		}
	}
	else if(is_int($muuttuja) || ctype_digit($muuttuja)) {
		return true;
	}
	
	return false;
}

function tarkista_totuusarvo($muuttuja) 
{
	if($muuttuja == 1 || $muuttuja == 0) {
		return true;
	}
	
	return false;
}

function tarkista_desimaali($desimaali)
{
	$tarkistettava_desimaali = $desimaali;
	if(substr($desimaali,0,1) == "-") {
		$tarkistettava_desimaali = substr($desimaali,1);
	}
	
	if(strpos($tarkistettava_desimaali,",")) {
		$numerot = explode(",",$tarkistettava_desimaali);
		if(sizeOf($numerot) == 2 && (is_int($numerot[0]) || ctype_digit($numerot[0])) && (is_int($numerot[1]) || ctype_digit($numerot[1]))) {
			return $desimaali;
		}
		else {
			return 0;
		}
	}
	else {
		return tarkista_numero($desimaali);
	}
}

function tarkista_tyhja_arvo($arvo)
{
	if($arvo != null) {
		return $arvo;
	}
	else {
		return "";
	}
}

function fi_aikaleima_muoto($aikaleima,$paivanimi)
{
	$paiva = "";
	switch ($paivanimi) 
	{
	case "Monday":
		$paiva = "Ma";
		break;
	case "Tuesday":
		$paiva = "Ti";
		break;
	case "Wednesday":
		$paiva = "Ke";
		break;
	case "Thursday":
		$paiva = "To";
		break;
	case "Friday":
		$paiva = "Pe";
		break;
	case "Saturday":
		$paiva = "La";
		break;
	case "Sunday":
		$paiva = "Su";
		break;
	}
	
	return $paiva . " " . substr($aikaleima, 8, 2) . "." . substr($aikaleima, 5, 2) . "." . substr($aikaleima, 0, 4) . " - " . substr($aikaleima,11);
}

function palauta_paivanimi_fi($paivanimi)
{
	$paivanimi_fi ="";
	switch ($paivanimi) 
	{
		case "Monday":
			$paivanimi_fi = "Ma";
			break;
		case "Tuesday":
			$paivanimi_fi = "Ti";
			break;
		case "Wednesday":
			$paivanimi_fi = "Ke";
			break;
		case "Thursday":
			$paivanimi_fi = "To";
			break;
		case "Friday":
			$paivanimi_fi = "Pe";
			break;
		case "Saturday":
			$paivanimi_fi = "La";
			break;
		case "Sunday":
			$paivanimi_fi = "Su";
			break;
	}
	return $paivanimi_fi;
}

function palauta_pvm_fi($pvm)
{
	return substr($pvm, 8, 2) . "." . substr($pvm, 5, 2) . "." . substr($pvm, 0, 4);
}

function palauta_aikaleima_fi($aikaleima)
{
	return substr($aikaleima, 8, 2) . "." . substr($aikaleima, 5, 2) . "." . substr($aikaleima, 0, 4) . substr($aikaleima,10);
}

function kaanna_fi_aikaleima($aikaleima)
{
	return substr($aikaleima, 6, 4) . "-" . substr($aikaleima, 3, 2) . "-" . substr($aikaleima, 0, 2) . " " . substr($aikaleima,11);
}

function kaanna_fi_pvm($pvm)
{
	return substr($pvm, 6, 4) . "-" . substr($pvm, 3, 2) . "-" . substr($pvm, 0, 2);
}
?>