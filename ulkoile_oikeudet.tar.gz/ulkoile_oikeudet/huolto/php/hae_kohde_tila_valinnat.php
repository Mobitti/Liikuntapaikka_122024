<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();

	if(!tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");

	$sql = "SELECT kohde_id, kategoria_id FROM kohde";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$kohde_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	for($i = 0; $i < sizeOf($kohde_tiedot); $i++)
	{
		$sql = "SELECT tila_id FROM kategoria_tila WHERE kategoria_id = :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kategoria_id", $kohde_tiedot[$i]["kategoria_id"]);
		$arvot->execute();
		while($rivi = $arvot->fetch(PDO::FETCH_ASSOC))
		{
			$rivi_tieto["kohde_id"] = $kohde_tiedot[$i]["kohde_id"];
			$rivi_tieto["tila_id"] = $rivi["tila_id"];
			
			array_push($rivi_tiedot,$rivi_tieto);
		}
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>