<?php
$dbuname = "uhuolto";
$dbpass = "Pl2AjLu9oF0PklK4X3F3ymhGMuKyRQcE";
$dbname = "ulkoile_kokkola_2";
$dbhost = "localhost";
?>