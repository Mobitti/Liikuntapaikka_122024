<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$jarjestysluku = 1;
	
	if(!tarkista_parametri("kategoria_id",true,"id")
	|| !tarkista_parametri("nimi",false,"teksti")
	|| !tarkista_parametri("lisatiedot",true,"teksti")
	|| !tarkista_parametri("tilat",false,"teksti")
	|| !tarkista_parametri("taso_id",true,"id")
	|| !tarkista_parametri("aktiivinen",false,"totuusarvo")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	if($_POST["kategoria_id"] == "") {
		$sql = "SELECT kategoria_id FROM kategoria WHERE nimi = :nimi";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Kategoria on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "SELECT COUNT(*) AS lkm FROM kategoria";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$jarjestysluku = $rivi['lkm'] + 1;
		}
		
		$sql = "INSERT INTO kategoria (kategoria_id, nimi, lisatiedot, taso_id, jarjestysluku, aktiivinen) VALUES (NULL, :nimi, :lisatiedot, :taso_id, :jarjestysluku, :aktiivinen)";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":lisatiedot", $_POST["lisatiedot"]);
		$arvot->bindParam(":taso_id", $_POST["taso_id"]);
		$arvot->bindParam(":jarjestysluku", $jarjestysluku);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->execute();
		$kategoria_id = $yhteys->lastInsertId();
		
		$rivi_tieto["nimi"] = "Kategoria";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		if($kategoria_id != "" && $kategoria_id != null) {
			for($i = 0; $i < sizeOf($_POST["tilat"]); $i++)
			{
				$tila_id = $_POST["tilat"][$i];
				
				if($tila_id != "") {
					$sql = "INSERT INTO kategoria_tila (kategoria_tila_id, kategoria_id, tila_id) VALUES (NULL, :kategoria_id, :tila_id)";
					$arvot = $yhteys->prepare($sql);
					$arvot->bindParam(":kategoria_id", $kategoria_id);
					$arvot->bindParam(":tila_id", $tila_id);
					$arvot->execute();
					$rivi_tieto["nimi"] = "Kategoria_Tila";
					$rivi_tieto["kpl"] = $arvot->rowCount();
					array_push($rivi_tiedot,$rivi_tieto);
				}
			}
		}
	}
	else {
		$sql = "SELECT kategoria_id FROM kategoria WHERE nimi = :nimi AND kategoria_id != :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Kategoria on jo olemassa";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		if($_POST["taso_id"] == $_POST["kategoria_id"]) {
			$tila_tieto["virhe"] = 1;
			$tila_tieto["viesti"] = "Virheellinen taso";
			$tiedot["tila"] = $tila_tieto;
			echo json_encode($tiedot);
			
			$yhteys = null; 
			$arvot = null;
			return;
		}
		
		$sql = "UPDATE kategoria SET nimi = :nimi, lisatiedot = :lisatiedot, taso_id = :taso_id, aktiivinen = :aktiivinen WHERE kategoria_id = :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":nimi", $_POST["nimi"]);
		$arvot->bindParam(":lisatiedot", $_POST["lisatiedot"]);
		$arvot->bindParam(":taso_id", $_POST["taso_id"]);
		$arvot->bindParam(":aktiivinen", $_POST["aktiivinen"]);
		$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
		$arvot->execute();
		
		$rivi_tieto["nimi"] = "Kategoria";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM kategoria_tila WHERE kategoria_id = :kategoria_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
		$arvot->execute();
		
		for($i = 0; $i < sizeOf($_POST["tilat"]); $i++)
		{
			$tila_id = $_POST["tilat"][$i];
			
			if($tila_id != "") {
				$sql = "INSERT INTO kategoria_tila (kategoria_tila_id, kategoria_id, tila_id) VALUES (NULL, :kategoria_id, :tila_id)";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":kategoria_id", $_POST["kategoria_id"]);
				$arvot->bindParam(":tila_id", $tila_id);
				$arvot->execute();
				$rivi_tieto["nimi"] = "Kategoria_Tila";
				$rivi_tieto["kpl"] = $arvot->rowCount();
				array_push($rivi_tiedot,$rivi_tieto);
			}
		}
	}

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>