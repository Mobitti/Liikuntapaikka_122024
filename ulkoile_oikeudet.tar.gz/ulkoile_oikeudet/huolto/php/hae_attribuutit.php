<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	$rivimaara = 0;
	$rivimaara_yhteensa = "";
	
	if(!tarkista_parametri("nimi",true,"teksti")
	|| !tarkista_parametri("kuvaus",true,"teksti")
	|| !tarkista_parametri("tyyppi",true,"id")
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$nimiWhere = "";
	$kuvausWhere = "";
	$tyyppiWhere = "";
	
	if($_POST["nimi"] != "") {
		$nimiWhere = " AND nimi LIKE '%" . $_POST["nimi"] . "%'";
	}
	
	if($_POST["kuvaus"] != "") {
		$kuvausWhere = " AND kuvaus LIKE '%" . $_POST["kuvaus"] . "%'";
	}
	
	if($_POST["tyyppi"] != "") {
		$tyyppiWhere = " AND tyyppi = '" . $_POST["tyyppi"] . "'";
	}
	
	if($nimiWhere != "" || $kuvausWhere != "" || $tyyppiWhere != "") {
		$sql = "SELECT COUNT(attribuutti_id) AS lukumaara FROM attribuutti";
		$arvot = $yhteys->prepare($sql);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$rivimaara_yhteensa = $rivi["lukumaara"];
		}
	}
	
	$sql = "SELECT attribuutti_id, nimi, kuvaus, tyyppi, jarjestysluku FROM attribuutti" . preg_replace("/AND/","WHERE", $nimiWhere . $kuvausWhere . $tyyppiWhere) . " ORDER BY jarjestysluku ASC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	while($rivi = $arvot->fetch(PDO::FETCH_ASSOC))
	{
		$rivi_tieto["attribuutti_id"] = $rivi["attribuutti_id"];
		$rivi_tieto["nimi"] = $rivi["nimi"];
		$rivi_tieto["kuvaus"] = $rivi["kuvaus"];
		$rivi_tieto["tyyppi"] = $rivi["tyyppi"];
		$rivi_tieto["jarjestysluku"] = $rivi["jarjestysluku"];
		$rivimaara++;
		
		array_push($rivi_tiedot,$rivi_tieto);
	}
	
	if($rivimaara_yhteensa == "") {
		$rivimaara_yhteensa = $rivimaara;
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	$tiedot["lukumaarat"]["rivimaara_yhteensa"] = $rivimaara_yhteensa;
	$tiedot["lukumaarat"]["rivimaara"] = $rivimaara;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>