<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("kohde_id",false,"id") 
	|| !tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");

	if($_POST["kohde_id"] != ""){
		$kohde_jarjestysluku = "";
		$kategoria_id = "";
		$sql = "SELECT jarjestysluku, kategoria_id FROM kohde WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$kohde_jarjestysluku = $rivi["jarjestysluku"];
		}
		
		$sql = "DELETE FROM laite_kohde_attribuutti WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();	
		$rivi_tieto["nimi"] = "Laite Kohde Attribuutti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM kayttaja_kohde WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();	
		$rivi_tieto["nimi"] = "Käyttäjä Kohde";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM huoltoviesti WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();	
		$rivi_tieto["nimi"] = "Huoltoviesti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM tapahtuma WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();	
		$rivi_tieto["nimi"] = "Tapahtuma";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM kohde_attribuutti WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();
		$rivi_tieto["nimi"] = "Kohde Attribuutti";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		$sql = "DELETE FROM kohde WHERE kohde_id = :kohde_id";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $_POST["kohde_id"]);
		$arvot->execute();	
		$rivi_tieto["nimi"] = "Kohde";
		$rivi_tieto["kpl"] = $arvot->rowCount();
		array_push($rivi_tiedot,$rivi_tieto);
		
		if($kohde_jarjestysluku != "" && $kategoria_id != "") {
			$sql = "SELECT kohde_id, jarjestysluku FROM kohde WHERE kategoria_id = :kategoria_id AND jarjestysluku > :jarjestysluku";
			$arvot = $yhteys->prepare($sql);
			$arvot->bindParam(":jarjestysluku", $kohde_jarjestysluku);
			$arvot->execute();
			$kohde_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);

			for($i = 0; $i < sizeOf($kohde_tiedot); $i++)
			{
				$kasiteltava_kohde_jarjestysluku = $kohde_tiedot[$i]["jarjestysluku"] - 1;
				$sql = "UPDATE kohde SET jarjestysluku = :jarjestysluku WHERE kohde_id = :kohde_id";
				$arvot = $yhteys->prepare($sql);
				$arvot->bindParam(":kohde_id", $kohde_tiedot[$i]["kohde_id"]);
				$arvot->bindParam(":jarjestysluku", $kasiteltava_kohde_jarjestysluku);
				$arvot->execute();
			}
		}	
	}
	
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "Poisto onnistui";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>