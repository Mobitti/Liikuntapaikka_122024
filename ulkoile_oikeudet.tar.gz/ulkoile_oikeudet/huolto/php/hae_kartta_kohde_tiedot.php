<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();

	if(!tarkista_parametri("kayttaja",false,"teksti")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$kategoria_tiedot = array();
	$kohde_tiedot = array();
	
	$sql = "SELECT kategoria_id, nimi, taso_id FROM kategoria WHERE aktiivinen = 1 ORDER BY jarjestysluku ASC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$kategoria_tiedot = $arvot->fetchAll(PDO::FETCH_ASSOC);
	
	$sql = "SELECT kohde_id, nimi, kuvaus, aineistotunnus, kategoria_id, tila_id, (SELECT nimi FROM tila WHERE tila.tila_id = kohde.tila_id) AS tila_nimi, (SELECT vari FROM tila WHERE tila.tila_id = kohde.tila_id) AS tila_vari FROM kohde WHERE aktiivinen = 1 AND (SELECT aktiivinen FROM kategoria WHERE kategoria.kategoria_id = kohde.kategoria_id) = 1 ORDER BY jarjestysluku ASC";
	$arvot = $yhteys->prepare($sql);
	$arvot->execute();
	$kohteet = $arvot->fetchAll(PDO::FETCH_ASSOC);	
	for($i = 0; $i < sizeOf($kohteet); $i++)
	{
		$kohde_tieto = array();
		$kohde_tieto["kohde_id"] = $kohteet[$i]["kohde_id"];
		$kohde_tieto["nimi"] = $kohteet[$i]["nimi"];
		$kohde_tieto["kuvaus"] = $kohteet[$i]["kuvaus"];
		$kohde_tieto["aineistotunnus"] = $kohteet[$i]["aineistotunnus"];
		$kohde_tieto["kategoria_id"] = $kohteet[$i]["kategoria_id"];
		$kohde_tieto["tila_id"] = $kohteet[$i]["tila_id"];
		$kohde_tieto["tila_nimi"] = $kohteet[$i]["tila_nimi"];
		$kohde_tieto["tila_vari"] = $kohteet[$i]["tila_vari"];
		
		$huoltotapahtuma = array();
		$sql = "SELECT kuvaus, aikaleima FROM tapahtuma WHERE kohde_id = :kohde_id AND tyyppi = 1 ORDER BY aikaleima DESC LIMIT 1";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $kohde_tieto["kohde_id"]);
		$arvot->execute();
		$rivi = $arvot->fetch(PDO::FETCH_ASSOC);
		if($rivi != null) {
			$huolto_tieto["aikaleima"] = palauta_aikaleima_fi($rivi["aikaleima"]);
			$huolto_tieto["kuvaus"] = $rivi["kuvaus"];
			array_push($huoltotapahtuma,$huolto_tieto);
		}
		$kohde_tieto["huoltotapahtuma"] = $huoltotapahtuma;
		
		$sql = "SELECT (SELECT tyyppi FROM attribuutti WHERE attribuutti_id = kohde_attribuutti.attribuutti_id) AS tyyppi, (SELECT nimi FROM attribuutti WHERE attribuutti_id = kohde_attribuutti.attribuutti_id) AS nimi, (SELECT jarjestysluku FROM attribuutti WHERE attribuutti_id = kohde_attribuutti.attribuutti_id) AS jarjestysluku, arvo FROM kohde_attribuutti WHERE kohde_id = :kohde_id ORDER BY jarjestysluku ASC";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":kohde_id", $kohde_tieto["kohde_id"]);
		$arvot->execute();
		$attribuutit = $arvot->fetchAll(PDO::FETCH_ASSOC);	
		$kohde_tieto["attribuutit"] = $attribuutit;
		
		$sql = "SELECT leveysaste, pituusaste FROM aineisto WHERE aineistotunnus = :aineistotunnus ORDER BY jarjestysluku ASC";
		$arvot = $yhteys->prepare($sql);
		$arvot->bindParam(":aineistotunnus", $kohde_tieto["aineistotunnus"]);
		$arvot->execute();
		$aineisto = $arvot->fetchAll(PDO::FETCH_ASSOC);	
		$kohde_tieto["aineisto"] = $aineisto;
		
		array_push($kohde_tiedot,$kohde_tieto);
	}
	
	$rivi_tieto["kategoria_tiedot"] = $kategoria_tiedot;
	$rivi_tieto["kohde_tiedot"] = $kohde_tiedot;
	array_push($rivi_tiedot,$rivi_tieto);

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;

	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	
	echo json_encode($tiedot);
}
?>