<!DOCTYPE html>
<html lang="fi">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Ulkoile Hallinta</title>
		<link rel="Stylesheet" href="css/jquery-ui.min.css" />
		<link rel="Stylesheet" href="css/font-awesome.min.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet-sidebar.css" />
		<link rel="Stylesheet" href="leaflet/css/Leaflet.PolylineMeasure.css" />
		<link rel="Stylesheet" href="leaflet/css/Leaflet.Weather.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet.draw.css" />
		<link rel="Stylesheet" href="leaflet/css/Leaflet.Dialog.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet-slider.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet-beautify-marker-icon.css" />
		<link rel="Stylesheet" href="leaflet/css/L.Control.MousePosition.css" />
		<link rel="Stylesheet" href="css/normalize.css" />
		<link rel="Stylesheet" href="css/stylesheet.css" />
	</head>
	<body>
		<div id="kirjautumisnakyma">
			<div id="kirjautumisnakyma_kehys">
				<div class="rivi_kehys">
					<i class="kirjautumisnakyma_kuvake fa fa-user"></i>
					<span>Tunnus</span>
					<input id="kirjautumisnakyma_tunnus" value="" />
				</div>
				<div class="rivi_kehys">
					<i class="kirjautumisnakyma_kuvake fa fa-key"></i>
					<span>Salasana</span>
					<input id="kirjautumisnakyma_salasana" type="password" value="" />
				</div>
				<button>Kirjaudu sisään</button>
			</div>
		</div>
		<div id="hallintanakyma"></div>
		
		<script src="js/jquery-3.2.1.min.js"></script>
		<script src="js/jquery-ui.min.js"></script>
		<script src="leaflet/js/leaflet.js"></script>
		<script src="leaflet/js/proj4.min.js"></script>
		<script src="leaflet/js/proj4leaflet.js"></script>
		<script src="leaflet/js/leaflet-sidebar.js"></script>
		<script src="leaflet/js/Leaflet.Weather.js"></script>
		<script src="leaflet/js/Leaflet.PolylineMeasure.js"></script>
		<script src="leaflet/js/Leaflet.Dialog.js"></script>
		<script src="leaflet/js/leaflet-slider.js"></script>
		<script src="leaflet/js/leaflet-beautify-marker-icon.js"></script>
		<script src="leaflet/js/L.Control.MousePosition.js"></script>
		<script src="leaflet/js/togeojson.js"></script>
		<script src="leaflet/js/leaflet.filelayer.js"></script>
		
		<script src="leaflet/js/Leaflet.draw.js"></script>
		<script src="leaflet/js/Control.Draw.js"></script>	
		<script src="leaflet/js/Leaflet.Draw.Event.js"></script>
		<script src="leaflet/js/Toolbar.js"></script>
		<script src="leaflet/js/Tooltip.js"></script>
		<script src="leaflet/js/GeometryUtil.js"></script>
		<script src="leaflet/js/LatLngUtil.js"></script>
		<script src="leaflet/js/LineUtil.Intersect.js"></script>
		<script src="leaflet/js/Polygon.Intersect.js"></script>
		<script src="leaflet/js/Polyline.Intersect.js"></script>
		<script src="leaflet/js/TouchEvents.js"></script>
		<script src="leaflet/js/DrawToolbar.js"></script>
		<script src="leaflet/js/Draw.Feature.js"></script>
		<script src="leaflet/js/Draw.SimpleShape.js"></script>
		<script src="leaflet/js/Draw.Polyline.js"></script>
		<script src="leaflet/js/Draw.Marker.js"></script>
		<script src="leaflet/js/Draw.Circle.js"></script>
		<script src="leaflet/js/Draw.CircleMarker.js"></script>
		<script src="leaflet/js/Draw.Polygon.js"></script>
		<script src="leaflet/js/Draw.Rectangle.js"></script>
		<script src="leaflet/js/EditToolbar.js"></script>
		<script src="leaflet/js/EditToolbar.Edit.js"></script>
		<script src="leaflet/js/EditToolbar.Delete.js"></script>
		<script src="leaflet/js/Edit.Poly.js"></script>
		<script src="leaflet/js/Edit.SimpleShape.js"></script>
		<script src="leaflet/js/Edit.Rectangle.js"></script>
		<script src="leaflet/js/Edit.Marker.js"></script>
		<script src="leaflet/js/Edit.CircleMarker.js"></script>
		<script src="leaflet/js/Edit.Circle.js"></script>
		<script src="leaflet/js/leaflet.snap.js"></script>
		
		<script src="js/core.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				alusta_sivu();
			});
		</script>
	</body>
</html>