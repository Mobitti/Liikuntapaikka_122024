/*************************************************************** MUUTTUJAT *************************************************************************************/
var kayttajatunnus = "";
var kayttajaoikeudet = [];
var kartta_alustettu = false;
var aineisto_alustettu = false;
var kohteet_alustettu = false;
var viestit_alustettu = false;
var tapahtumat_alustettu = false;
var asetukset_alustettu = false;
var kategoriat_alustettu = false;
var tilat_alustettu = false;
var attribuutit_alustettu = false;
var kayttajat_alustettu = false;
var laitteet_alustettu = false;
var huoltoviestit_alustettu = false;
var kaannokset_alustettu = false;
var aineistotunnus_valinnat = [];
var kohde_valinnat = [];
var kohde_tila_valinnat = [];
var kohde_attribuutti_valinnat = [];
var kategoria_valinnat = [];
var kategoria_tila_valinnat = [];
var tila_valinnat = [];
var attribuutti_valinnat = [];
var laite_attribuutti_valinnat = [];
var kaannos_valinnat = [];

var viesti_aihe_valinnat = [
	{"id":1,"nimi":"Kysely"},
	{"id":2,"nimi":"Pyyntö"},
	{"id":3,"nimi":"Palaute"}
];

var tapahtuma_tyyppi_valinnat = [
	{"id":1,"nimi":"Huolto"},
	{"id":2,"nimi":"Muu"}
];

var attribuutti_tyyppi_valinnat = [
	{"id":1,"nimi":"Teksti"},
	{"id":2,"nimi":"Linkki"},
	{"id":3,"nimi":"Kuva"}
];

var oikeus_valinnat = [
	{"id":1,"nimi":"Aineisto"},
	{"id":2,"nimi":"Kohteet"},
	{"id":3,"nimi":"Tapahtumat"},
	{"id":4,"nimi":"Palaute"},
	{"id":5,"nimi":"Asetukset"},
	{"id":6,"nimi":"SMS päivitys"},
	{"id":7,"nimi":"Kohteen tilan vaihto"}
];

var nakyma_oikeudet = [
	{"id":"1","nimi":"Aineisto"},
	{"id":"2","nimi":"Kohteet"},
	{"id":"3","nimi":"Tapahtumat"},
	{"id":"4","nimi":"Palaute"},
	{"id":"5","nimi":"Asetukset"}
];

var kieli_valinnat = [
	{"id":1,"nimi":"Ruotsi"}
];

var karttakomponentti = "";
var karttavalikko = "";
var karttaaineistotaso = "";
var karttaapuaineistotaso = "";
var karttaaineisto = [];
var karttapiirtotaso = "";
var karttapiirtoohjaus = "";
var karttalapinakyvyys = "";
var karttaaineistotiedostolataus = "";
var karttaruutu = "";
var kohdetilaruutu = "";
var valittu_kohde_id = "";
var nykyinen_karttataso = "";
var sisaltotaulu_painike_solu_leveys = "150";
var piirtotoiminto = "";
var kategoria_aineisto_taso = "";
var valittu_kieli = "fi";
var karttakohde_piste = "";

/*************************************************************** FUNKTIOT **************************************************************************************/
function alusta_sivu()
{
	$("#kirjautumisnakyma").show();
	$("#hallintanakyma").html("");
	$("#kirjautumisnakyma input").val("");

	$("#kirjautumisnakyma_kehys button").click(function() {
		tarkista_kayttaja();
	});
	
	$('#kirjautumisnakyma_salasana').keydown(function(painiketapahtuma) {		
		if(painiketapahtuma.which == 13) {
			tarkista_kayttaja();
		}
	});
}

function tarkista_kayttaja()
{
	var toiminnon_siirto = $.Deferred();
	
	var k_tunnus = $("#kirjautumisnakyma_tunnus").val();
	var k_salasana = $("#kirjautumisnakyma_salasana").val();
	
	$.ajax({
		method: "POST",
		url: "php/tarkista_kayttaja.php",
		data: { tunnus:k_tunnus, salasana:k_salasana },
		dataType: "json",
		error: function(pyynto,tila,virhe) {
			toiminnon_siirto.reject();
		},
		success: function(palvelinvastaus,tila,pyynto) {
			var vastaustila = palvelinvastaus.tila;
			var tiedot = palvelinvastaus.rivitiedot;
			
			if(vastaustila.virhe == 1) {
				luo_ilmoitusviesti("virhe",vastaustila.viesti);
				return;
			}
			
			kayttajaoikeudet = tiedot;
			$("#kirjautumisnakyma").hide();
			kayttajatunnus = k_tunnus;
			alusta_hallintanakyma();

			toiminnon_siirto.resolve();
		}
	});
	
	return toiminnon_siirto;
}

function kirjaudu_ulos()
{
	window.location = "index.php";
}

function alusta_hallintanakyma()
{	
	var nakymat = ["Kartta"];
	for(var i = 0; i < nakyma_oikeudet.length; i++)
	{
		if($.inArray(nakyma_oikeudet[i].id,kayttajaoikeudet[0].oikeudet) != -1) {
			nakymat.push(nakyma_oikeudet[i].nimi);
		}
	}

	$("#hallintanakyma").valilehtinakyma(nakymat);
	$(".valilehti_sisaltonakyma").hide();
}

function alusta_nakyma(nakyma_id,nakyma_nimi)
{
	switch(nakyma_nimi)
	{
		case "Kartta": alusta_kartta(nakyma_id); break;
		case "Aineisto": alusta_aineisto(nakyma_id); break;
		case "Kohteet": alusta_kohteet(nakyma_id); break;
		case "Palaute": alusta_viestit(nakyma_id); break;
		case "Tapahtumat": alusta_tapahtumat(nakyma_id); break;
		case "Asetukset": alusta_asetukset(nakyma_id); break;
	}
}

function alusta_kartta(nakyma_id)
{
	if(!kartta_alustettu) {
		$.when(hae_kartta_kohde_tiedot(),hae_kohde_aineistotunnus_valinnat(),hae_tila_valinnat(),hae_kategoria_tila_valinnat()).then(function(kartta_kohde_tiedot) {
			var karttakehys = $("<div class='karttakehys'>"
				+ "<div id='karttavalikko' class='sidebar collapsed'>"
					+ "<div class='logo_kehys'>"
						+ "<img class='logo_kuvake' src='css/images/kokkola_logo.gif' />"
					+ "</div>"
					+ "<div class='sidebar-tabs'>"
						+ "<ul>"
							+ "<li><a id='kohteet' href='#karttavalikko_kohdevalikko'><i class='fa fa-map-signs'></i></a></li>"
							+ "<li><a id='aineisto' href='#karttavalikko_aineisto'><i class='fa fa-map-marker'></i></a></li>"
						+ "</ul>"
					+ "</div>"
					+ "<div class='sidebar-content'>"
						+ "<div class='sidebar-pane karttavalikko_valikko' id='karttavalikko_kohdevalikko'>"
							+ "<h1 class='sidebar-header'>"
								+ "Kohteet"
								+ "<span class='sidebar-close'><i class='fa fa-caret-left'></i></span>"
							+ "</h1>"
							+ "<div id='karttavalikko_kategoriakohteet' class='karttavalikko_sisalto'></div>"
							+ "<div class='karttavalikko_tilat'></div>"
						+ "</div>"
						+ "<div class='sidebar-pane' id='karttavalikko_aineisto'>"
							+ "<h1 class='sidebar-header'>"
								+ "Aineisto"
								+ "<span class='sidebar-close'><i class='fa fa-caret-left'></i></span>"
							+ "</h1>"
							+ "<div id='karttavalikko_aineistokehys' class='karttavalikko_sisalto'>"
								+ "<div class='karttavalikko_aineistorivikehys'>"
									+ "<span class='karttavalikko_aineistootsikko'>Piirtotason apuaineisto</span>"
									+ "<div class='karttavalikko_aineistorivi'>"
										+ "<span class='karttavalikko_aineistoteksti'>Kohde</span>"
										+ "<select id='karttavalikko_aputaso_aineistovalinta'></select>"
									+ "</div>"
									+ "<div class='karttavalikko_aineistorivi'>"
										+ "<span class='karttavalikko_aineistoteksti'>Läpinäkyvyys</span>"
										+ "<input class='karttavalikko_apuaineisto_lapinakyvyys' onchange='aseta_apuaineisto_lapinakyvyys()' value='100' />"
									+ "</div>"
									+ "<div class='karttavalikko_painikekehys'>"
										+ "<i class='karttavalikko_aineistopainike fa fa-search' onclick='nayta_apu_aineisto()' title='Näytä'></i>"
									+ "</div>"
								+ "</div>"
								+ "<div class='karttavalikko_aineistorivikehys'>"
									+ "<span class='karttavalikko_aineistootsikko'>Aineiston kopiointi</span>"
									+ "<div class='karttavalikko_aineistorivi'>"
										+ "<span class='karttavalikko_aineistoteksti'>Lähde</span>"
										+ "<select id='karttavalikko_aineistovalinta_lahde'></select>"
									+ "</div>"
									+ "<div class='karttavalikko_aineistorivi'>"
										+ "<span class='karttavalikko_aineistoteksti'>Kohde</span>"
										+ "<select id='karttavalikko_aineistovalinta_kohde'></select>"
									+ "</div>"
									+ "<div class='karttavalikko_painikekehys'>"
										+ "<i class='karttavalikko_aineistopainike fa fa-files-o' onclick='kopioi_kartta_aineisto()' title='Kopioi'></i>"
									+ "</div>"
									+ "<span>Huom! Valitun kohteen aineiston tiedot korvataan kopioitavalla aineistolla.</span>"
								+ "</div>"
								+ "<div class='karttavalikko_aineistorivikehys'>"
									+ "<span class='karttavalikko_aineistootsikko'>Piste aineiston näyttö</span>"
									+ "<div class='karttavalikko_aineistorivi'>"
										+ "<span class='karttavalikko_aineistoteksti'>Aineistotyyppi</span>"
										+ "<select class='karttavalikko_aineistotyyppi_valinta'>"
											+ "<option value=''>Piilota aineisto</option>"
											+ "<option value='60000'>Ulkoilumerkit</option>"
											+ "<option value='60696'>Kuntoradat</option>"
											+ "<option value='60695'>Hevosreitit</option>"
											+ "<option value='60694'>Maastopyöräilyreitti</option>"
											+ "<option value='60693'>Pyöräilyreitti</option>"
											+ "<option value='60692'>Melontareitti</option>"
											+ "<option value='60691'>Veneilyreitti</option>"
											+ "<option value='60690'>Latu jäällä</option>"
											+ "<option value='60683'>Luontopolku</option>"
											+ "<option value='60682'>Ulkoilureitti</option>"
											+ "<option value='60681'>Valaistu latu</option>"
											+ "<option value='60680'>Latu</option>"
										+ "</select>"
									+ "</div>"
									+ "<div class='karttavalikko_aineistorivi'>"
										+ "<span class='karttavalikko_aineistoteksti'>Läpinäkyvyys</span>"
										+ "<input class='karttavalikko_aineisto_lapinakyvyys' onchange='aseta_aineisto_lapinakyvyys()' value='100' />"
									+ "</div>"
									+ "<div class='karttavalikko_painikekehys'>"
										+ "<i class='karttavalikko_aineistopainike fa fa-map-pin' onclick='hae_aineisto_pisteet()' title='Näytä'></i>"
									+ "</div>"
								+ "</div>"
							+ "</div>"
						+ "</div>"
					+ "</div>"
				+ "</div>"
				+ "<div id='karttakomponentti' class='karttakomponentti sidebar-map'></div>"
			+ "</div>");
			
			$("#valilehti_sisaltonakyma_" + nakyma_id).append(karttakehys);
			
			$(".logo_kuvake").hide();
			
			$("#karttavalikko_aineistovalinta_lahde").html("<option value=''>Valitse</option>");
			$("#karttavalikko_aineistovalinta_kohde").html("<option value=''>Valitse</option>");
			$("#karttavalikko_aputaso_aineistovalinta").html("<option value=''>Piilota</option>");
			
			$("#karttavalikko_aineistovalinta_lahde").change(function() {
				$(this).removeClass("karttavalikko_kenttavirhe");
			});
			
			$("#karttavalikko_aineistovalinta_kohde").change(function() {
				$(this).removeClass("karttavalikko_kenttavirhe");
			});
			
			for(var i = 0; i < tila_valinnat.length; i++)
			{
				$(".karttavalikko_tilat").append(
					"<div class='karttavalikko_tila_kehys'>"
						+ "<i class='karttavalikko_tila_kuvake fa fa-square' style='color:rgb(" + tila_valinnat[i].vari + ")'></i>"
						+ "<span class='karttavalikko_tila_teksti'>" + tila_valinnat[i].nimi + "</span>"
					+ "</div>"
				);
			}
			
			for(var i = 0; i < aineistotunnus_valinnat.length; i++)
			{
				$("#karttavalikko_aineistovalinta_lahde").append("<option value='" + aineistotunnus_valinnat[i]["id"] + "'>" + aineistotunnus_valinnat[i]["nimi"] + "</option>");
				$("#karttavalikko_aineistovalinta_kohde").append("<option value='" + aineistotunnus_valinnat[i]["id"] + "'>" + aineistotunnus_valinnat[i]["nimi"] + "</option>");
				$("#karttavalikko_aputaso_aineistovalinta").append("<option value='" + aineistotunnus_valinnat[i]["id"] + "'>" + aineistotunnus_valinnat[i]["nimi"] + "</option>");
			}
			
			karttakomponentti = L.map("karttakomponentti", {
				crs: new L.Proj.CRS("urn:ogc:def:crs:EPSG::3877","+proj=tmerc +lat_0=0 +lon_0=23 +k=1 +x_0=23500000 +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs",{
					resolutions: [
						8192, 4096, 2048, 1024, 512, 256, 128,
						64, 32, 16, 8, 4, 2, 1, 0.5
					]
				}),
				maxBounds: L.latLngBounds(L.latLng(63.12,22.54),L.latLng(64.12,25.10)),
				attributionControl: false,
				zoomControl: false
			});
			
			var opaskartta = L.tileLayer.wms("https://kartta.kokkola.fi/TeklaOgcWeb/WMS.ashx?", {
				layers: 'Opaskartta', 
				format: 'image/png',
				maxZoom: 13,
				minZoom: 7
			});

			var ilmakuva = L.tileLayer.wms("https://kartta.kokkola.fi/TeklaOgcWeb/WMS.ashx?", {
				layers: 'Ilmakuva',
				format: 'image/png',
				minZoom: 8
			});

			var peruskartta = L.tileLayer.wms("https://kartta.kokkola.fi/TeklaOgcWeb/WMS.ashx?", {
				layers: 'Peruskartta',
				format: 'image/png',
				minZoom: 7
			});
			
			karttakomponentti.addLayer(opaskartta);
			nykyinen_karttataso = opaskartta;
			karttakomponentti.setView([63.85, 23.25],9);
			
			karttakohde_piste = L.icon({
				iconUrl: "css/images/mapmarker.png",
				iconSize: [40,40],
				iconAnchor: [20,39]
			});
			
			var tasot = {"Opaskartta":opaskartta,"Ilmakuva":ilmakuva,"Peruskartta":peruskartta};
			karttapiirtotaso = L.featureGroup().addTo(karttakomponentti);
			karttaaineistotaso = L.featureGroup().addTo(karttakomponentti);
			karttaapuaineistotaso = L.featureGroup().addTo(karttakomponentti);
			L.control.layers(tasot,{"Piirtotaso":karttapiirtotaso,"Piirto-aputaso":karttaapuaineistotaso,"Aineisto":karttaaineistotaso},{position:"topleft"}).addTo(karttakomponentti);
			if(L.Browser.touch) {
				$(".leaflet-control-layers-toggle").css({
					"width":"30px",
					"height":"30px",
					"line-height":"30px"
				});
			}
			else {
				$(".leaflet-control-layers-toggle").css({
					"width":"26px",
					"height":"26px",
					"line-height":"26px"
				});
			}
			karttalapinakyvyys = L.control.slider(
				function(lapinakyvyys) { 
					$(karttalapinakyvyys.slider).val(lapinakyvyys); 
					nykyinen_karttataso.setOpacity(lapinakyvyys/100); 
				}, {
				size: "200px",
				position:"topleft",
				min:0,
				max:100,
				step:10,
				value:100,
				title:"Kartan läpinäkyvyys",
				logo:"<i class='fa fa-adjust'></i>",
				showValue:true
			}).addTo(karttakomponentti);
			if(L.Browser.touch) {
				$(".leaflet-control-slider-toggle").css({
					"width":"30px",
					"height":"30px",
					"line-height":"30px",
				});
			}
			else {
				$(".leaflet-control-slider-toggle").css({
					"width":"26px",
					"height":"26px",
					"line-height":"26px",
				});
				$(".leaflet-control-slider").css({
					"border":"none",
				});
			}
			L.control.zoom({zoomInTitle:"Lähennä", zoomOutTitle:"Loitonna"}).addTo(karttakomponentti);
			L.control.polylineMeasure({position: 'topleft', imperial:false}).addTo(karttakomponentti);
			var saaPainike = $(
				"<div class='leaflet-control-weather-button leaflet-control leaflet-bar'>"
				+ "<a href='#' title='Sää / Väder'><i class='fa fa-sun-o'></i></a>"
			);
			$(".leaflet-top.leaflet-left").append(saaPainike);
			L.DomEvent.disableClickPropagation($(".leaflet-control-weather-button")[0]);
			L.DomEvent.disableClickPropagation($(".leaflet-control-weather-button a")[0]);
			$(".leaflet-control-weather-button a").click(function() {
				if($(".leaflet-control-weather").css("display") == "none") {
					$(".leaflet-control-weather").show();
				}
				else {
					$(".leaflet-control-weather").hide();
				}
			})
			L.control.weather({lang:"fi", units:"metric", cityid:"651951", appid:"e565305875183227d1923fda2a77e904"}).addTo(karttakomponentti);
			$(".leaflet-control-weather").hide();
			L.control.scale({position:'bottomright', imperial:false}).addTo(karttakomponentti);
			$(".leaflet-control-scale").css({"clear":"none"});
			L.control.mousePosition({position:"bottomright",emptystring:"Ei saatavilla"}).addTo(karttakomponentti);
			$(".leaflet-control-mouseposition").css({"clear":"none"});
			karttaruutu = L.control.dialog({initOpen:false, size:[450,75], anchor:[5,500]}).addTo(karttakomponentti);
			kohdetilaruutu = L.control.dialog({initOpen:false, size:[550,350], anchor:[250,250]});
			kohdetilaruutu.setContent(
				"<span class='kohdetilaruutu_teksti'></span>"
				+ "<select class='kohdetilaruutu_valinta' onchange='kohdetilaruutu_poista_virhe()'></select>"
				+ "<span class='piilotettu kohdetilaruutu_kohde_id'></span>"
				+ "<div class='kohdetilaruutu_painikekehys'>"
					+ "<i class='kohdetilaruutu_peruuta_painike fa fa-ban' title='Peruuta' onclick='sulje_kohdetilaruutu()'></i>"
					+ "<i class='kohdetilaruutu_tallenna_painike fa fa-floppy-o' title='Aseta tila' onclick='aseta_kohteen_tila()'></i>"
				+ "</div>"
			);
			kohdetilaruutu.addTo(karttakomponentti);
			
			karttavalikko = L.control.sidebar("karttavalikko").addTo(karttakomponentti);
			karttavalikko.on("closing",function() {
				$(".logo_kuvake").hide();
			});
			karttavalikko.on("opening",function() {
				$(".logo_kuvake").show();
			});
			$(".sidebar-tabs").css({"top":"100px"});
			$(".sidebar-content").css({"top":"100px"});
			
			karttapiirtoohjaus = new L.Control.Draw({
				draw: {
					polygon: false,
					rectangle: false,
					circle: false,
					circlemarker: false,
					polyline: {
						shapeOptions: {
							opacity: 1
						}
					}
				},
				edit: {
					featureGroup: karttapiirtotaso
				}
			}).addTo(karttakomponentti);
			$(".leaflet-draw-section").hide();
			
			karttakomponentti.on(L.Draw.Event.CREATED, function(tapahtuma) {
				var taso = tapahtuma.layer;
				karttapiirtotaso.addLayer(taso);
				tallenna_kartta_aineisto(taso.toGeoJSON());
				$(".leaflet-draw-draw-polyline, .leaflet-draw-draw-marker").hide();

				if(valittu_kohde_id in karttaaineisto) {
					for(var j = 0; j < karttaaineisto[valittu_kohde_id].length; j++)
					{
						if(karttaaineistotaso.hasLayer(karttaaineisto[valittu_kohde_id][j])) {
							karttaaineistotaso.removeLayer(karttaaineisto[valittu_kohde_id][j]);
						}
					}
				}
				
				var koordinaatit = [];
				if(taso.toGeoJSON().geometry.type == "Point") {
					koordinaatit.push(taso.toGeoJSON().geometry.coordinates);
				}
				else {
					koordinaatit = taso.toGeoJSON().geometry.coordinates;
				}

				var pisteet = [];
				for(var j = 0; j < koordinaatit.length; j++)
				{
					pisteet.push({"leveysaste":koordinaatit[j][1],"pituusaste":koordinaatit[j][0]});
				}

				$("#karttavalikko_kohde_" + valittu_kohde_id).data("aineisto",pisteet);
				
				if(taso.toGeoJSON().geometry.type == "Point") {
					var kartta_kohde = L.marker([pisteet[0].leveysaste,pisteet[0].pituusaste], {});
					karttaaineistotaso.addLayer(kartta_kohde);
					karttaaineisto[valittu_kohde_id] = [kartta_kohde];
				}
				else if(taso.toGeoJSON().geometry.type == "LineString") {
					var kartta_kohde_alku = L.marker([pisteet[0].leveysaste,pisteet[0].pituusaste], {
						icon: karttakohde_piste 
						/*L.BeautifyIcon.icon({
							icon: 'flag',
							iconShape: 'marker',
							textColor: "green"
						})
						*/
					});
					var kartta_kohde_loppu = L.marker([pisteet[pisteet.length - 1].leveysaste,pisteet[pisteet.length - 1].pituusaste], {
						icon: karttakohde_piste 
						/*L.BeautifyIcon.icon({
							icon: 'flag',
							iconShape: 'marker',
							textColor: "red"
						})
						*/
					});

					var kohde_koordinaatti_pisteet = [];
					for(var j = 0; j < pisteet.length; j++)
					{
						kohde_koordinaatti_pisteet.push([pisteet[j].leveysaste,pisteet[j].pituusaste]);
					}

					var kartta_kohde = L.polyline(kohde_koordinaatti_pisteet, {});
					var kohde_nimi = $("#karttavalikko_kohde_" + valittu_kohde_id).children(".karttavalikko_kohde_teksti").html();
					var kohde_kuvaus = $("#karttavalikko_kohde_" + valittu_kohde_id).data("kuvaus");
					kartta_kohde.bindPopup("<b>" + kohde_nimi + "</b></br>" + kohde_kuvaus);
					karttaaineistotaso.addLayer(kartta_kohde);
					karttaaineistotaso.addLayer(kartta_kohde_alku);
					karttaaineistotaso.addLayer(kartta_kohde_loppu);
					karttaaineisto[valittu_kohde_id] = [kartta_kohde,kartta_kohde_alku,kartta_kohde_loppu];
				}

				var kohde_nakyvyys = $("#karttavalikko_kohde_" + valittu_kohde_id).children(".karttavalikko_kohde_nakyvyys");
				if(kohde_nakyvyys.hasClass("fa-square-o")) {
					kohde_nakyvyys.removeClass("fa-square-o");
					kohde_nakyvyys.addClass("fa-check-square-o");
				}
			});
			
			karttakomponentti.on(L.Draw.Event.EDITED, function(tapahtuma) {
				karttapiirtotaso.eachLayer(function(taso) {
					tallenna_kartta_aineisto(taso.toGeoJSON());
					
					if(valittu_kohde_id in karttaaineisto) {
						for(var j = 0; j < karttaaineisto[valittu_kohde_id].length; j++)
						{
							if(karttaaineistotaso.hasLayer(karttaaineisto[valittu_kohde_id][j])) {
								karttaaineistotaso.removeLayer(karttaaineisto[valittu_kohde_id][j]);
							}
						}
					}
					
					var koordinaatit = [];
					if(taso.toGeoJSON().geometry.type == "Point") {
						koordinaatit.push(taso.toGeoJSON().geometry.coordinates);
					}
					else {
						koordinaatit = taso.toGeoJSON().geometry.coordinates;
					}
				
					var pisteet = [];
					for(var j = 0; j < koordinaatit.length; j++)
					{
						pisteet.push({"leveysaste":koordinaatit[j][1],"pituusaste":koordinaatit[j][0]});
					}
					$("#karttavalikko_kohde_" + valittu_kohde_id).data("aineisto",pisteet);
					
					if(taso.toGeoJSON().geometry.type == "Point") {
						var kartta_kohde = L.marker([pisteet[0].leveysaste,pisteet[0].pituusaste], {});
						karttaaineistotaso.addLayer(kartta_kohde);
						karttaaineisto[valittu_kohde_id] = [kartta_kohde];
					}
					else if(taso.toGeoJSON().geometry.type == "LineString") {
						var kartta_kohde_alku = L.marker([pisteet[0].leveysaste,pisteet[0].pituusaste], {
							icon: karttakohde_piste 
							/* L.BeautifyIcon.icon({
								icon: 'flag',
								iconShape: 'marker',
								textColor: "green"
							})
							*/
						});
						var kartta_kohde_loppu = L.marker([pisteet[pisteet.length - 1].leveysaste,pisteet[pisteet.length - 1].pituusaste], {
							icon: karttakohde_piste 
							/* L.BeautifyIcon.icon({
								icon: 'flag',
								iconShape: 'marker',
								textColor: "red"
							})
							*/
						});
						
						var kohde_koordinaatti_pisteet = [];
						for(var j = 0; j < pisteet.length; j++)
						{
							kohde_koordinaatti_pisteet.push([pisteet[j].leveysaste,pisteet[j].pituusaste]);
						}

						var kartta_kohde = L.polyline(kohde_koordinaatti_pisteet, {});
						var kohde_nimi = $("#karttavalikko_kohde_" + valittu_kohde_id).children(".karttavalikko_kohde_teksti").html();
						var kohde_kuvaus = $("#karttavalikko_kohde_" + valittu_kohde_id).data("kuvaus");
						kartta_kohde.bindPopup("<b>" + kohde_nimi + "</b></br>" + kohde_kuvaus);
						karttaaineistotaso.addLayer(kartta_kohde);
						karttaaineistotaso.addLayer(kartta_kohde_alku);
						karttaaineistotaso.addLayer(kartta_kohde_loppu);
						karttaaineisto[valittu_kohde_id] = [kartta_kohde,kartta_kohde_alku,kartta_kohde_loppu];
					}

					var kohde_nakyvyys = $("#karttavalikko_kohde_" + valittu_kohde_id).children(".karttavalikko_kohde_nakyvyys");
					if(kohde_nakyvyys.hasClass("fa-square-o")) {
						kohde_nakyvyys.removeClass("fa-square-o");
						kohde_nakyvyys.addClass("fa-check-square-o");
					}
				});
			});
			
			karttakomponentti.on(L.Draw.Event.DELETED, function(tapahtuma) {
				tallenna_kartta_aineisto("");
				$(".leaflet-draw-draw-polyline, .leaflet-draw-draw-marker").show();
				$(".leaflet-control-filelayer").show();
				if(valittu_kohde_id in karttaaineisto) {
					for(var j = 0; j < karttaaineisto[valittu_kohde_id].length; j++)
					{
						if(karttaaineistotaso.hasLayer(karttaaineisto[valittu_kohde_id][j])) {
							karttaaineistotaso.removeLayer(karttaaineisto[valittu_kohde_id][j]);
						}
					}
				}
				
				$("#karttavalikko_kohde_" + valittu_kohde_id).data("aineisto",[]);
				var kohde_nakyvyys = $("#karttavalikko_kohde_" + valittu_kohde_id).children(".karttavalikko_kohde_nakyvyys");
				if(kohde_nakyvyys.hasClass("fa-check-square-o")) {
					kohde_nakyvyys.removeClass("fa-check-square-o");
					kohde_nakyvyys.addClass("fa-square-o");
				}
			});
			
			karttaaineistotiedostolataus = L.Control.fileLayerLoad({
				layer: L.geoJson,
				addToMap: false
			}).addTo(karttakomponentti);
			
			karttaaineistotiedostolataus.loader.on("data:loaded",function(tapahtuma) {
				var gpx_koordinaatit = tapahtuma.layer.toGeoJSON().features[0].geometry.coordinates;
				var gpx_pisteet = [];
				for(var j = 0; j < gpx_koordinaatit.length; j++)
				{
					gpx_pisteet.push([gpx_koordinaatit[j][1],gpx_koordinaatit[j][0]]);
				}
				var taso = L.polyline(gpx_pisteet);
				karttapiirtotaso.addLayer(taso);
				tallenna_kartta_aineisto(taso.toGeoJSON());
				$(".leaflet-draw-draw-polyline, .leaflet-draw-draw-marker").hide();

				if(valittu_kohde_id in karttaaineisto) {
					for(var j = 0; j < karttaaineisto[valittu_kohde_id].length; j++)
					{
						if(karttaaineistotaso.hasLayer(karttaaineisto[valittu_kohde_id][j])) {
							karttaaineistotaso.removeLayer(karttaaineisto[valittu_kohde_id][j]);
						}
					}
				}
				
				var koordinaatit = [];
				if(taso.toGeoJSON().geometry.type == "Point") {
					koordinaatit.push(taso.toGeoJSON().geometry.coordinates);
				}
				else {
					koordinaatit = taso.toGeoJSON().geometry.coordinates;
				}

				var pisteet = [];
				for(var j = 0; j < koordinaatit.length; j++)
				{
					pisteet.push({"leveysaste":koordinaatit[j][1],"pituusaste":koordinaatit[j][0]});
				}

				$("#karttavalikko_kohde_" + valittu_kohde_id).data("aineisto",pisteet);
				
				if(taso.toGeoJSON().geometry.type == "Point") {
					var kartta_kohde = L.marker([pisteet[0].leveysaste,pisteet[0].pituusaste], {});
					karttaaineistotaso.addLayer(kartta_kohde);
					karttaaineisto[valittu_kohde_id] = [kartta_kohde];
				}
				else if(taso.toGeoJSON().geometry.type == "LineString") {
					var kartta_kohde_alku = L.marker([pisteet[0].leveysaste,pisteet[0].pituusaste], {
						icon: karttakohde_piste
						/* L.BeautifyIcon.icon({
							icon: 'flag',
							iconShape: 'marker',
							textColor: "green"
						})
						*/
					});
					var kartta_kohde_loppu = L.marker([pisteet[pisteet.length - 1].leveysaste,pisteet[pisteet.length - 1].pituusaste], {
						icon: karttakohde_piste 
						/* L.BeautifyIcon.icon({
							icon: 'flag',
							iconShape: 'marker',
							textColor: "red"
						})
						*/
					});

					var kohde_koordinaatti_pisteet = [];
					for(var j = 0; j < pisteet.length; j++)
					{
						kohde_koordinaatti_pisteet.push([pisteet[j].leveysaste,pisteet[j].pituusaste]);
					}

					var kartta_kohde = L.polyline(kohde_koordinaatti_pisteet, {});
					var kohde_nimi = $("#karttavalikko_kohde_" + valittu_kohde_id).children(".karttavalikko_kohde_teksti").html();
					var kohde_kuvaus = $("#karttavalikko_kohde_" + valittu_kohde_id).data("kuvaus");
					kartta_kohde.bindPopup("<b>" + kohde_nimi + "</b></br>" + kohde_kuvaus);
					karttaaineistotaso.addLayer(kartta_kohde);
					karttaaineistotaso.addLayer(kartta_kohde_alku);
					karttaaineistotaso.addLayer(kartta_kohde_loppu);
					karttaaineisto[valittu_kohde_id] = [kartta_kohde,kartta_kohde_alku,kartta_kohde_loppu];
				}

				var kohde_nakyvyys = $("#karttavalikko_kohde_" + valittu_kohde_id).children(".karttavalikko_kohde_nakyvyys");
				if(kohde_nakyvyys.hasClass("fa-square-o")) {
					kohde_nakyvyys.removeClass("fa-square-o");
					kohde_nakyvyys.addClass("fa-check-square-o");
				}
			});
			
			karttaaineistotiedostolataus.loader.on("data:error",function(virhe) {
				luo_ilmoitusviesti("virhe","tiedoston lataus epäonnistui");
			});
			
			$(".leaflet-control-filelayer").hide();
			
			karttakomponentti.on("baselayerchange", function(tapahtuma) {
				karttalapinakyvyys.setValue(100);
				nykyinen_karttataso = tapahtuma.layer;
				nykyinen_karttataso.setOpacity(1);
			});
		
			karttakomponentti.on("dialog:closed",function() { 
				$("#karttavalikko").show();
				karttapiirtotaso.clearLayers();
				
				if(!karttakomponentti.hasLayer(karttaaineistotaso)) {
					karttaaineistotaso.addTo(karttakomponentti); 
				}
				$(".leaflet-draw-section").hide();
				$(".leaflet-control-filelayer").hide();
				
				var tyokalurivit = karttapiirtoohjaus._toolbars;
				for(var tyyppi in tyokalurivit) 
				{
					tyokalurivit[tyyppi].disable();
				}
			});
			
			aseta_karttavalikko_kohde_tiedot(kartta_kohde_tiedot);
			
			kartta_alustettu = true;
		});
	}
	else {
		$.when(hae_kartta_kohde_tiedot(),hae_kohde_aineistotunnus_valinnat(),hae_tila_valinnat(),hae_kategoria_tila_valinnat()).then(function(kartta_kohde_tiedot) {
			karttaruutu.close();
			kohdetilaruutu.close();
			karttavalikko.close();
			$(".logo_kuvake").hide();
			karttaaineistotaso.clearLayers();
			karttaaineisto = [];
			$("#karttavalikko_kategoriakohteet").html("");
			$("#karttavalikko_aineistovalinta_lahde").html("<option value=''>Valitse</option>");
			$("#karttavalikko_aineistovalinta_kohde").html("<option value=''>Valitse</option>");
			$("#karttavalikko_aputaso_aineistovalinta").html("<option value=''>Piilota</option>");
			
			for(var i = 0; i < aineistotunnus_valinnat.length; i++)
			{
				$("#karttavalikko_aineistovalinta_lahde").append("<option value='" + aineistotunnus_valinnat[i]["id"] + "'>" + aineistotunnus_valinnat[i]["nimi"] + "</option>");
				$("#karttavalikko_aineistovalinta_kohde").append("<option value='" + aineistotunnus_valinnat[i]["id"] + "'>" + aineistotunnus_valinnat[i]["nimi"] + "</option>");
				$("#karttavalikko_aputaso_aineistovalinta").append("<option value='" + aineistotunnus_valinnat[i]["id"] + "'>" + aineistotunnus_valinnat[i]["nimi"] + "</option>");
			}	

			aseta_karttavalikko_kohde_tiedot(kartta_kohde_tiedot);
		});
	}
}

function aseta_karttavalikko_kohde_tiedot(tiedot)
{
	$("#karttavalikko_kategoriakohteet").html("");
	var kategoria_tiedot = tiedot[0].kategoria_tiedot;
	var kohde_tiedot = tiedot[0].kohde_tiedot;
	
	var karttavalikko_kategoriat = [];
	for(var i = 0; i < kategoria_tiedot.length; i++)
	{
		var karttavalikko_kategoria_nakyvyys = $("<i class='karttavalikko_kategoria_nakyvyys fa fa-plus'></i>");
		
		var karttavalikko_kategoria = $("<div id='karttavalikko_kategoria_" + kategoria_tiedot[i].kategoria_id + "' class='karttavalikko_kategoria'>"
			+ "<span class='karttavalikko_kategoria_teksti'>" + kategoria_tiedot[i].nimi + "</span>"
			+ "<div class='karttavalikko_kohteet'></div>"
			+ "<div class='karttavalikko_alakategoriat'></div>"
		+ "</div>");
		
		karttavalikko_kategoria.prepend(karttavalikko_kategoria_nakyvyys);
		
		karttavalikko_kategoria_nakyvyys.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			if($(this).hasClass("fa-plus")) {
				$(this).removeClass("fa-plus");
				$(this).addClass("fa-minus");
				
				$(this).closest(".karttavalikko_kategoria").children(".karttavalikko_alakategoriat").show();
				$(this).closest(".karttavalikko_kategoria").children(".karttavalikko_kohteet").show();
			}
			else {
				$(this).removeClass("fa-minus");
				$(this).addClass("fa-plus");
				
				$(this).closest(".karttavalikko_kategoria").find(".karttavalikko_alakategoriat").hide();
				$(this).closest(".karttavalikko_kategoria").find(".karttavalikko_kohteet").hide();
				$(this).closest(".karttavalikko_kategoria").find(".fa-minus").removeClass("fa-minus").addClass("fa-plus");
			}
		});
		
		$('#karttavalikko_kategoriakohteet').append(karttavalikko_kategoria);
		karttavalikko_kategoria.find(".karttavalikko_alakategoriat").hide();
		karttavalikko_kategoria.find(".karttavalikko_kohteet").hide();
		
		karttavalikko_kategoriat.push(karttavalikko_kategoria);
	}

	for(var i = 0; i < kategoria_tiedot.length; i++)
	{
		if(kategoria_tiedot[i].taso_id != 0) { 
			$('#karttavalikko_kategoria_' + kategoria_tiedot[i].kategoria_id).appendTo($('#karttavalikko_kategoria_' + kategoria_tiedot[i].taso_id + " > .karttavalikko_alakategoriat"));
			var taso_siirto = $('#karttavalikko_kategoria_' + kategoria_tiedot[i].kategoria_id).parents(".karttavalikko_kategoria").length * 10;
			$('#karttavalikko_kategoria_' + kategoria_tiedot[i].kategoria_id).css({"margin-left":taso_siirto + "px"});
		}
	}
	
	for(var i = 0; i < kohde_tiedot.length; i++)
	{
		var karttavalikko_kohde_nakyvyys = $("<i class='karttavalikko_kohde_nakyvyys fa fa-square-o'></i>");
		var karttavalikko_kohde_muokkaa = $("<i class='karttavalikko_kohde_aineisto fa fa-map-marker'></i>");
		var karttavalikko_kohde_tila_teksti = kohde_tiedot[i].tila_nimi;
		if(kohde_tiedot[i].huoltotapahtuma.length > 0) {
			karttavalikko_kohde_tila_teksti += ", " + kohde_tiedot[i].huoltotapahtuma[0].aikaleima;
		}
		
		var karttavalikko_kohde = $(
			"<div id='karttavalikko_kohde_" + kohde_tiedot[i].kohde_id + "' class='karttavalikko_kohde'>"
				+ "<span class='karttavalikko_kohde_teksti'>" + kohde_tiedot[i].nimi + "</span>"
				+ "<i class='karttavalikko_kohde_tila fa fa-square' style='color:rgb(" + kohde_tiedot[i].tila_vari + ")' title='" + karttavalikko_kohde_tila_teksti + "'></i>"
				+ "<div class='karttavalikko_kohde_lisatiedot'>"
					+ "<span class='karttavalikko_kohde_lisatieto_teksti'>" + karttavalikko_kohde_tila_teksti + "</span>"
					+ "<span class='karttavalikko_kohde_lisatieto_teksti'>" + kohde_tiedot[i].kuvaus + "</span>"
					+ "<div class='karttavalikko_kohde_attribuutit'></div>"
				+ "</div>"
			+ "</div>"
		);
		
		var kohde_attribuutit = kohde_tiedot[i].attribuutit;
		for(var j = 0; j < kohde_attribuutit.length; j++)
		{
			if(kohde_attribuutit[j].tyyppi == 1) {
				karttavalikko_kohde.children(".karttavalikko_kohde_lisatiedot").children(".karttavalikko_kohde_attribuutit").append(
					"<div class='karttavalikko_kohde_attribuutti'>"
						+ "<span class='karttavalikko_kohde_attribuutti_nimi'>" + kohde_attribuutit[j].nimi + ":</span>"
						+ "<span class='karttavalikko_kohde_attribuutti_arvo'>" + kohde_attribuutit[j].arvo + "</span>"
					+ "</div>"
				);
			}
				
			if(kohde_attribuutit[j].tyyppi == 2 || kohde_attribuutit[j].tyyppi == 3) {
				karttavalikko_kohde.children(".karttavalikko_kohde_lisatiedot").children(".karttavalikko_kohde_attribuutit").append(
					"<div class='karttavalikko_kohde_attribuutti'>"
						+ "<a class='karttavalikko_kohde_attribuutti_linkki' href='" + kohde_attribuutit[j].arvo + "' target='_blank'>" + kohde_attribuutit[j].nimi + "</a>"
					+ "</div>"
				);
			}
			/*
			if(kohde_attribuutit[j].tyyppi == 3) {
				karttavalikko_kohde.children(".karttavalikko_kohde_lisatiedot").children(".karttavalikko_kohde_attribuutit").append(
					"<div class='karttavalikko_kohde_attribuutti'>"
						+ "<a class='karttavalikko_kohde_attribuutti_linkki' href='" + kohde_attribuutit[j].arvo + "' target='_blank'>" + kohde_attribuutit[j].nimi + "</a>" 
					+ "</div>"
				);
			}
			*/
		}
		
		karttavalikko_kohde.data("kohde_id",kohde_tiedot[i].kohde_id);
		karttavalikko_kohde.data("aineistotunnus",kohde_tiedot[i].aineistotunnus);
		karttavalikko_kohde.data("aineisto",kohde_tiedot[i].aineisto);
		karttavalikko_kohde.data("attribuutit",kohde_tiedot[i].attribuutit);
		karttavalikko_kohde.data("kuvaus",kohde_tiedot[i].kuvaus);
		karttavalikko_kohde.data("vari",kohde_tiedot[i].tila_vari);
		karttavalikko_kohde.data("tila",karttavalikko_kohde_tila_teksti);
		karttavalikko_kohde.data("tila_id",kohde_tiedot[i].tila_id);
		karttavalikko_kohde.data("kategoria_id",kohde_tiedot[i].kategoria_id);
		
		karttavalikko_kohde.prepend(karttavalikko_kohde_nakyvyys);
		karttavalikko_kohde.children(".karttavalikko_kohde_tila").after(karttavalikko_kohde_muokkaa);
		
		$("#karttavalikko_kategoria_" + kohde_tiedot[i].kategoria_id).children(".karttavalikko_kohteet").append(karttavalikko_kohde);
		
		karttavalikko_kohde.children(".karttavalikko_kohde_lisatiedot").hide();
		
		karttavalikko_kohde.children(".karttavalikko_kohde_teksti").click(function() {
			if($(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_lisatiedot").css("display") == "none") {
				$(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_lisatiedot").show();
			}
			else {
				$(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_lisatiedot").hide();
			}
		});
		
		if($.inArray("7",kayttajaoikeudet[0].oikeudet) != -1) {
			karttavalikko_kohde.children(".karttavalikko_kohde_tila").css("cursor","pointer");
			karttavalikko_kohde.children(".karttavalikko_kohde_tila").click(function() {
				var kohde = $(this).closest(".karttavalikko_kohde");
				var kohde_id = kohde.data("kohde_id");
				var kohde_nimi = $(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_teksti").html();
				var kohde_tila = "-";
				if(kohde.data("tila") != "") {
					kohde_tila = kohde.data("tila");
				}
				var kohde_tila_id = kohde.data("tila_id");
				var kategoria_id = kohde.data("kategoria_id");
				var tila_valinta_teksti = "<option value=''>Valitse</option>";
				var kategorian_tila_valinnat = [];
				for(var i = 0; i < kategoria_tila_valinnat.length; i++)
				{
					if(kategoria_id == kategoria_tila_valinnat[i]["tieto1_id"]) {
						kategorian_tila_valinnat.push(kategoria_tila_valinnat[i]["tieto2_id"]);
					}
				}

				for(var i = 0; i < tila_valinnat.length; i++)
				{
					if($.inArray(tila_valinnat[i].id,kategorian_tila_valinnat) != -1) {
						tila_valinta_teksti += "<option value='" + tila_valinnat[i]["id"] + "'>" + tila_valinnat[i]["nimi"] + "</option>";
					}
				}
				
				$(".kohdetilaruutu_teksti").html(kohde_nimi + " tilassa " + kohde_tila);
				$(".kohdetilaruutu_valinta").html(tila_valinta_teksti);
				$(".kohdetilaruutu_kohde_id").html(kohde_id);
				kohdetilaruutu.open();
			});
		}
			
		
		karttavalikko_kohde_muokkaa.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			
			if(karttakomponentti.hasLayer(karttaaineistotaso)) {
				karttakomponentti.removeLayer(karttaaineistotaso);
			}
			karttapiirtotaso.clearLayers();
			valittu_kohde_id = $(this).closest(".karttavalikko_kohde").data("kohde_id");
			var kohde_nimi = $(this).closest(".karttavalikko_kohde").find(".karttavalikko_kohde_teksti").html();
			var kohde_aineisto = $(this).closest(".karttavalikko_kohde").data("aineisto");
			
			if(kohde_aineisto.length == 1) {
				var kartta_kohde = L.marker([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste], {});
				karttapiirtotaso.addLayer(kartta_kohde);
				karttakomponentti.setView([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste]);
				$(".leaflet-draw-draw-polyline, .leaflet-draw-draw-marker").hide();
				$(".leaflet-control-filelayer").hide();
			}
			else if(kohde_aineisto.length > 1) {
				var pisteet = [];
				for(var k = 0; k < kohde_aineisto.length; k++)
				{
					pisteet.push([kohde_aineisto[k].leveysaste,kohde_aineisto[k].pituusaste]);
				}
				var kartta_kohde = L.polyline(pisteet, {});
				karttapiirtotaso.addLayer(kartta_kohde);
				karttakomponentti.fitBounds(kartta_kohde.getBounds());
				$(".leaflet-draw-draw-polyline, .leaflet-draw-draw-marker").hide();
				$(".leaflet-control-filelayer").hide();
			}
			else {
				$(".leaflet-draw-draw-polyline, .leaflet-draw-draw-marker").show();
				$(".leaflet-control-filelayer").show();
			}
			
			$(".leaflet-draw-section").show();
			karttavalikko.close();
			$("#karttavalikko").hide();
			karttaruutu.open();
			karttaruutu.freeze();
			karttaruutu.setContent("<span class='karttaruutu_teksti'>" + kohde_nimi + " - muokkaustila" + "</span>");
		});
			
		karttavalikko_kohde_nakyvyys.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			var kohde = $(this).closest(".karttavalikko_kohde");
			var kohde_id = kohde.data("kohde_id");
			var kohde_aineisto = kohde.data("aineisto");
			var kohde_kuvaus = kohde.data("kuvaus");
			var kohde_nimi = $(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_teksti").html();
			var kohde_vari = kohde.data("vari");
			var kohde_tila = "";
			if(kohde.data("tila") != "") {
				kohde_tila = kohde.data("tila");
			}
			
			var kohde_attribuutti_tiedot = kohde.data("attribuutit");
			var kohde_attribuutti_lista = "";
			
			for(var j = 0; j < kohde_attribuutti_tiedot.length; j++)
			{
				if(j == 0) {
					kohde_attribuutti_lista += "<ul class='karttakohde_ruutu_lista'>";
				}
				
				if(kohde_attribuutti_tiedot[j].tyyppi == 1) {
					kohde_attribuutti_lista += "<li>" + kohde_attribuutti_tiedot[j].nimi + ": " + kohde_attribuutti_tiedot[j].arvo + "</li>"
				}
				else if(kohde_attribuutti_tiedot[j].tyyppi == 2) {
					kohde_attribuutti_lista += "<li class='karttavalikko_ei_lista_merkintaa'><a href='" + kohde_attribuutti_tiedot[j].arvo + "' target='_blank'>" + kohde_attribuutti_tiedot[j].nimi + "<a></li>";
				}
				else if(kohde_attribuutti_tiedot[j].tyyppi == 3) {
					kohde_attribuutti_lista += "<li class='karttavalikko_ei_lista_merkintaa'><img class='karttavalikko_kohde_attribuutti_kuva' src='" + kohde_attribuutti_tiedot[j].arvo + "' onclick='nayta_kuva($(this))' /></li>";
				}
				
				if(j == kohde_attribuutti_tiedot.length - 1) {
					kohde_attribuutti_lista += "</ul>";
				}
			}
			
			if($(this).hasClass("fa-check-square-o")) {
				$(this).removeClass("fa-check-square-o");
				$(this).addClass("fa-square-o");
				
				if(kohde_id in karttaaineisto) {
					var kartta_kohde_aineisto = karttaaineisto[kohde_id];
					for(var j = 0; j < kartta_kohde_aineisto.length; j++)
					{
						karttaaineistotaso.removeLayer(kartta_kohde_aineisto[j]);
					}
				}
			}
			else {
				$(this).removeClass("fa-square-o");
				$(this).addClass("fa-check-square-o");
				
				if(kohde_aineisto.length == 1) {
					var kartta_kohde = L.marker([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste], { 
						icon: L.BeautifyIcon.icon({
							icon: 'circle',
							iconShape: 'marker',
							textColor: "#fff",
							borderColor: "rgb(" + kohde_vari + ")",
							backgroundColor: "rgb(" + kohde_vari + ")"
						})
					});
					kartta_kohde.bindPopup("<b>" + kohde_nimi + "</b></br>" + kohde_kuvaus + "</br>" + kohde_tila + "</br>" + kohde_attribuutti_lista);
					karttaaineistotaso.addLayer(kartta_kohde);
					karttaaineisto[kohde_id] = [kartta_kohde];
					karttakomponentti.setView([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste]);
					kartta_kohde.openPopup();
				}
				else if(kohde_aineisto.length > 1) {
					var pisteet = [];
					for(var j = 0; j < kohde_aineisto.length; j++)
					{
						pisteet.push([kohde_aineisto[j].leveysaste,kohde_aineisto[j].pituusaste]);
					}
					var kartta_kohde_alku = L.marker([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste], {
						icon: karttakohde_piste
						/* L.BeautifyIcon.icon({
							icon: 'flag',
							iconShape: 'marker',
							textColor: "green"
						})
						*/
					});
					var kartta_kohde_loppu = L.marker([kohde_aineisto[kohde_aineisto.length - 1].leveysaste,kohde_aineisto[kohde_aineisto.length - 1].pituusaste], {
						icon: karttakohde_piste
						/* L.BeautifyIcon.icon({
							icon: 'flag-checkered',
							iconShape: 'marker',
							textColor: "red"
						})
						*/
					});
					var kartta_kohde = L.polyline(pisteet, { "color":"rgb(" + kohde_vari + ")" });
					kartta_kohde.bindPopup("<b>" + kohde_nimi + "</b></br>" + kohde_kuvaus + "</br>" + kohde_tila + "</br>" + kohde_attribuutti_lista);
					karttaaineistotaso.addLayer(kartta_kohde);
					karttaaineistotaso.addLayer(kartta_kohde_alku);
					karttaaineistotaso.addLayer(kartta_kohde_loppu);
					karttaaineisto[kohde_id] = [kartta_kohde,kartta_kohde_alku,kartta_kohde_loppu];
					karttakomponentti.setView(kartta_kohde.getBounds().getCenter());
					//karttakomponentti.fitBounds(kartta_kohde.getBounds());
					kartta_kohde.openPopup(kartta_kohde.getBounds().getCenter());
				}
			}
		});
	}
}

function hae_aineisto_pisteet() 
{
	var toiminnon_siirto = $.Deferred();
	
	var valittu_luokkatunnus = $(".karttavalikko_aineistotyyppi_valinta").val();
	
	if(kategoria_aineisto_taso != "") {
		kategoria_aineisto_taso.removeFrom(karttakomponentti);
		kategoria_aineisto_taso = "";
	}
	
	if(valittu_luokkatunnus == "") {
		return;
	}
	
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kategoria_aineisto_pisteet.php",
			data: { luokkatunnus:valittu_luokkatunnus, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				var pisteet = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					pisteet.push([tiedot[i].y,tiedot[i].x]);
				}

				proj4.defs("urn:ogc:def:crs:EPSG::3877","+proj=tmerc +lat_0=0 +lon_0=23 +k=1 +x_0=23500000 +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs");
				
				var geojson = {
					"type": "Feature",
					"geometry": {
						"type": "MultiPoint",
						"coordinates": pisteet
					},
					"crs": {
						"type": "name",
						"properties": {
							"name": "urn:ogc:def:crs:EPSG::3877"
						}
					}
				}
				
				kategoria_aineisto_taso = L.Proj.geoJson(geojson, { pointToLayer: function (feature, latlng) {
						var lapinakyvyys = $(".karttavalikko_aineisto_lapinakyvyys").val();
						if(tarkista_muuttuja(lapinakyvyys,"numero") != "") {
							lapinakyvyys = lapinakyvyys/100;
						}
						else {
							lapinakyvyys = 1;
						}

						return L.circleMarker(latlng, {
							radius: 8,
							fillColor: "#ff7800",
							color: "#000",
							weight: 1,
							opacity: lapinakyvyys,
							fillOpacity: lapinakyvyys
						});
					}}
				);
				
				kategoria_aineisto_taso.addTo(karttakomponentti);
				
				
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function aseta_aineisto_lapinakyvyys()
{
	var lapinakyvyys = $(".karttavalikko_aineisto_lapinakyvyys").val();
	if(tarkista_muuttuja(lapinakyvyys,"numero") != "") {
		if(lapinakyvyys > 100) {
			lapinakyvyys = 100;
		}
		if(lapinakyvyys < 0) {
			lapinakyvyys = 0;
		}
		if(kategoria_aineisto_taso != "") {
			kategoria_aineisto_taso.setStyle({opacity:lapinakyvyys/100, fillOpacity:lapinakyvyys/100});
		}
	}
	else {
		$(".karttavalikko_aineisto_lapinakyvyys").val(100);
		kategoria_aineisto_taso.setOpacity(1);
	}
}

function nayta_apu_aineisto()
{
	var toiminnon_siirto = $.Deferred();
	
	karttaapuaineistotaso.clearLayers();
	
	var valittu_kohde = $("#karttavalikko_aputaso_aineistovalinta").val();
	if(valittu_kohde == "") {
		return;
	}
	
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kohde_aineisto.php",
			data: { aineistotunnus:valittu_kohde, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				var lapinakyvyys = $(".karttavalikko_apuaineisto_lapinakyvyys").val();
				if(tarkista_muuttuja(lapinakyvyys,"numero") != "") {
					lapinakyvyys = lapinakyvyys/100;
				}
				else {
					lapinakyvyys = 1;
				}
				
				var kohde_aineisto = tiedot[0].aineisto;
				if(kohde_aineisto.length == 1) {
					var kartta_kohde = L.marker([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste], { 
						opacity: lapinakyvyys,
						icon: L.BeautifyIcon.icon({
							icon: 'circle',
							iconShape: 'marker',
							textColor: "#f5a038",
							borderColor: "#f5a038",
							backgroundColor: "#f5a038"
						})
					});
					karttaapuaineistotaso.addLayer(kartta_kohde);
					karttakomponentti.setView([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste]);
				}
				else if(kohde_aineisto.length > 1) {
					var pisteet = [];
					for(var j = 0; j < kohde_aineisto.length; j++)
					{
						pisteet.push([kohde_aineisto[j].leveysaste,kohde_aineisto[j].pituusaste]);
					}
					var kartta_kohde = L.polyline(pisteet, {
						opacity: lapinakyvyys,
						color: "#f5a038"
					});
					karttaapuaineistotaso.addLayer(kartta_kohde);
					karttakomponentti.fitBounds(kartta_kohde.getBounds());
				}

				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function aseta_apuaineisto_lapinakyvyys()
{
	var lapinakyvyys = $(".karttavalikko_apuaineisto_lapinakyvyys").val();
	if(tarkista_muuttuja(lapinakyvyys,"numero") != "") {
		if(lapinakyvyys > 100) {
			lapinakyvyys = 100;
		}
		if(lapinakyvyys < 0) {
			lapinakyvyys = 0;
		}
		if(karttaapuaineistotaso != "") {
			karttaapuaineistotaso.setStyle({opacity:lapinakyvyys/100, fillOpacity:lapinakyvyys/100});
		}
	}
	else {
		$(".karttavalikko_apuaineisto_lapinakyvyys").val(100);
		karttaapuaineistotaso.setOpacity(1);
	}
}

function alusta_aineisto(nakyma_id)
{
	if(!aineisto_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#valilehti_sisaltonakyma_" + nakyma_id).append(sisaltotaulukehys);
		
		$.when(hae_kohde_aineistotunnus_valinnat()).then(function() {
			sisaltotaulukehys.sisaltotaulu({
				nimi: "aineisto",
				solut: [
					{"nimi":"#","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Leveysaste","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Pituusaste","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Kohde","leveys":"200","kentta":"valintakentta","tiedot":aineistotunnus_valinnat,"linkitys":[]}
				],
				tietohaku: hae_aineisto,
				tallennus: tallenna_aineisto
			});
			
			sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
		
			aineisto_alustettu = true;
		});
	}
	else {
		$.when(hae_kohde_aineistotunnus_valinnat()).then(function() {
			$("#valilehti_sisaltonakyma_" + nakyma_id).find("table").sisaltotaulu_otsikkosolu_paivitys({
				solut: [
					{"solu":3,"kentta":"valintakentta","tiedot":aineistotunnus_valinnat,"linkitys":[]}
				]
			});
			
			$("#valilehti_sisaltonakyma_" + nakyma_id).find("table").trigger("sisalto_paivitys");
		});
	}
}

function alusta_kohteet(nakyma_id)
{
	if(!kohteet_alustettu) {
		$.when(hae_kategoria_valinnat(),hae_attribuutti_valinnat(),hae_tila_valinnat(),hae_kategoria_tila_valinnat()).then(function() {
			var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
			$("#valilehti_sisaltonakyma_" + nakyma_id).append(sisaltotaulukehys);
			
			sisaltotaulukehys.sisaltotaulu({
				nimi: "kohteet",
				solut: [
					{"nimi":"Kategoria","leveys":"100","kentta":"valintakentta","tiedot":kategoria_valinnat,"linkitys":[kategoria_tila_valinnat,5,tila_valinnat]},
					{"nimi":"#","leveys":"50","kentta":"","tiedot":"","linkitys":[]},
					{"nimi":"Nimi","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Kuvaus","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Attribuutit","leveys":"300","kentta":"valintasyottokentta","tiedot":[attribuutti_valinnat,""],"linkitys":[]},
					{"nimi":"Tila","leveys":"100","kentta":"valintakentta","tiedot":[],"linkitys":[]},
					{"nimi":"Aineistotunnus","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Näkyvyys","leveys":"150","kentta":"kytkinkentta","tiedot":"","linkitys":[]}
				],
				tietohaku: hae_kohteet,
				tallennus: tallenna_kohde
			});
			
			sisaltotaulukehys.find("table").trigger("sisalto_paivitys");

			kohteet_alustettu = true;
		});
	}
	else {
		$.when(hae_kategoria_valinnat(),hae_attribuutti_valinnat,hae_tila_valinnat(),hae_kategoria_tila_valinnat()).then(function() {
			$("#valilehti_sisaltonakyma_" + nakyma_id).find("table").sisaltotaulu_otsikkosolu_paivitys({
				solut: [
					{"solu":0,"kentta":"valintakentta","tiedot":kategoria_valinnat,"linkitys":[kategoria_tila_valinnat,5,tila_valinnat]},
					{"solu":4,"kentta":"valintasyottokentta","tiedot":[attribuutti_valinnat,""],"linkitys":[]}
				]
			});
			
			$("#valilehti_sisaltonakyma_" + nakyma_id).find("table").trigger("sisalto_paivitys");
		});
	}
}

function alusta_viestit(nakyma_id)
{
	if(!viestit_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#valilehti_sisaltonakyma_" + nakyma_id).append(sisaltotaulukehys);
		
		sisaltotaulukehys.sisaltotaulu({
			nimi: "viestit",
			solut: [
				{"nimi":"Aihe","leveys":"100","kentta":"valintakentta","tiedot":viesti_aihe_valinnat,"linkitys":[]},
				{"nimi":"Viesti","leveys":"500","kentta":"syottokentta","tiedot":"","linkitys":[]},
				{"nimi":"Lähettäjä","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
				{"nimi":"Lähetetty","leveys":"200","kentta":"aikavalihakukentta","tiedot":"","linkitys":[]},
				{"nimi":"Kuitattu","leveys":"200","kentta":"kytkinkentta","tiedot":"","linkitys":[]}
			],
			tietohaku: hae_viestit,
			tallennus: tallenna_viesti
		});
		
		sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
		
		viestit_alustettu = true;
		
	}
	else {
		$("#valilehti_sisaltonakyma_" + nakyma_id).find("table").trigger("sisalto_paivitys");
	}
}

function alusta_tapahtumat(nakyma_id)
{
	if(!tapahtumat_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#valilehti_sisaltonakyma_" + nakyma_id).append(sisaltotaulukehys);
		
		$.when(hae_kohde_valinnat()).then(function() {
			sisaltotaulukehys.sisaltotaulu({
				nimi: "tapahtumat",
				solut: [
					{"nimi":"Tyyppi","leveys":"50","kentta":"valintakentta","tiedot":tapahtuma_tyyppi_valinnat,"linkitys":[]},
					{"nimi":"Kohde","leveys":"150","kentta":"valintakentta","tiedot":kohde_valinnat,"linkitys":[]},
					{"nimi":"Kuvaus","leveys":"500","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Aikaleima","leveys":"200","kentta":"aikavalihakukentta","tiedot":"","linkitys":[]}
				],
				tietohaku: hae_tapahtumat,
				tallennus: tallenna_tapahtuma
			});
			
			sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
			
			tapahtumat_alustettu = true;
		});
	}
	else {
		$.when(hae_kohde_valinnat()).then(function() {
			$("#valilehti_sisaltonakyma_" + nakyma_id).find("table").sisaltotaulu_otsikkosolu_paivitys({
				solut: [
					{"solu":1,"kentta":"valintakentta","tiedot":kohde_valinnat,"linkitys":[]}
				]
			});
			
			$("#valilehti_sisaltonakyma_" + nakyma_id).find("table").trigger("sisalto_paivitys");
		});
	}
}

function alusta_asetukset(nakyma_id)
{
	if(!asetukset_alustettu) {
		$("#valilehti_sisaltonakyma_" + nakyma_id).pudotusvalikko({
			"kehys_id": nakyma_id,
			"tiedot": [
				{"nimi":"Kategoriat","toiminto":alusta_kategoriat},
				{"nimi":"Tilat","toiminto":alusta_tilat},
				{"nimi":"Attribuutit","toiminto":alusta_attribuutit},
				{"nimi":"Käyttäjät","toiminto":alusta_kayttajat},
				{"nimi":"Laitteet","toiminto":alusta_laitteet},
				{"nimi":"Huoltoviestit","toiminto":alusta_huoltoviestit}
				//{"nimi":"Käännökset","toiminto":alusta_kaannokset},
			]
		});
		asetukset_alustettu = true;
	}
}

function alusta_kategoriat(sisalto_id)
{
	if(!kategoriat_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").html(sisaltotaulukehys);
		
		$.when(hae_kategoria_valinnat(),hae_tila_valinnat()).then(function() {
			sisaltotaulukehys.sisaltotaulu({
				nimi: "kategoriat",
				solut: [
					{"nimi":"#","leveys":"50","kentta":"","tiedot":"","linkitys":[]},
					{"nimi":"Nimi","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Lisätiedot","leveys":"350","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Tilat","leveys":"300","kentta":"monivalintakentta","tiedot":tila_valinnat,"linkitys":[]},
					{"nimi":"Taso","leveys":"150","kentta":"valintakentta","tiedot":kategoria_valinnat,"linkitys":[]},
					{"nimi":"Näkyvyys","leveys":"150","kentta":"kytkinkentta","tiedot":"","linkitys":[]}
				],
				tietohaku: hae_kategoriat,
				tallennus: tallenna_kategoria
			});
			
			sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
			
			kategoriat_alustettu = true;
		});
	}
	else {
		$.when(hae_kategoria_valinnat(),hae_tila_valinnat()).then(function() {
			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").sisaltotaulu_otsikkosolu_paivitys({
				solut: [
					{"solu":3,"kentta":"monivalintakentta","tiedot":tila_valinnat,"linkitys":[]},
					{"solu":4,"kentta":"valintakentta","tiedot":kategoria_valinnat,"linkitys":[]}
				]
			});

			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").trigger("sisalto_paivitys");
		});
	}
}

function alusta_tilat(sisalto_id)
{
	if(!tilat_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").html(sisaltotaulukehys);
		
		sisaltotaulukehys.sisaltotaulu({
			nimi: "tilat",
			solut: [
				{"nimi":"Nimi","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
				{"nimi":"Väri","leveys":"200","kentta":"varikentta","tiedot":"","linkitys":[]}
			],
			tietohaku: hae_tilat,
			tallennus: tallenna_tila
		});
		
		sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
		
		tilat_alustettu = true;
	}
	else {
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").trigger("sisalto_paivitys");
	}
}

function alusta_attribuutit(sisalto_id)
{
	if(!attribuutit_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").html(sisaltotaulukehys);
		
		sisaltotaulukehys.sisaltotaulu({
			nimi: "attribuutit",
			solut: [
				{"nimi":"#","leveys":"50","kentta":"","tiedot":"","linkitys":[]},
				{"nimi":"Nimi","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
				{"nimi":"Kuvaus","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
				{"nimi":"Tyyppi","leveys":"200","kentta":"valintakentta","tiedot":attribuutti_tyyppi_valinnat,"linkitys":[]}
			],
			tietohaku: hae_attribuutit,
			tallennus: tallenna_attribuutti
		});
		
		sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
		
		attribuutit_alustettu = true;
	}
	else {
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").trigger("sisalto_paivitys");
	}
}

function alusta_kayttajat(sisalto_id)
{
	if(!kayttajat_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").html(sisaltotaulukehys);
		
		$.when(hae_kohde_valinnat()).then(function() {
			sisaltotaulukehys.sisaltotaulu({
				nimi: "kayttajat",
				solut: [
					{"nimi":"Nimi","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"GSM","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Sähköposti","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Tunnus","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Salasana","leveys":"100","kentta":"salasanakentta","tiedot":"","linkitys":[]},
					{"nimi":"Ryhmä","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Oikeudet","leveys":"100","kentta":"monivalintakentta","tiedot":oikeus_valinnat,"linkitys":[]},
					{"nimi":"Kohteet","leveys":"100","kentta":"monivalintakentta","tiedot":kohde_valinnat,"linkitys":[]},
					{"nimi":"Aktiivinen","leveys":"100","kentta":"kytkinkentta","tiedot":"","linkitys":[]}
				],
				tietohaku: hae_kayttajat,
				tallennus: tallenna_kayttaja
			});
			
			sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
		
			kayttajat_alustettu = true;
		});
	}
	else {
		$.when(hae_kohde_valinnat()).then(function() {
			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").sisaltotaulu_otsikkosolu_paivitys({
				solut: [
					{"solu":7,"kentta":"monivalintakentta","tiedot":kohde_valinnat,"linkitys":[]}
				]
			});

			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").trigger("sisalto_paivitys");
		});
	}
}

function alusta_laitteet(sisalto_id)
{
	if(!laitteet_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").html(sisaltotaulukehys);
		
		$.when(hae_kohde_attribuutti_valinnat()).then(function() {
			sisaltotaulukehys.sisaltotaulu({
				nimi: "laitteet",
				solut: [
					{"nimi":"Laitetunnus","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Kuvaus","leveys":"200","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Attribuutit/Päivitysvälit(min)","leveys":"350","kentta":"","tiedot":[kohde_attribuutti_valinnat,"numero"],"linkitys":[]},
					{"nimi":"Aktiivinen","leveys":"100","kentta":"kytkinkentta","tiedot":"","linkitys":[]}
				],
				tietohaku: hae_laitteet,
				tallennus: tallenna_laite
			});
				
			sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
				
			laitteet_alustettu = true;
		});
	}
	else {
		$.when(hae_kohde_attribuutti_valinnat()).then(function() {
			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").sisaltotaulu_otsikkosolu_paivitys({
				solut: [
					{"solu":2,"kentta":"","tiedot":[kohde_attribuutti_valinnat,"numero"],"linkitys":[]}
				]
			});
			
			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").trigger("sisalto_paivitys");
		});
	}
}


function alusta_huoltoviestit(sisalto_id)
{
	if(!huoltoviestit_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").html(sisaltotaulukehys);
		
		$.when(hae_kohde_valinnat(),hae_tila_valinnat(),hae_kohde_tila_valinnat()).then(function() {
			sisaltotaulukehys.sisaltotaulu({
				nimi: "huoltoviestit",
				solut: [
					{"nimi":"Kohde","leveys":"100","kentta":"valintakentta","tiedot":kohde_valinnat,"linkitys":[kohde_tila_valinnat,1,tila_valinnat]},
					{"nimi":"Tila","leveys":"100","kentta":"valintakentta","tiedot":[],"linkitys":[]},
					{"nimi":"Ohjaus","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]},
					{"nimi":"Aktiivinen","leveys":"100","kentta":"kytkinkentta","tiedot":"","linkitys":[]}
				],
				tietohaku: hae_huoltoviestit,
				tallennus: tallenna_huoltoviesti
			});
			
			sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
			
			huoltoviestit_alustettu = true;
		});
	}
	else {
		$.when(hae_kohde_valinnat(),hae_tila_valinnat(),hae_kohde_tila_valinnat()).then(function() {
			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").sisaltotaulu_otsikkosolu_paivitys({
				solut: [
					{"solu":0,"kentta":"valintakentta","tiedot":kohde_valinnat,"linkitys":[kohde_tila_valinnat,1,tila_valinnat]}
				]
			});

			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").trigger("sisalto_paivitys");
		});
	}
}

function alusta_kaannokset(sisalto_id)
{
	if(!kaannokset_alustettu) {
		var sisaltotaulukehys = $("<div class='sisaltotaulukehys'></div>");
		$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").html(sisaltotaulukehys);
		
		$.when(hae_kaannos_valinnat()).then(function() {
			sisaltotaulukehys.sisaltotaulu({
				nimi: "kaannokset",
				solut: [
					{"nimi":"Kieli","leveys":"100","kentta":"valintakentta","tiedot":kieli_valinnat,"linkitys":[]},
					{"nimi":"Käännettävä teksti","leveys":"100","kentta":"valintakentta","tiedot":[],"linkitys":[]},
					{"nimi":"Käännös","leveys":"100","kentta":"syottokentta","tiedot":"","linkitys":[]}
					
				],
				tietohaku: hae_kaannokset,
				tallennus: tallenna_kaannos
			});
			
			sisaltotaulukehys.find("table").trigger("sisalto_paivitys");
			
			kaannokset_alustettu = true;
		});
	}
	else {
		$.when(hae_kaannos_valinnat()).then(function() {
			$("#pudotusvalikko_" + sisalto_id).next(".pudotusvalikko_sisaltokehys").find("table").trigger("sisalto_paivitys");
		});
	}
}

$.fn.sisaltotaulu = function() {
	var taulusolut = arguments[0].solut;
	var tietohakufunktio = arguments[0].tietohaku;
	var tallennusfunktio = arguments[0].tallennus;
	
	$(this).html(
		"<table id='sisaltotaulu_" + arguments[0].nimi + "' class='sisaltotaulu'>"
			+ "<thead>"
				+ "<tr class='otsikkorivi'></tr>"
				+ "<tr class='sisaltotaulu_hakurivi' style='display:none'></tr>"
				+ "<tr class='sisaltotaulu_tallennusrivi' style='display:none'></tr>"
			+ "</thead>"
			+ "<tbody></tbody>"
			+ "<tfoot>"
				+ "<tr class='lukumaararivi'></tr>"
			+ "</tfoot>"
		+ "</table>"
	);
	
	$(this).find(".sisaltotaulu_hakurivi").on("piilota_rivi",function() {
		if($(this).css("display") != "none") {
			$(this).tyhjenna_rivi_kentat();
			$(this).hide();
		}
	});
	
	$(this).find(".sisaltotaulu_tallennusrivi").on("piilota_rivi",function() {
		if($(this).css("display") != "none") {
			$(this).tyhjenna_rivi_kentat();
			$(this).hide();
		}
	});
	
	$(this).find("table").on("sisalto_paivitys",function() {
		var taulu = $(this);
		taulu.find("tbody").html("");
		taulu.find("tfoot .lukumaararivi").html("");
		
		$.when(tietohakufunktio(taulu)).then(function(lukumaarat) {
			taulu.find("tbody tr").each(function() { 
				var solu_vieritys_leveys = $(this).closest("tbody").outerWidth() - $(this).closest("tbody").prop("clientWidth");
				$(this).find(".sisaltotaulu_painike_solu").css("width",$(this).find(".sisaltotaulu_painike_solu").outerWidth() - solu_vieritys_leveys);
			});
			
			$(taulu).alatunnisterivi({
				"lukumaarat":lukumaarat
			});
		});
		$(this).find("tbody").css("bottom",$(this).find("tfoot").outerHeight());
	});
	
	$(this).find("table").on("otsikko_paivitys",function() {
		$(this).find("tbody").css("top",$(this).find("thead").outerHeight());
	});
	
	for(var i = 0; i < taulusolut.length; i++)
	{
		$(this).find(".sisaltotaulu .otsikkorivi").append("<th style='width:" + taulusolut[i].leveys + "px' class='sisaltotaulu_otsikko'>" + taulusolut[i].nimi + "</th>");
		$(this).find(".sisaltotaulu_hakurivi, .sisaltotaulu_tallennusrivi").each(function() {
			$(this).append("<th style='width:" + taulusolut[i].leveys + "px' class='sisaltotaulu_otsikko_solu'></th>");

			var tiedot = taulusolut[i].tiedot;
			var linkitys = taulusolut[i].linkitys;
			var kentta = "";
			switch(taulusolut[i].kentta)
			{
				case "syottokentta": 
					kentta = $("<input class='syottokentta' />");
					kentta.syottokentta();
				break;
				
				case "hakusyottokentta": 
					if($(this).hasClass("sisaltotaulu_hakurivi")) {
						kentta = $("<input class='syottokentta' />");
						kentta.syottokentta();
					}
				break;
				
				case "salasanakentta":
					if($(this).hasClass("sisaltotaulu_tallennusrivi")) {
						kentta = $("<input class='salasanakentta' type='password' />");
						kentta.syottokentta();
					}
				break;
				
				case "valintakentta": 
					kentta = $("<select class='valintakentta'></select>");
					kentta.valintakentta(tiedot,linkitys);
				break;
				
				case "monivalintakentta": 
					kentta = $("<div class='monivalintakehys'>"
							+ "<input class='monivalinta' readonly />"
							+ "<i class='monivalinta_kuvake fa fa-toggle-left'></i>"
							+ "<div class='monivalinta_valinnat' data-valitut_idt=[]></div>"
						+ "</div>");
					kentta.monivalinta(tiedot);
				break;
				
				case "kytkinkentta": 
					kentta = $("<div class='kytkinkehys kytkinkehys_ei_maaritelty' data-aktiivinen='-1' data-edellinen_tila='0'>"
							+ "<div class='kytkinvipu kytkinvipu_ei_maaritelty'></div>"
						+ "</div>");
					kentta.kytkin();
				break;
				
				case "varikentta":
					kentta = $("<div class='varivalintakehys'>"
						+ "<div class='varivalinta' data-tiedot=''>"
							+ "<i class='varivalinta_kuvake fa fa-paint-brush'></i>"
						+ "</div>"
						+ "<div class='varikehys'>"
							+ "<div class='varikarttakehys'></div>"
							+ "<div class='varikaistakehys'></div>"
						+ "</div>"
						+ "</div>");
					$(this).find("th:last-of-type").append(kentta);
					kentta.varivalinta();
				break;
				
				case "valintasyottokentta":
					kentta = $("<div class='valintasyottokehys'>"
						+ "<input class='valintasyotto' readonly />"
						+ "<i class='valintasyotto_kuvake fa fa-toggle-left'></i>"
						+ "<div class='valintasyotto_tietokehys' data-tiedot=[]>"
							+ "<div class='valintasyotto_lisayskenttarivi'>"
								+ "<div class='valintasyotto_kenttakehys'>"
									+ "<select class='valintasyotto_lisayskentta'></select>"
									+ "<input class='valintasyotto_lisayskentta' />"
								+ "</div>"
								+ "<i class='valintasyotto_lisayskuvake fa fa-plus-square-o' title='Lisää'></i>"
							+ "</div>"
							+ "<div class='valintasyotto_arvot'></div>"
						+ "</div>"
					+ "</div>");
					kentta.valintasyotto(tiedot[0],tiedot[1]);
				break;
				
				case "monisyottokentta":
					kentta = $("<div class='monisyottokehys'>"
							+ "<input class='monisyotto' readonly />"
							+ "<i class='monisyotto_kuvake fa fa-toggle-left'></i>"
							+ "<div class='monisyotto_tietokehys' data-tiedot=[]>"
								+ "<div class='monisyotto_lisayskenttarivi'>"
									+ "<div class='monisyotto_kenttakehys'>"
										+ "<input class='monisyotto_lisayskentta' />"
										+ "<input class='monisyotto_lisayskentta' />"
									+ "</div>"
									+ "<i class='monisyotto_lisayskuvake fa fa-plus-square-o' title='Lisää'></i>"
								+ "</div>"
								+ "<div class='monisyotto_arvot'></div>"
							+ "</div>"
						+ "</div>");
					kentta.monisyotto(["teksti","numero"]);
				break;
				
				case "monipuuvalintasyottokentta":
					kentta = $("<div class='monipuuvalintasyottokehys'>"
						+ "<input class='monipuuvalintasyotto' readonly />"
						+ "<i class='monipuuvalintasyotto_kuvake fa fa-toggle-left'></i>"
						+ "<div class='monipuuvalintasyotto_valinnat' data-valitut_idt=[]></div>"
					+ "</div>");
					kentta.monipuuvalintasyotto(tiedot[0],tiedot[1]);
				break;
				
				case "puuvalintakentta":
					kentta = $("<div class='puuvalintakehys'>"
						+ "<input class='puuvalinta' readonly />"
						+ "<i class='puuvalinta_kuvake fa fa-toggle-left'></i>"
						+ "<div class='puuvalinta_valinnat' data-tiedot=[]></div>"
					+ "</div>");
					kentta.puuvalinta(tiedot);
				break;
				
				case "aikavalihakukentta":
					if($(this).hasClass("sisaltotaulu_hakurivi")) {
						kentta = $("<div class='aikavalikehys'>"
							+ "<div class='aikavali_alkupvm_kehys aikavali_pvm_kehys'>"
								+ "<input class='aikavali_pvmkentta' />"
								+ "<i class='aikavali_pvm_tyhjennys_kuvake fa fa-times'></i>"
							+ "</div>"
							+ "<span class='aikavali_pvmerotin'>-</span>"
							+ "<div class='aikavali_loppupvm_kehys aikavali_pvm_kehys'>"
								+ "<input class='aikavali_pvmkentta' />"
								+ "<i class='aikavali_pvm_tyhjennys_kuvake fa fa-times'></i>"
							+ "</div>"
						+ "</div>");
						kentta.aikavali();
					}
				break;
				
				default: kentta = "";
			}
			
			if(taulusolut[i].kentta != "varikentta") {
				$(this).find("th:last-of-type").append(kentta);
			}
		});
	}

	$(this).find(".otsikkorivi").append("<th style='width:" + sisaltotaulu_painike_solu_leveys + "px' class='sisaltotaulu_otsikko sisaltotaulu_painike_solu'></th>");
	$(this).find(".sisaltotaulu_hakurivi, .sisaltotaulu_tallennusrivi").each(function() {
		$(this).append("<th style='width:100px' class='sisaltotaulu_otsikko_solu sisaltotaulu_painike_solu'></th>");
	});
	
	var tallenna_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_tallenna fa fa-floppy-o' title='Uusi rivi'></i>");
	$(this).find(".otsikkorivi th:last-of-type").append(tallenna_painike);
	tallenna_painike.click(function() {
		$(this).closest("table").find(".sisaltotaulu_hakurivi").trigger("piilota_rivi");
		$(this).closest("table").find(".sisaltotaulu_tallennusrivi").show();
		$(this).closest("table").find(".sisaltotaulu_muokkausrivi").remove();
		$(this).closest("table").find(".muokattava_rivi").show();
		$(this).closest("table").trigger("otsikko_paivitys");
	});
	
	var suorita_tallenna_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_suorita fa fa-check' title='Tallenna'></i>");
	$(this).find(".sisaltotaulu_tallennusrivi th:last-of-type").append(suorita_tallenna_painike);
	suorita_tallenna_painike.click(function() {
		$.when(tallennusfunktio($(this).closest("tr"))).then(function() {
			$(this).closest("table").find(".sisaltotaulu_tallennusrivi").trigger("piilota_rivi");
			$(this).closest("table").trigger("otsikko_paivitys");
		});
	});
	
	var peruuta_tallenna_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_peruuta fa fa-times' title='Peruuta'></i>");
	$(this).find(".sisaltotaulu_tallennusrivi th:last-of-type").append(peruuta_tallenna_painike);
	peruuta_tallenna_painike.click(function() {
		$(this).closest("table").find(".sisaltotaulu_tallennusrivi").trigger("piilota_rivi");
		$(this).closest("table").trigger("otsikko_paivitys");
	});
	
	var haku_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_etsi fa fa-search' title='Hae tietoja'></i>");
	$(this).find(".otsikkorivi th:last-of-type").append(haku_painike);
	haku_painike.click(function() {
		$(this).closest("table").find(".sisaltotaulu_hakurivi").show();
		$(this).closest("table").find(".sisaltotaulu_tallennusrivi").trigger("piilota_rivi");
		$(this).closest("table").find(".sisaltotaulu_muokkausrivi").remove();
		$(this).closest("table").find(".muokattava_rivi").show();
		$(this).closest("table").trigger("otsikko_paivitys");
	});
	
	var suorita_haku_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_suorita fa fa-check' title='Hae'></i>");
	$(this).find(".sisaltotaulu_hakurivi th:last-of-type").append(suorita_haku_painike);
	suorita_haku_painike.click(function() {
		$(this).closest("table").trigger("sisalto_paivitys");
	});
	
	var peruuta_haku_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_peruuta fa fa-times' title='Peruuta'></i>");
	$(this).find(".sisaltotaulu_hakurivi th:last-of-type").append(peruuta_haku_painike);
	peruuta_haku_painike.click(function() {
		$(this).closest("table").find(".sisaltotaulu_hakurivi").trigger("piilota_rivi");
		$(this).closest("table").trigger("otsikko_paivitys");
		$(this).closest("table").trigger("sisalto_paivitys");
	});
	
	var paivita_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_paivita fa fa-refresh' title='Päivitä'></i>");
	$(this).find(".otsikkorivi th:last-of-type").append(paivita_painike);
	paivita_painike.click(function() {
		$(this).closest("table").trigger("sisalto_paivitys");
	});

	$(this).find("table").trigger("otsikko_paivitys");
};

$.fn.sisaltotaulu_otsikkosolu_paivitys = function() {
	var taulusolut = arguments[0].solut;

	for(var i = 0; i < taulusolut.length; i++)
	{
		$(this).find(".sisaltotaulu_hakurivi, .sisaltotaulu_tallennusrivi").each(function() {
			var solu = taulusolut[i].solu;
			var kentta = taulusolut[i].kentta;
			var tiedot = taulusolut[i].tiedot;
			var linkitys = taulusolut[i].linkitys;
			
			switch(kentta)
			{
				case "valintakentta": 
					$(this).find("th:eq(" + solu + ")").find(".valintakentta").remove();
					
					var uusi_kentta = $("<select class='valintakentta'></select>");
					uusi_kentta.valintakentta(tiedot,linkitys);
					
					$(this).find("th:eq(" + solu + ")").append(uusi_kentta);
				break;
				
				case "monivalintakentta": 
					$(this).find("th:eq(" + solu + ")").find(".monivalintakehys").remove();
				
					var uusi_kentta = $("<div class='monivalintakehys'>"
						+ "<input class='monivalinta' readonly />"
						+ "<i class='monivalinta_kuvake fa fa-toggle-left'></i>"
						+ "<div class='monivalinta_valinnat' data-valitut_idt=[]></div>"
					+ "</div>");
					uusi_kentta.monivalinta(tiedot);
					
					$(this).find("th:eq(" + solu + ")").append(uusi_kentta);
				break;
				
				case "valintasyottokentta":
					$(this).find("th:eq(" + solu + ")").find(".valintasyottokehys").remove();
					
					var uusi_kentta = $("<div class='valintasyottokehys'>"
						+ "<input class='valintasyotto' readonly />"
						+ "<i class='valintasyotto_kuvake fa fa-toggle-left'></i>"
						+ "<div class='valintasyotto_tietokehys' data-tiedot=[]>"
							+ "<div class='valintasyotto_lisayskenttarivi'>"
								+ "<div class='valintasyotto_kenttakehys'>"
									+ "<select class='valintasyotto_lisayskentta'></select>"
									+ "<input class='valintasyotto_lisayskentta' />"
								+ "</div>"
								+ "<i class='valintasyotto_lisayskuvake fa fa-plus-square-o' title='Lisää'></i>"
							+ "</div>"
							+ "<div class='valintasyotto_arvot'></div>"
						+ "</div>"
					+ "</div>");
					uusi_kentta.valintasyotto(tiedot[0],tiedot[1]);
					
					$(this).find("th:eq(" + solu + ")").append(uusi_kentta);
				break;
						
				case "monipuuvalintasyottokentta":
					$(this).find("th:eq(" + solu + ")").find(".monipuuvalintakehys").remove();
				
					var uusi_kentta = $("<div class='monipuuvalintasyottokehys'>"
						+ "<input class='monipuuvalintasyotto' readonly />"
						+ "<i class='monipuuvalintasyotto_kuvake fa fa-toggle-left'></i>"
						+ "<div class='monipuuvalintasyotto_valinnat' data-valitut_idt=[]></div>"
					+ "</div>");
					uusi_kentta.monipuuvalintasyotto(tiedot[0],tiedot[1]);
					
					$(this).find("th:eq(" + solu + ")").append(uusi_kentta);
				break;
				
				case "puuvalintakentta":
					$(this).find("th:eq(" + solu + ")").find(".puuvalintakehys").remove();
					
					var uusi_kentta = $("<div class='puuvalintakehys'>"
						+ "<input class='puuvalinta' readonly />"
						+ "<i class='puuvalinta_kuvake fa fa-toggle-left'></i>"
						+ "<div class='puuvalinta_valinnat' data-tiedot=[]></div>"
					+ "</div>");
					uusi_kentta.puuvalinta(tiedot);
					
					$(this).find("th:eq(" + solu + ")").append(uusi_kentta);
				break;
				
				default:
			}
		});	
	}
};

$.fn.sisaltotaulurivi = function() {
	var sisaltotaulu_id = $(this).prop("id");
	var rivitiedot = arguments[0].rivitiedot;
	var solut = arguments[0].solut;
	var tallennusfunktio = arguments[0].tallennus;
	var poistofunktio = arguments[0].poisto;

	var rivi = $("<tr id='" + sisaltotaulu_id + "_rivi_" + rivitiedot.rivinumero + "' data-rivi_id='" + rivitiedot.rivi_id + "'" + rivitiedot.rivitila + "></tr>");
	
	for(var i = 0; i < solut.length; i++)
	{
		var soluleveys = $("#" + sisaltotaulu_id + " .otsikkorivi th:eq(" + i + ")").outerWidth();
		var solu = $("<td class='sisaltotaulu_solu' style='width:" + soluleveys + "px; max-width:" + soluleveys + "px;'></td>"); 
		var kentta = "";
		var muokattava = true;
		switch(solut[i].kentta)
		{							
			case "varitila":
				var vari = "rgba(" + solut[i].arvo + ",1)";
				kentta = $("<div class='varitila fa' style='border: 2px solid #000000; width:30px; height:30px; background-color:" + vari + "' data-tiedot='" + solut[i].arvo + "'></div>");
			break;
			
			case "painike_siirra": 
				kentta = $("<i class='sisaltotaulu_painike sisaltotaulu_siirra fa fa-exchange' title='Siirrä'></i>");
				kentta.siirra_painike(sisaltotaulu_id);
				solu.addClass("sisaltotaulu_painike_solu");
			break;

			case "painike_sahkoposti": 
				kentta = $("<i class='sisaltotaulu_painike sisaltotaulu_sahkoposti fa fa-envelope-o' title='Sähköposti'></i>");
				kentta.sahkoposti_painike(sisaltotaulu_id);
				solu.addClass("sisaltotaulu_painike_solu");
			break;
			
			case "painike_tekstiviesti": 
				kentta = $("<i class='sisaltotaulu_painike sisaltotaulu_tekstiviesti fa fa-mobile' title='Tekstiviesti'></i>");
				kentta.tekstiviesti_painike(sisaltotaulu_id);
				solu.addClass("sisaltotaulu_painike_solu");
			break;
			
			case "painike_aineisto":
				kentta = $("<i class='sisaltotaulu_painike sisaltotaulu_aineisto fa fa-map-marker' title='Näytä kartalla'></i>");
				kentta.aineisto_painike(sisaltotaulu_id);
				solu.addClass("sisaltotaulu_painike_solu");
			break;
			
			case "ei_muokattava":
				kentta = solut[i].arvo;
				muokattava = false;
			break;
			
			default: 
				kentta = solut[i].arvo;
		}
		solu.append(kentta);
		solu.data("tiedot",solut[i].tiedot);
		solu.data("kentta",solut[i].kentta);
		solu.data("muokattava",muokattava);
		rivi.append(solu);
	}
	
	var muokkaa_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_muokkaa fa fa-pencil-square-o' title='Muokkaa'></i>");
	muokkaa_painike.click(function() {
		//$(this).closest("table").find(".sisaltotaulu_hakurivi").trigger("piilota_rivi");
		$(this).closest("table").find(".sisaltotaulu_tallennusrivi").trigger("piilota_rivi");
		$(this).closest("table").trigger("otsikko_paivitys");
		$(this).closest("table").find(".sisaltotaulu_muokkausrivi").remove();
		$(this).closest("table").find(".muokattava_rivi").show();
		$(this).closest("table").find(".muokattava_rivi").removeClass("muokattava_rivi");
		
		var muokattava_rivi = $(this).closest("tr");
		muokattava_rivi.hide();
		muokattava_rivi.addClass("muokattava_rivi");
		
		var sisaltotaulu_muokkausrivi = $("<tr class='sisaltotaulu_muokkausrivi' data-rivi_id='" + muokattava_rivi.data("rivi_id") + "'></tr>");
		$(this).closest("tr").before(sisaltotaulu_muokkausrivi);
		sisaltotaulu_muokkausrivi.muokkausrivi(tallennusfunktio); 
	});
	
	var poista_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_poista fa fa-trash-o' title='Poista'></i>");
	poista_painike.click(function() {
		luo_poistoruutu($(this).closest("tr"),poistofunktio);
	});
	
	if(rivi.find(".sisaltotaulu_painike_solu").length > 0) {
		if(!rivi.hasClass("sisaltotaulu_ei_muokattava")) {
			rivi.find(".sisaltotaulu_painike_solu").prepend(muokkaa_painike);
		}
		
		rivi.find(".sisaltotaulu_painike_solu").append(poista_painike);
	}
	else {
		var otsikkotaulu_painike_solu_leveys = $("#" + sisaltotaulu_id + " .otsikkorivi .sisaltotaulu_painike_solu").outerWidth();
		rivi.append("<td class='sisaltotaulu_solu sisaltotaulu_painike_solu' style='width:" + otsikkotaulu_painike_solu_leveys + "px'></td>");
		
		if(!rivi.hasClass("sisaltotaulu_ei_muokattava")) {
			rivi.find(".sisaltotaulu_painike_solu").append(muokkaa_painike);
		}
		
		rivi.find(".sisaltotaulu_painike_solu").append(poista_painike);
	}
	
	$(this).find("tbody").append(rivi);	
};

$.fn.muokkausrivi = function(tallennusfunktio) {
	var muokkausrivi = $(this);
	var muokattava_rivi = $(this).closest("table").find(".muokattava_rivi");
	var solut = $(this).closest("table").find(".sisaltotaulu_tallennusrivi th").not(".sisaltotaulu_painike_solu");
	
	solut.each(function(i) {
		var soluleveys = muokkausrivi.closest("table").find(".otsikkorivi th:eq(" + i + ")").css("width");
		var solu = $("<td class='sisaltotaulu_solu' style='width:" + soluleveys + "'></td>");
		var solukentta = $(this).find(".syottokentta, .salasanakentta, .puuvalintakehys, .monivalintakehys, .valintasyottokehys, .monisyottokehys, .valintakentta, .kytkinkehys, .varivalintakehys");
		if(solukentta.length > 0) {
			var kentta = "";
			if(muokattava_rivi.find("td:eq(" + i + ")").data("muokattava") == false) {
				solu.append(muokattava_rivi.find("td:eq(" + i + ")").html());
			}
			else if(solukentta.hasClass("syottokentta")) {
				kentta = $("<input class='syottokentta' />");
				kentta.syottokentta();
			}
			else if(solukentta.hasClass("salasanakentta")) {
				kentta = $("<input class='salasanakentta' type='password' />");
				kentta.syottokentta();
			}
			else if(solukentta.hasClass("valintakentta")) {
				kentta = $("<select class='valintakentta'></select>");
				kentta.valintakentta(solukentta.data("valinnat"),solukentta.data("linkitys"));
			}
			else if(solukentta.hasClass("monivalintakehys")) {
				kentta = $("<div class='monivalintakehys'>"
						+ "<input class='monivalinta' readonly />"
						+ "<i class='monivalinta_kuvake fa fa-toggle-left'></i>"
						+ "<div class='monivalinta_valinnat' data-valitut_idt=[]></div>"
					+ "</div>");
					
				kentta.monivalinta(solukentta.data("valinnat"));
			}
			else if(solukentta.hasClass("kytkinkehys")) {
				kentta = $("<div class='kytkinkehys kytkinkehys_ei_maaritelty' data-aktiivinen='-1' data-edellinen_tila='0'>"
							+ "<div class='kytkinvipu kytkinvipu_ei_maaritelty'></div>"
						+ "</div>");
				kentta.kytkin();
			}
			else if(solukentta.hasClass("varivalintakehys")) {
				kentta = $("<div class='varivalintakehys'>"
					+ "<div class='varivalinta' data-tiedot=''>"
						+ "<i class='varivalinta_kuvake fa fa-paint-brush'></i>"
					+ "</div>"
					+ "<div class='varikehys'>"
						+ "<div class='varikarttakehys'></div>"
						+ "<div class='varikaistakehys'></div>"
					+ "</div>"
					+ "</div>");
				solu.append(kentta);
				muokkausrivi.append(solu);
				kentta.varivalinta();
			}
			else if(solukentta.hasClass("valintasyottokehys")) {
				kentta = $("<div class='valintasyottokehys'>"
					+ "<input class='valintasyotto' readonly />"
					+ "<i class='valintasyotto_kuvake fa fa-toggle-left'></i>"
					+ "<div class='valintasyotto_tietokehys' data-tiedot=[]>"
						+ "<div class='valintasyotto_lisayskenttarivi'>"
							+ "<div class='valintasyotto_kenttakehys'>"
								+ "<select class='valintasyotto_lisayskentta'></select>"
								+ "<input class='valintasyotto_lisayskentta' />"
							+ "</div>"
							+ "<i class='valintasyotto_lisayskuvake fa fa-plus-square-o' title='Lisää'></i>"
						+ "</div>"
						+ "<div class='valintasyotto_arvot'></div>"
					+ "</div>"
				+ "</div>");
				
				kentta.valintasyotto(solukentta.find("select").data("valinnat"),solukentta.data("kentta"));
			}
			else if(solukentta.hasClass("monisyottokehys")) {
				kentta = $("<div class='monisyottokehys'>"
							+ "<input class='monisyotto' readonly />"
							+ "<i class='monisyotto_kuvake fa fa-toggle-left'></i>"
							+ "<div class='monisyotto_tietokehys' data-tiedot=[]>"
								+ "<div class='monisyotto_lisayskenttarivi'>"
									+ "<div class='monisyotto_kenttakehys'>"
										+ "<input class='monisyotto_lisayskentta' />"
										+ "<input class='monisyotto_lisayskentta' />"
									+ "</div>"
									+ "<i class='monisyotto_lisayskuvake fa fa-plus-square-o' title='Lisää'></i>"
								+ "</div>"
								+ "<div class='monisyotto_arvot'></div>"
							+ "</div>"
						+ "</div>");
				kentta.monisyotto(["teksti","numero"]);
			}
			else if(solukentta.hasClass("puuvalintakehys")) {
				kentta = $("<div class='puuvalintakehys'>"
					+ "<input class='puuvalinta' readonly />"
					+ "<i class='puuvalinta_kuvake fa fa-toggle-left'></i>"
					+ "<div class='puuvalinta_valinnat' data-tiedot=[]></div>"
				+ "</div>");
				kentta.puuvalinta(solukentta.data("valinnat"));
			}
			
			if(!solukentta.hasClass("varivalintakehys")) {
				solu.append(kentta);
			}
		}
		else {
			solu.append(muokattava_rivi.find("td:eq(" + i + ")").html());
		}
		
		if(!solukentta.hasClass("varivalintakehys")) {
			muokkausrivi.append(solu);
		}
	});
	
	$(this).find("td").not(".sisaltotaulu_painike_solu").each(function(i) {
		var muokkausrivikentta = $(this).find(".syottokentta, .salasanakentta, .puuvalintakehys, .monivalintakehys, .valintasyottokehys, .monisyottokehys, .valintakentta, .kytkinkehys, .varivalintakehys");
		var kentta = muokkausrivikentta;
		
		if(solut.length > 0) {
			if(muokkausrivikentta.hasClass("syottokentta")) {
				muokkausrivikentta.val(muokattava_rivi.find("td:eq(" + i + ")").html());
			}
			else if(muokkausrivikentta.hasClass("valintakentta")) {
				var kenttavalinta_arvo = muokattava_rivi.find("td:eq(" + i + ")").data("tiedot");
				var loytyi = false;
				muokkausrivikentta.find("option").each(function() {
					if($(this).val() == kenttavalinta_arvo) {
						loytyi = true;
						return false;
					}
				});
				if(loytyi) {
					muokkausrivikentta.val(muokattava_rivi.find("td:eq(" + i + ")").data("tiedot")).trigger("change");
				}
				else {
					muokkausrivikentta.val("").trigger("change");
				}
			}
			else if(muokkausrivikentta.hasClass("monivalintakehys")) {
				muokkausrivikentta.find(".monivalinta_valinnat").data("valitut_idt",muokattava_rivi.find("td:eq(" + i + ")").data("tiedot"));
				muokkausrivikentta.find(".monivalinta").val(muokattava_rivi.find("td:eq(" + i + ")").html());
				
				muokkausrivikentta.find(".monivalinta_valinta").each(function() {
					if($.inArray($(this).data("id") + "",muokkausrivikentta.find(".monivalinta_valinnat").data("valitut_idt")) != -1) {
						$(this).find(".monivalinta_valinta_kuvake").removeClass("fa-square-o");
						$(this).find(".monivalinta_valinta_kuvake").addClass("fa-check-square-o");
						$(this).addClass("monivalinta_valittu");
					} 
				});
			}
			else if(muokkausrivikentta.hasClass("kytkinkehys")) {
				if(muokattava_rivi.find("td:eq(" + i + ")").data("tiedot") == "1") {
					muokkausrivikentta.removeClass("kytkinkehys_ei_maaritelty");
					muokkausrivikentta.addClass("kytkinkehys_aktiivinen");
					muokkausrivikentta.find(".kytkinvipu").removeClass("kytkinvipu_ei_maaritelty");
					muokkausrivikentta.find(".kytkinvipu").addClass("kytkinvipu_aktiivinen");
					muokkausrivikentta.data("aktiivinen","1");
					muokkausrivikentta.data("edellinen_tila","-1");
				}
				else {
					muokkausrivikentta.removeClass("kytkinkehys_ei_aktiivinen");
					muokkausrivikentta.addClass("kytkinkehys_ei_aktiivinen");
					muokkausrivikentta.find(".kytkinvipu").removeClass("kytkinvipu_ei_maaritelty");
					muokkausrivikentta.find(".kytkinvipu").addClass("kytkinvipu_ei_aktiivinen");
					muokkausrivikentta.data("aktiivinen","0");
					muokkausrivikentta.data("edellinen_tila","-1");
				}
			}
			else if(muokkausrivikentta.hasClass("varivalintakehys")) {
				var vari = muokattava_rivi.find("td:eq(" + i + ") .varitila").data("tiedot");
				muokkausrivikentta.find(".varivalinta").data("tiedot",vari);
				muokkausrivikentta.find(".varivalinta").css("background-color","rgba(" + vari + ",1)");
				
				var leveys = muokkausrivikentta.find(".varikehys").width();
				var varikartta_korkeus = muokkausrivikentta.find(".varikarttakehys").height();
				var varikartta = muokkausrivikentta.find(".varikartta")[0];
				var varikartta_alue = varikartta.getContext("2d");
				varikartta_alue.fillStyle = "rgba(" + vari + ",1)";
				varikartta_alue.fillRect(0,0,leveys,varikartta_korkeus);
		
				var varikartta_alue_varitys_valkoinen = varikartta_alue.createLinearGradient(0,0,leveys,0);
				varikartta_alue_varitys_valkoinen.addColorStop(0,"rgba(255,255,255,1)");
				varikartta_alue_varitys_valkoinen.addColorStop(1,"rgba(255,255,255,0)");
				varikartta_alue.fillStyle = varikartta_alue_varitys_valkoinen;
				varikartta_alue.fillRect(0,0,leveys,varikartta_korkeus);
				
				var varikartta_alue_varitys_musta = varikartta_alue.createLinearGradient(0,0,0,varikartta_korkeus);
				varikartta_alue_varitys_musta.addColorStop(0,"rgba(0,0,0,0)");
				varikartta_alue_varitys_musta.addColorStop(1,"rgba(0,0,0,1)");
				varikartta_alue.fillStyle = varikartta_alue_varitys_musta;
				varikartta_alue.fillRect(0,0,leveys,varikartta_korkeus);
			}
			else if(muokkausrivikentta.hasClass("valintasyottokehys")) {
				var tiedot = muokattava_rivi.find("td:eq(" + i + ")").data("tiedot");
				for(var j = 0; j < tiedot.length; j++)
				{
					var valintasyotto_rivi = $("<div class='valintasyotto_tietorivi'>"
						+ "<div class='valintasyotto_tietorivikehys'>"
							+ "<span class='valintasyotto_tietorivi_teksti' data-id='" + tiedot[j].tieto1 + "'>" + tiedot[j].tieto1_teksti + "</span>"
							+ "<span class='valintasyotto_tietorivi_teksti'>" + tiedot[j].tieto2 + "</span>"
						+ "</div>"
						+ "<i class='valintasyotto_kenttakuvake valintasyotto_muokkaus fa fa-pencil-square-o'></i>"
						+ "<i class='valintasyotto_kenttakuvake valintasyotto_poista fa fa-trash-o'></i>"
					+ "</div>");

					muokkausrivikentta.find(".valintasyotto_arvot").append(valintasyotto_rivi);
					muokkausrivikentta.find(".valintasyotto_tietokehys").data("tiedot").push({"tieto1":tiedot[j].tieto1,"tieto2":tiedot[j].tieto2});
					valintasyotto_rivi.find(".valintasyotto_tietorivikehys").css("width",muokkausrivikentta.find(".valintasyotto").width());
					valintasyotto_rivi.valintasyotto_tietorivi();
				}
				muokkausrivikentta.find(".valintasyotto_tietokehys").trigger("tietomuutos");
			}
			else if(muokkausrivikentta.hasClass("monisyottokehys")) {
				var tiedot = muokattava_rivi.find("td:eq(" + i + ")").data("tiedot");
				for(var j = 0; j < tiedot.length; j++)
				{
					var monisyotto_rivi = $("<div class='monisyotto_tietorivi'>"
						+ "<div class='monisyotto_tietorivikehys'>"
							+ "<span class='monisyotto_tietorivi_teksti'>" + tiedot[j].tieto1 + "</span>"
							+ "<span class='monisyotto_tietorivi_teksti'>" + tiedot[j].tieto2 + "</span>"
						+ "</div>"
						+ "<i class='monisyotto_kenttakuvake monisyotto_muokkaus fa fa-pencil-square-o'></i>"
						+ "<i class='monisyotto_kenttakuvake monisyotto_poista fa fa-trash-o'></i>"
					+ "</div>");

					muokkausrivikentta.find(".monisyotto_arvot").append(monisyotto_rivi);
					muokkausrivikentta.find(".monisyotto_tietokehys").data("tiedot").push({"tieto1":tiedot[j].tieto1,"tieto2":tiedot[j].tieto2});
					monisyotto_rivi.find(".monisyotto_tietorivikehys").css("width",muokkausrivikentta.find(".monisyotto").width());
					monisyotto_rivi.monisyotto_tietorivi();
				}
				muokkausrivikentta.find(".monisyotto_tietokehys").trigger("tietomuutos");
			}
			else if(muokkausrivikentta.hasClass("puuvalintakehys")) {
				muokkausrivikentta.find(".puuvalinta_valinnat").data("tiedot",muokattava_rivi.find("td:eq(" + i + ")").data("tiedot"));
				muokkausrivikentta.find(".puuvalinta").val(muokattava_rivi.find("td:eq(" + i + ")").html());
				if(muokkausrivikentta.find(".puuvalinta").val() != "") {
					muokkausrivikentta.find(".puuvalinta_tyhjennys_kuvake").show();
				}
			}
		}
	});
	
	var suorita_muokkaus_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_suorita fa fa-check' title='Tallenna'></i>");
	$(this).find("td:last-of-type").append(suorita_muokkaus_painike);
	suorita_muokkaus_painike.click(function() {
		tallennusfunktio($(this).closest("tr"));
	});
	
	var peruuta_muokkaus_painike = $("<i class='sisaltotaulu_painike sisaltotaulu_peruuta fa fa-times' title='Peruuta'></i>");
	$(this).find("td:last-of-type").append(peruuta_muokkaus_painike);
	peruuta_muokkaus_painike.click(function() {
		$(this).closest("table").find(".muokattava_rivi").show();
		$(this).closest("table").find(".muokattava_rivi").removeClass("muokattava_rivi");
		$(this).closest("tr").remove();
	});
	
	var painike_solu_leveys = muokattava_rivi.find(".sisaltotaulu_painike_solu").css("width");
	muokkausrivi.append("<td class='sisaltotaulu_solu sisaltotaulu_painike_solu' style='width:" + painike_solu_leveys + "'></td>");
	$(this).find("td:last-of-type").append(suorita_muokkaus_painike);
	$(this).find("td:last-of-type").append(peruuta_muokkaus_painike);
};

$.fn.alatunnisterivi = function() {
	var lukumaarat = arguments[0].lukumaarat;
	$(this).find("tfoot .lukumaararivi").html("<td>Näytetään: " + lukumaarat.rivimaara + " / " + lukumaarat.rivimaara_yhteensa + "</td>");
};

$.fn.tyhjenna_rivi_kentat = function() {
	$(this).find("th").each(function() {
		var kentta = $(this).find(".syottokentta, .salasanakentta, .puuvalintakehys, .monivalintakehys, .valintasyottokehys, .monisyottokehys, .valintakentta, .kytkinkehys, .aikavalikehys, .varivalintakehys");
		if(kentta.length > 0) {
			kentta.parent().removeClass("sisaltotaulu_solu_virhe");
			
			if(kentta.hasClass("syottokentta") || kentta.hasClass("salasanakentta")) {
				kentta.val("");
			}
			else if(kentta.hasClass("valintakentta")) {
				kentta.val("").trigger("change");
			}
			else if(kentta.hasClass("monivalintakehys")) {
				kentta.find(".monivalinta").val("");
				kentta.find(".monivalinta_valittu").each(function() {
					$(this).removeClass("monivalinta_valittu");
					$(this).find(".monivalinta_valinta_kuvake").removeClass("fa-check-square-o");
					$(this).find(".monivalinta_valinta_kuvake").addClass("fa-square-o");
				});
				kentta.find(".monivalinta_valinnat").removeData();
			}
			else if(kentta.hasClass("valintasyottokehys")) {
				kentta.find(".valintasyotto").val("");
				kentta.find(".valintasyotto_tietokehys").removeData();
				kentta.find(".valintasyotto_arvot").html("");
				kentta.find(".valintasyotto_lisayskentta").val("");
			}
			else if(kentta.hasClass("monisyottokehys")) {
				kentta.find(".monisyotto").val("");
				kentta.find(".monisyotto_tietokehys").removeData();
				kentta.find(".monisyotto_arvot").html("");
				kentta.find(".monisyotto_lisayskentta").val("");
			}
			else if(kentta.hasClass("puuvalintakehys")) {
				kentta.find(".puuvalinta").val("");
				kentta.find(".puuvalinta_tyhjennys_kuvake").hide();
				kentta.find(".puuvalinta_valinnat").removeData();
			}
			else if(kentta.hasClass("kytkinkehys")) {
				kentta.data("aktiivinen","-1");
				kentta.data("edellinen_tila","0");
				kentta.removeClass("kytkinkehys_aktiivinen kytkinkehys_ei_aktiivinen");
				if(!kentta.hasClass("kytkinkehys_ei_maaritelty")) {
					kentta.addClass("kytkinkehys_ei_maaritelty");
				}
				kentta.find(".kytkinvipu").removeClass("kytkinvipu_aktiivinen kytkinvipu_ei_aktiivinen")
				if(!kentta.find(".kytkinvipu").hasClass("kytkinvipu_ei_maaritelty")) {
					kentta.find(".kytkinvipu").addClass("kytkinvipu_ei_maaritelty");
				}
			}
			else if(kentta.hasClass("aikavalikehys")) {
				$.datepicker._clearDate(kentta.find(".aikavali_alkupvm_kehys .aikavali_pvmkentta"));
				kentta.find(".aikavali_alkupvm_kehys .aikavali_pvm_tyhjennys_kuvake").hide();
				$.datepicker._clearDate(kentta.find(".aikavali_loppupvm_kehys .aikavali_pvmkentta"));
				kentta.find(".aikavali_loppupvm_kehys .aikavali_pvm_tyhjennys_kuvake").hide();
			}
			else if(kentta.hasClass("varivalintakehys")) {
				kentta.find(".varivalinta").data("tiedot","");
				kentta.find(".varivalinta").css("background-color","transparent");
				var varikartta = kentta.find(".varikartta")[0];
				var varikartta_alue = varikartta.getContext("2d");
				var leveys = kentta.find(".varikehys").width();
				var varikartta_korkeus = kentta.find(".varikarttakehys").height();
				varikartta_alue.clearRect(0,0,leveys,varikartta_korkeus);
			}
		}
	});
};

$.fn.syottokentta = function() {
	$(this).change(function() {
		if($(this).parent().hasClass("sisaltotaulu_solu_virhe")) {
			$(this).parent().removeClass("sisaltotaulu_solu_virhe");
		}
	});
};

$.fn.valintakentta = function() {
	var valinnat = arguments[0];
	var linkitys = arguments[1];
	
	if(valinnat.length > 0) {
		if(valinnat[0].id != "" && valinnat[0].nimi != "Valitse") {
			valinnat.unshift({"id":"","nimi":"Valitse"});
		}
	}
	else {
		valinnat.unshift({"id":"","nimi":"Valitse"});
	}
	
	for(var i = 0; i < valinnat.length; i++)
	{
		$(this).append("<option value='" + valinnat[i]["id"] + "'>" + valinnat[i]["nimi"] + "</option>");
	}
	
	$(this).data("valinnat",valinnat);
	$(this).data("linkitys",linkitys);
	
	$(this).change(function(event) {
		if($(this).parent().hasClass("sisaltotaulu_solu_virhe")) {
			$(this).parent().removeClass("sisaltotaulu_solu_virhe");
		}

		var linkitys = $(this).data("linkitys");
		if(linkitys.length > 0) {
			var idt = [];
			var lahde_id = $(this).val();
			for(var i = 0; i < linkitys[0].length; i++)
			{
				if(lahde_id == linkitys[0][i].tieto1_id) {
					idt.push(linkitys[0][i].tieto2_id);
				}
			}
			
			var kohde_kentta = $($(this).parent().siblings()[linkitys[1] - 1]).find("select"); 
			kohde_kentta.html("<option value=''>Valitse</option>");
			var kohde_valinnat = linkitys[2];
			for(var i = 0; i < kohde_valinnat.length; i++)
			{
				if($.inArray(kohde_valinnat[i].id,idt) != -1) {
					kohde_kentta.append("<option value='" + kohde_valinnat[i].id + "'>" + kohde_valinnat[i].nimi + "</option>");
				}
			}
		}
	});
}

$.fn.puuvalinta = function() {
	var valinnat = arguments[0];
	
	$(this).find(".puuvalinta").change(function() {
		if($(this).closest(".puuvalintakehys").parent().hasClass("sisaltotaulu_solu_virhe")) {
			$(this).closest(".puuvalintakehys").parent().removeClass("sisaltotaulu_solu_virhe");
		}
		if($(this).val().length > 0) {
			$(this).next(".puuvalinta_tyhjennys_kuvake").show();
		}
		else {
			$(this).next(".puuvalinta_tyhjennys_kuvake").hide();
		}
	});
	
	var puuvalinta_tyhjennys_kuvake = $("<i class='puuvalinta_tyhjennys_kuvake fa fa-times'></i>");
	$(this).find(".puuvalinta").after(puuvalinta_tyhjennys_kuvake);
	puuvalinta_tyhjennys_kuvake.hide();
	puuvalinta_tyhjennys_kuvake.click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		$(this).closest(".puuvalintakehys").find(".puuvalinta_valinnat").data("tiedot","");
		$(this).siblings(".puuvalinta").val("");
		$(this).siblings(".puuvalinta").trigger("change");
		$(this).closest(".puuvalintakehys").find(".puuvalinta_valinnat").hide();
	});
	
	for(var i = 0; i < valinnat.length; i++)
	{
		$(this).find(".puuvalinta_valinnat").puuvalinta_taso(valinnat[i],0);
	}
	
	$(this).find(".puuvalinta_valinnat").hide();
	$(this).data("valinnat",valinnat);
	
	$(document).click(function(painiketapahtuma) {
		$(".puuvalinta_valinnat").hide();
	});
	
	$(this).click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		var puuvalinnat = $(this).find(".puuvalinta_valinnat");
		/*
		if(($(this).position().top + $(this).outerHeight() + puuvalinnat.outerHeight()) > $(this).closest("tbody").outerHeight()) {
			puuvalinnat.css("top",-1 * puuvalinnat.outerHeight());
			puuvalinnat.css({"border-top":"1px solid #000000"},{"border-bottom":"0px solid #000000"});
		}
		else {
			*/
			puuvalinnat.css("top",$(this).outerHeight());
			puuvalinnat.css({"border-top":"0px solid #000000"},{"border-bottom":"1px solid #000000"});
		//}

		if(puuvalinnat.css("display") == "none") {
			puuvalinnat.find(".puuvalinta_valinta").show();
			puuvalinnat.find(".puuvalinta_tasokehys").hide();
			puuvalinnat.find(".puuvalinta_taso_0").show();
			puuvalinnat.show();
		}
		else {
			puuvalinnat.hide();
		}
	});				
};

$.fn.puuvalinta_taso = function() {
	var valinta = arguments[0];
	var taso = arguments[1];
	var edellinen_painike = "";
	var seuraava_painike = "";
	var valitse_painike = "";
	var puuvalinta_valinta = "";
	var puuvalinta_tasokehys = "";

	if(taso > 0) {
		edellinen_painike = $("<i class='puuvalinta_edellinen_kuvake fa fa-arrow-circle-o-left'></i>");
	}
	
	if(valinta.tiedot.length > 0) {
		seuraava_painike = $("<i class='puuvalinta_seuraava_kuvake fa fa-arrow-circle-o-right'></i>");
	}
	else {
		valitse_painike = $("<i class='puuvalinta_valinta_kuvake fa fa-check'></i>");
	}
	
	if(taso == 0) {
		puuvalinta_valinta = $("<div class='puuvalinta_valinta'>"
			+ "<div class='puuvalinta_tasokehys puuvalinta_taso_" + taso + "' data-id='" + valinta.id + "' data-taso='" + taso + "'>"
				+ "<span class='puuvalinta_valinta_teksti'>" + valinta.nimi + "</span>"
			+ "</div>"
		+ "</div>");
		$(this).append(puuvalinta_valinta);
		puuvalinta_tasokehys = puuvalinta_valinta.find(".puuvalinta_tasokehys");
	}
	else {
		puuvalinta_valinta = $("<div class='puuvalinta_tasokehys puuvalinta_taso_" + taso + "' data-id='" + valinta.id + "' data-taso='" + taso + "'>"
			+ "<span class='puuvalinta_valinta_teksti'>" + valinta.nimi + "</span>"
		+ "</div>");
		$(this).closest(".puuvalinta_valinta").append(puuvalinta_valinta);
		puuvalinta_tasokehys = puuvalinta_valinta;
	}

	if(taso > 0) {
		puuvalinta_valinta.hide();
	}
	
	puuvalinta_valinta.click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
	});
	
	if(edellinen_painike != "") {
		puuvalinta_tasokehys.find(".puuvalinta_valinta_teksti").before(edellinen_painike);
		
		edellinen_painike.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			
			if($(this).closest(".puuvalinta_tasokehys").data("taso") == 1) {
				$(this).closest(".puuvalinta_valinta").siblings().show();
			}
			
			$(this).closest(".puuvalinta_valinta").find(".puuvalinta_taso_" + $(this).closest(".puuvalinta_tasokehys").data("taso")).hide();
			$(this).closest(".puuvalinta_valinta").find(".puuvalinta_taso_" + ($(this).closest(".puuvalinta_tasokehys").data("taso") - 1)).show();
		});
	}
		
	if(seuraava_painike != "") {
		puuvalinta_tasokehys.append(seuraava_painike);
		
		seuraava_painike.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			if($(this).closest(".puuvalinta_tasokehys").data("taso") == 0) {
				$(this).closest(".puuvalinta_valinta").siblings().hide();
			}
			
			$(this).closest(".puuvalinta_valinta").find(".puuvalinta_taso_" + $(this).closest(".puuvalinta_tasokehys").data("taso")).hide();
			$(this).closest(".puuvalinta_valinta").find(".puuvalinta_taso_" + ($(this).closest(".puuvalinta_tasokehys").data("taso") + 1)).show();
		});
	}
	else if(valitse_painike != "") {
		puuvalinta_valinta.append(valitse_painike);
		
		valitse_painike.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			var tiedot = [];
			var puuvalinta_teksti = "";
			$(this).closest(".puuvalinta_tasokehys").prevUntil(".puuvalinta_valinta").each(function() {
				tiedot.push($(this).data("id") + "");
				puuvalinta_teksti += $(this).find(".puuvalinta_valinta_teksti").html() + " / ";
			});

			tiedot.push($(this).closest(".puuvalinta_tasokehys").data("id") + "");
			$(this).closest(".puuvalinta_valinnat").data("tiedot",tiedot);
			puuvalinta_teksti += $(this).closest(".puuvalinta_tasokehys").find(".puuvalinta_valinta_teksti").html();
			$(this).closest(".puuvalintakehys").find(".puuvalinta").val(puuvalinta_teksti);
			$(this).closest(".puuvalintakehys").find(".puuvalinta").trigger("change");
			$(this).closest(".puuvalinta_valinnat").hide();
		});
	}

	if(valinta.tiedot.length > 0) {
		puuvalinta_valinta.puuvalinta_taso(valinta.tiedot[0],taso + 1);
	}
};

$.fn.monipuuvalintasyotto = function() {
	var valinnat = arguments[0];
	var kentta = arguments[1];
	
	$(this).find(".monipuuvalintasyotto").change(function() {
		if($(this).closest(".monipuuvalintasyottokehys").parent().hasClass("sisaltotaulu_solu_virhe")) {
			$(this).closest(".monipuuvalintasyottokehys").parent().removeClass("sisaltotaulu_solu_virhe");
		}
		if($(this).val().length > 0) {
			$(this).next(".monipuuvalintasyotto_tyhjennys_kuvake").show();
		}
		else {
			$(this).next(".monipuuvalintasyotto_tyhjennys_kuvake").hide();
		}
	});
	
	var monipuuvalintasyotto_tyhjennys_kuvake = $("<i class='monipuuvalintasyotto_tyhjennys_kuvake fa fa-times'></i>");
	$(this).find(".monipuuvalintasyotto").after(monipuuvalintasyotto_tyhjennys_kuvake);
	monipuuvalintasyotto_tyhjennys_kuvake.hide();
	monipuuvalintasyotto_tyhjennys_kuvake.click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		$(this).closest(".monipuuvalintasyottokehys").find(".monipuuvalintasyotto_valinnat").data("tiedot","");
		$(this).siblings(".monipuuvalintasyotto").val("");
		$(this).siblings(".monipuuvalintasyotto").trigger("change");
		$(this).closest(".monipuuvalintasyottokehys").find(".monipuuvalintasyotto_valinnat").hide();
	});
	
	for(var i = 0; i < valinnat.length; i++)
	{
		$(this).find(".monipuuvalintasyotto_valinnat").monipuuvalintasyotto_taso(valinnat[i],0,kentta);
	}
	
	$(this).find(".monipuuvalintasyotto_valinnat").hide();
	$(this).data("valinnat",valinnat);
	
	$(document).click(function(painiketapahtuma) {
		$(".monipuuvalintasyotto_valinnat").hide();
	});
	
	$(this).click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		var puuvalinnat = $(this).find(".monipuuvalintasyotto_valinnat");
		/*
		if(($(this).position().top + $(this).outerHeight() + puuvalinnat.outerHeight()) > $(this).closest("tbody").outerHeight()) {
			puuvalinnat.css("top",-1 * puuvalinnat.outerHeight());
			puuvalinnat.css({"border-top":"1px solid #000000"},{"border-bottom":"0px solid #000000"});
		}
		else {
			*/
			puuvalinnat.css("top",$(this).outerHeight());
			puuvalinnat.css({"border-top":"0px solid #000000"},{"border-bottom":"1px solid #000000"});
		//}

		if(puuvalinnat.css("display") == "none") {
			puuvalinnat.find(".monipuuvalintasyotto_valinta").show();
			puuvalinnat.find(".monipuuvalintasyotto_tasokehys").hide();
			puuvalinnat.find(".monipuuvalintasyotto_taso_0").show();
			puuvalinnat.show();
		}
		else {
			puuvalinnat.hide();
		}
	});				
};

$.fn.monipuuvalintasyotto_taso = function() {
	var valinta = arguments[0];
	var taso = arguments[1];
	var kenttatyyppi = arguments[2];
	var edellinen_painike = "";
	var seuraava_painike = "";
	var valitse_painike = "";
	var monipuuvalintasyotto_valinta = "";
	var monipuuvalintasyotto_tasokehys = "";

	if(taso > 0) {
		edellinen_painike = $("<i class='monipuuvalintasyotto_edellinen_kuvake fa fa-arrow-circle-o-left'></i>");
	}
	
	if(valinta.tiedot.length > 0) {
		seuraava_painike = $("<i class='monipuuvalintasyotto_seuraava_kuvake fa fa-arrow-circle-o-right'></i>");
	}
	else {
		valitse_painike = $("<i class='monipuuvalintasyotto_valinta_kuvake fa fa-check'></i>");
		kentta = $("<input class='monipuuvalintasyotto_syottokentta' />");
	}
	
	if(taso == 0) {
		monipuuvalintasyotto_valinta = $("<div class='monipuuvalintasyotto_valinta'>"
			+ "<div class='monipuuvalintasyotto_tasokehys monipuuvalintasyotto_taso_" + taso + "' data-id='" + valinta.id + "' data-taso='" + taso + "'>"
				+ "<span class='monipuuvalintasyotto_valinta_teksti'>" + valinta.nimi + "</span>"
			+ "</div>"
		+ "</div>");
		$(this).append(monipuuvalintasyotto_valinta);
		monipuuvalintasyotto_tasokehys = monipuuvalintasyotto_valinta.find(".monipuuvalintasyotto_tasokehys");
	}
	else {
		monipuuvalintasyotto_valinta = $("<div class='monipuuvalintasyotto_tasokehys monipuuvalintasyotto_taso_" + taso + "' data-id='" + valinta.id + "' data-taso='" + taso + "'>"
			+ "<span class='monipuuvalintasyotto_valinta_teksti'>" + valinta.nimi + "</span>"
		+ "</div>");
		$(this).closest(".monipuuvalintasyotto_valinta").append(monipuuvalintasyotto_valinta);
		monipuuvalintasyotto_tasokehys = monipuuvalintasyotto_valinta;
	}

	if(taso > 0) {
		monipuuvalintasyotto_valinta.hide();
	}
	
	monipuuvalintasyotto_valinta.click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
	});
	
	if(edellinen_painike != "") {
		monipuuvalintasyotto_tasokehys.find(".monipuuvalintasyotto_valinta_teksti").before(edellinen_painike);
		
		edellinen_painike.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			
			if($(this).closest(".monipuuvalintasyotto_tasokehys").data("taso") == 1) {
				$(this).closest(".monipuuvalintasyotto_valinta").siblings().show();
			}
			
			$(this).closest(".monipuuvalintasyotto_valinta").find(".monipuuvalintasyotto_taso_" + $(this).closest(".monipuuvalintasyotto_tasokehys").data("taso")).hide();
			$(this).closest(".monipuuvalintasyotto_valinta").find(".monipuuvalintasyotto_taso_" + ($(this).closest(".monipuuvalintasyotto_tasokehys").data("taso") - 1)).show();
		});
	}
		
	if(seuraava_painike != "") {
		monipuuvalintasyotto_tasokehys.append(seuraava_painike);
		
		seuraava_painike.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			if($(this).closest(".monipuuvalintasyotto_tasokehys").data("taso") == 0) {
				$(this).closest(".monipuuvalintasyotto_valinta").siblings().hide();
			}
			
			$(this).closest(".monipuuvalintasyotto_valinta").find(".monipuuvalintasyotto_taso_" + $(this).closest(".monipuuvalintasyotto_tasokehys").data("taso")).hide();
			$(this).closest(".monipuuvalintasyotto_valinta").find(".monipuuvalintasyotto_taso_" + ($(this).closest(".monipuuvalintasyotto_tasokehys").data("taso") + 1)).show();
		});
	}
	else if(valitse_painike != "") {
		monipuuvalintasyotto_valinta.append(valitse_painike);
		monipuuvalintasyotto_valinta.append(kentta);
		
		kentta.change(function() {
			if($(this).hasClass("monipuuvalintasyotto_kenttavirhe")) {
				$(this).removeClass("monipuuvalintasyotto_kenttavirhe");
			}
		});
		
		valitse_painike.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			var tiedot = [];
			var monipuuvalintasyotto_teksti = "";
			
			var syottokentta = $(this).siblings(".monipuuvalintasyotto_syottokentta");
			if(tarkista_muuttuja(syottokentta.val(),kenttatyyppi) == "") {
				syottokentta.addClass("monipuuvalintasyotto_kenttavirhe");
			}
			else {
				$(this).closest(".monipuuvalintasyotto_tasokehys").prevUntil(".monipuuvalintasyotto_valinta").each(function() {
					$(this).addClass("monipuuvalintasyotto_rivi_valittu");
					tiedot.push($(this).data("id") + "");
					monipuuvalintasyotto_teksti += $(this).find(".monipuuvalintasyotto_valinta_teksti").html() + " / ";
					//$(this).("")
				});

				tiedot.push($(this).closest(".monipuuvalintasyotto_tasokehys").data("id") + "");
				tiedot.push(syottokentta.val() + "");
				$(this).closest(".monipuuvalintasyotto_valinnat").data("tiedot",tiedot);
				monipuuvalintasyotto_teksti += $(this).closest(".monipuuvalintasyotto_tasokehys").find(".monipuuvalintasyotto_valinta_teksti").html();
				$(this).closest(".monipuuvalintasyottokehys").find(".monipuuvalintasyotto").val(monipuuvalintasyotto_teksti);
				$(this).closest(".monipuuvalintasyottokehys").find(".monipuuvalintasyotto").trigger("change");
				$(this).closest(".monipuuvalintasyotto_valinnat").hide();
			}
		});
	}

	if(valinta.tiedot.length > 0) {
		monipuuvalintasyotto_valinta.monipuuvalintasyotto_taso(valinta.tiedot[0],taso + 1,kenttatyyppi);
	}
};

$.fn.monivalinta = function() {
	var valinnat = arguments[0];
		
	$(this).find(".monivalinta").change(function() {
		if($(this).parent().hasClass("sisaltotaulu_solu_virhe")) {
			$(this).parent().removeClass("sisaltotaulu_solu_virhe");
		}
	});
	
	for(var i = 0; i < valinnat.length; i++)
	{
		var valinta = $("<div class='monivalinta_valinta' data-id='" + valinnat[i].id + "'>"
			+ "<i class='monivalinta_valinta_kuvake fa fa-square-o'></i>"
			+ "<span class='monivalinta_valinta_teksti'>" + valinnat[i].nimi + "</span>"
		+ "</div>");
		
		$(this).find(".monivalinta_valinnat").append(valinta);
		
		valinta.click(function(painiketapahtuma) {
			painiketapahtuma.stopPropagation();
			if($(this).hasClass("monivalinta_valittu") == false) {
				$(this).find(".monivalinta_valinta_kuvake").removeClass("fa-square-o");
				$(this).find(".monivalinta_valinta_kuvake").addClass("fa-check-square-o");
				$(this).addClass("monivalinta_valittu");
			}
			else {
				$(this).find(".monivalinta_valinta_kuvake").removeClass("fa-check-square-o");
				$(this).find(".monivalinta_valinta_kuvake").addClass("fa-square-o");
				$(this).removeClass("monivalinta_valittu");
			}
			var monivalinta = $(this).closest(".monivalintakehys").find(".monivalinta");
			var valitut_valinnat = "";
			var valitut_idt = [];
			$(this).parent(".monivalinta_valinnat").find(".monivalinta_valittu").each(function() {
				valitut_valinnat += "," + $(this).find(".monivalinta_valinta_teksti").html();
				valitut_idt.push($(this).data("id"));
			});
			
			if(valitut_valinnat.length > 0) {
				valitut_valinnat = valitut_valinnat.substring(1);
			}
			
			monivalinta.val(valitut_valinnat).trigger("change");
			$(this).parent(".monivalinta_valinnat").data("valitut_idt",valitut_idt);
			
			if($(this).closest(".monivalintakehys").parent().hasClass("sisaltotaulu_solu_virhe")) {
				$(this).closest(".monivalintakehys").parent().removeClass("sisaltotaulu_solu_virhe");
			}
		});
	}
	
	$(this).find(".monivalinta_valinnat").hide();
	$(this).data("valinnat",valinnat);
	
	$(document).click(function(painiketapahtuma) {
		$(".monivalinta_valinnat").hide();
	});
	
	$(this).click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		var monivalinnat = $(this).find(".monivalinta_valinnat");
		/*
		if(($(this).position().top + $(this).outerHeight() + monivalinnat.outerHeight()) > $(this).closest("tbody").outerHeight()) {
			monivalinnat.css("top",-1 * monivalinnat.outerHeight());
			monivalinnat.css({"border-top":"1px solid #000000"},{"border-bottom":"0px solid #000000"});
		}
		else {
		*/
			monivalinnat.css("top",$(this).outerHeight());
			monivalinnat.css({"border-top":"0px solid #000000"},{"border-bottom":"1px solid #000000"});
		//}

		if(monivalinnat.css("display") == "none") {
			$(".monivalinta_valinnat").hide();
			monivalinnat.show();
		}
		else {
			monivalinnat.hide();
		}
	});
};

$.fn.valintasyotto = function() {
	var valinnat = arguments[0];
	var kentta = arguments[1];
	
	if(valinnat.length > 0) {
		if(valinnat[0].id != "" && valinnat[0].nimi != "Valitse") {
			valinnat.unshift({"id":"","nimi":"Valitse"});
		}
	}
	else {
		valinnat.unshift({"id":"","nimi":"Valitse"});
	}

	$(this).data("kentta",kentta);
	
	var valintakentta = $(this).find(".valintasyotto_lisayskenttarivi select");
	for(var i = 0; i < valinnat.length; i++)
	{
		valintakentta.append("<option value='" + valinnat[i]["id"] + "'>" + valinnat[i]["nimi"] + "</option>");
	}
	
	valintakentta.data("valinnat",valinnat);
	
	$(this).find(".valintasyotto").change(function() {
		if($(this).parent().hasClass("sisaltotaulu_solu_virhe")) {
			$(this).parent().removeClass("sisaltotaulu_solu_virhe");
		}
	});
	
	$(this).find(".valintasyotto_lisayskentta").each(function() {
		$(this).change(function() {
			if($(this).hasClass("valintasyotto_kenttavirhe")) {
				$(this).removeClass("valintasyotto_kenttavirhe");
			}
		});
	});
	
	$(this).find(".valintasyotto_tietokehys").click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
	});

	$(this).find(".valintasyotto_lisayskenttarivi .valintasyotto_lisayskuvake").click(function(painiketapahtuma) {
		var lisayskentta_1 = $(this).closest(".valintasyotto_lisayskenttarivi").find(".valintasyotto_lisayskentta:eq(0)");
		var lisayskentta_2 = $(this).closest(".valintasyotto_lisayskenttarivi").find(".valintasyotto_lisayskentta:eq(1)");

		if(tarkista_muuttuja(lisayskentta_1.val(),"ei_tyhjä") != "" && tarkista_muuttuja(lisayskentta_2.val(),kentta) != "") {
			var valintasyotto_rivi = $("<div class='valintasyotto_tietorivi'>"
				+ "<div class='valintasyotto_tietorivikehys'>"
					+ "<span class='valintasyotto_tietorivi_teksti' data-id='" + lisayskentta_1.val() + "'>" + lisayskentta_1.find("option:selected").text() + "</span>"
					+ "<span class='valintasyotto_tietorivi_teksti'>" + lisayskentta_2.val() + "</span>"
				+ "</div>"
				+ "<i class='valintasyotto_kenttakuvake valintasyotto_muokkaus fa fa-pencil-square-o'></i>"
				+ "<i class='valintasyotto_kenttakuvake valintasyotto_poista fa fa-trash-o'></i>"
			+ "</div>");
			
			$(this).closest(".valintasyotto_tietokehys").find(".valintasyotto_arvot").append(valintasyotto_rivi);
			$(this).closest(".valintasyotto_tietokehys").data("tiedot").push({"tieto1":lisayskentta_1.val(),"tieto2":lisayskentta_2.val()});
			valintasyotto_rivi.find(".valintasyotto_tietorivikehys").css("width",$(this).closest(".valintasyottokehys").find(".valintasyotto").width());
			valintasyotto_rivi.valintasyotto_tietorivi();
			$(this).closest(".valintasyotto_tietokehys").trigger("tietomuutos");
			
			lisayskentta_1.val("");
			lisayskentta_2.val("");
		}
		else {
			if(tarkista_muuttuja(lisayskentta_1.val(),"ei_tyhjä") == "") {
				lisayskentta_1.addClass("valintasyotto_kenttavirhe");
			}
			if(tarkista_muuttuja(lisayskentta_2.val(),kentta) == "") {
				lisayskentta_2.addClass("valintasyotto_kenttavirhe");
			}
		}
	});
	
	$(this).find(".valintasyotto_tietokehys").hide();
	
	$(document).click(function(painiketapahtuma) {
		$(".valintasyotto_tietokehys").hide();
	});
	
	$(this).find(".valintasyotto_tietokehys").on("tietomuutos", function() {
		var tiedot = [];
		var tietoteksti = "";
		$(this).find(".valintasyotto_tietorivi").each(function() {
			var tietotekstit = $(this).find(".valintasyotto_tietorivi_teksti"); 
			var tieto1 = $(tietotekstit[0]).html();
			var tieto2 = $(tietotekstit[1]).html(); 
			tiedot.push({"tieto1":$(tietotekstit[0]).data("id"),"tieto2":tieto2});
			tietoteksti += "," + tieto1 + ":" + tieto2;
		});

		if(tietoteksti.length > 0) {
			tietoteksti = tietoteksti.substring(1);
		}
		$(this).data("tiedot",tiedot);
		$(this).closest(".valintasyottokehys").find(".valintasyotto").val(tietoteksti);
	});
	
	$(this).click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		
		var valintasyotto = $(this).find(".valintasyotto_tietokehys");
		/*
		if(($(this).position().top + $(this).outerHeight() + valintasyotto.outerHeight()) > $(this).closest("tbody").outerHeight()) {
			valintasyotto.css("top",-1 * valintasyotto_tietokehys.outerHeight());
			valintasyotto.css({"border-top":"1px solid #000000"},{"border-bottom":"0px solid #000000"});
		}
		else {
			*/
			valintasyotto.css("top",$(this).outerHeight());
			valintasyotto.css({"border-top":"0px solid #000000"},{"border-bottom":"1px solid #000000"});
		//}
		
		if(valintasyotto.css("display") == "none") {
			valintasyotto.show();
			$(this).find(".valintasyotto_kenttakehys").css("width",$(this).find(".valintasyotto").width());
			$(this).find(".valintasyotto_tietorivikehys").css("width",$(this).find(".valintasyotto").width());
		}
		else {
			valintasyotto.hide();
		}
	});
};

$.fn.valintasyotto_tietorivi = function() {
	var muokkaus_painike = $(this).find(".valintasyotto_muokkaus");
	muokkaus_painike.click(function() {
		var muokattava_rivi = $(this).closest(".valintasyotto_tietorivi");
		muokattava_rivi.addClass("valintasyotto_muokattava_rivi");
		muokattava_rivi.hide();
		
		var muokkaus_rivi = $("<div class='valintasyotto_muokkauskenttarivi'>"
			+ "<div class='valintasyotto_kenttakehys'>"
				+ "<select class='valintasyotto_muokkauskentta'></select>"
				+ "<input class='valintasyotto_muokkauskentta' />"
			+ "</div>"
			+ "<i class='valintasyotto_kenttakuvake valintasyotto_hyvaksy fa fa-check' title='Muuta'></i>"
			+ "<i class='valintasyotto_kenttakuvake valintasyotto_peruuta fa fa-times' title='Peruuta'></i>"
		+ "</div>");
		
		var valinnat = $(this).closest(".valintasyotto_tietokehys").find(".valintasyotto_lisayskenttarivi select").data("valinnat");
		var valintakentta = muokkaus_rivi.find("select");
		for(var i = 0; i < valinnat.length; i++) 
		{
			valintakentta.append("<option value='" + valinnat[i]["id"] + "'>" + valinnat[i]["nimi"] + "</option>");
		}
		
		$(this).closest(".valintasyotto_arvot .valintasyotto_muokattava_rivi").before(muokkaus_rivi);
		muokkaus_rivi.find(".valintasyotto_kenttakehys").css("width",muokkaus_rivi.closest(".valintasyottokehys").find(".valintasyotto").width());
		
		muokkaus_rivi.find(".valintasyotto_muokkauskentta").each(function() {
			$(this).change(function() {
				if($(this).hasClass("valintasyotto_kenttavirhe")) {
					$(this).removeClass("valintasyotto_kenttavirhe");
				}
			});
		});
		
		var muutoskentat = muokkaus_rivi.find(".valintasyotto_muokkauskentta");
		var arvokentat = muokattava_rivi.find(".valintasyotto_tietorivi_teksti");
		$(muutoskentat[0]).val($(arvokentat[0]).data("id"));
		$(muutoskentat[1]).val($(arvokentat[1]).html());
		
		var muutos_painike = muokkaus_rivi.find(".valintasyotto_hyvaksy");
		muutos_painike.click(function() {
			var muutoskentat = $(this).closest(".valintasyotto_muokkauskenttarivi").find(".valintasyotto_muokkauskentta");
			var arvokentat = $(this).closest(".valintasyotto_tietokehys").find(".valintasyotto_muokattava_rivi .valintasyotto_tietorivi_teksti");
			var kentta = $(this).closest(".valintasyottokehys").data("kentta");
			
			if(tarkista_muuttuja($(muutoskentat[0]).val(),"ei_tyhjä") != "" && tarkista_muuttuja($(muutoskentat[1]).val(),kentta) != "") {
				$(arvokentat[0]).html($(muutoskentat[0]).find("option:selected").text());
				$(arvokentat[0]).data("id",$(muutoskentat[0]).val());
				$(arvokentat[1]).html($(muutoskentat[1]).val());
				$(this).closest(".valintasyotto_tietokehys").trigger("tietomuutos");
				$(this).closest(".valintasyotto_tietokehys").find(".valintasyotto_muokattava_rivi").show();
				$(this).closest(".valintasyotto_tietokehys").find(".valintasyotto_muokattava_rivi").removeClass("valintasyotto_muokattava_rivi");
				$(this).closest(".valintasyotto_muokkauskenttarivi").remove();
			}
			else {
				if(tarkista_muuttuja($(muutoskentat[0]).val(),"ei_tyhjä") == "") {
					$(muutoskentat[0]).addClass("valintasyotto_kenttavirhe");
				}
				if(tarkista_muuttuja($(muutoskentat[1]).val(),kentta) == "") {
					$(muutoskentat[1]).addClass("valintasyotto_kenttavirhe");
				}
			}
		});
		
		var peruuta_muutos_painike = muokkaus_rivi.find(".valintasyotto_peruuta");
		peruuta_muutos_painike.click(function() {
			$(this).closest(".valintasyotto_tietokehys").find(".valintasyotto_muokattava_rivi").show();
			$(this).closest(".valintasyotto_tietokehys").find(".valintasyotto_muokattava_rivi").removeClass("valintasyotto_muokattava_rivi");
			$(this).closest(".valintasyotto_muokkauskenttarivi").remove();
		});
	});
	
	var poista_painike = $(this).find(".valintasyotto_poista");
	poista_painike.click(function() {
		var valintasyotto_tietokehys = $(this).closest(".valintasyotto_tietokehys");
		$(this).closest(".valintasyotto_tietorivi").remove();
		valintasyotto_tietokehys.trigger("tietomuutos");	
	});
};

$.fn.monisyotto = function() {
	var kentat = arguments[0];
	
	$(this).data("kentat",kentat);
	
	$(this).find(".monisyotto").change(function() {
		if($(this).parent().hasClass("sisaltotaulu_solu_virhe")) {
			$(this).parent().removeClass("sisaltotaulu_solu_virhe");
		}
	});
	
	$(this).find(".monisyotto_lisayskentta").each(function() {
		$(this).change(function() {
			if($(this).hasClass("monisyotto_kenttavirhe")) {
				$(this).removeClass("monisyotto_kenttavirhe");
			}
		});
	});
	
	$(this).find(".monisyotto_tietokehys").click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
	});

	$(this).find(".monisyotto_lisayskenttarivi .monisyotto_lisayskuvake").click(function(painiketapahtuma) {
		var lisayskentta_1 = $(this).closest(".monisyotto_lisayskenttarivi").find(".monisyotto_lisayskentta:eq(0)");
		var lisayskentta_2 = $(this).closest(".monisyotto_lisayskenttarivi").find(".monisyotto_lisayskentta:eq(1)");

		if(tarkista_muuttuja(lisayskentta_1.val(),kentat[0]) != "" && tarkista_muuttuja(lisayskentta_2.val(),kentat[1]) != "") {
			var monisyotto_rivi = $("<div class='monisyotto_tietorivi'>"
				+ "<div class='monisyotto_tietorivikehys'>"
					+ "<span class='monisyotto_tietorivi_teksti'>" + lisayskentta_1.val() + "</span>"
					+ "<span class='monisyotto_tietorivi_teksti'>" + lisayskentta_2.val() + "</span>"
				+ "</div>"
				+ "<i class='monisyotto_kenttakuvake monisyotto_muokkaus fa fa-pencil-square-o'></i>"
				+ "<i class='monisyotto_kenttakuvake monisyotto_poista fa fa-trash-o'></i>"
			+ "</div>");
			
			$(this).closest(".monisyotto_tietokehys").find(".monisyotto_arvot").append(monisyotto_rivi);
			$(this).closest(".monisyotto_tietokehys").data("tiedot").push({"tieto1":lisayskentta_1.val(),"tieto2":lisayskentta_2.val()});
			monisyotto_rivi.find(".monisyotto_tietorivikehys").css("width",$(this).closest(".monisyottokehys").find(".monisyotto").width());
			monisyotto_rivi.monisyotto_tietorivi();
			$(this).closest(".monisyotto_tietokehys").trigger("tietomuutos");
			
			lisayskentta_1.val("");
			lisayskentta_2.val("");
		}
		else {
			if(tarkista_muuttuja(lisayskentta_1.val(),kentat[0]) == "") {
				lisayskentta_1.addClass("monisyotto_kenttavirhe");
			}
			if(tarkista_muuttuja(lisayskentta_2.val(),kentat[1]) == "") {
				lisayskentta_2.addClass("monisyotto_kenttavirhe");
			}
		}
	});
	
	$(this).find(".monisyotto_tietokehys").hide();
	
	$(document).click(function(painiketapahtuma) {
		$(".monisyotto_tietokehys").hide();
	});
	
	$(this).find(".monisyotto_tietokehys").on("tietomuutos", function() {
		var tiedot = [];
		var tietoteksti = "";
		$(this).find(".monisyotto_tietorivi").each(function() {
			var tietotekstit = $(this).find(".monisyotto_tietorivi_teksti"); 
			var tieto1 = $(tietotekstit[0]).html();
			var tieto2 = $(tietotekstit[1]).html(); 
			tiedot.push({"tieto1":tieto1,"tieto2":tieto2});
			tietoteksti += "," + tieto1 + ":" + tieto2;
		});

		if(tietoteksti.length > 0) {
			tietoteksti = tietoteksti.substring(1);
		}
		$(this).data("tiedot",tiedot);
		$(this).closest(".monisyottokehys").find(".monisyotto").val(tietoteksti);
	});
	
	$(this).click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		
		var monisyotto = $(this).find(".monisyotto_tietokehys");
		/*
		if(($(this).position().top + $(this).outerHeight() + monisyotto.outerHeight()) > $(this).closest("tbody").outerHeight()) {
			monisyotto.css("top",-1 * monisyotto_tietokehys.outerHeight());
			monisyotto.css({"border-top":"1px solid #000000"},{"border-bottom":"0px solid #000000"});
		}
		else {
			*/
			monisyotto.css("top",$(this).outerHeight());
			monisyotto.css({"border-top":"0px solid #000000"},{"border-bottom":"1px solid #000000"});
		//}
		
		if(monisyotto.css("display") == "none") {
			monisyotto.show();
			$(this).find(".monisyotto_kenttakehys").css("width",$(this).find(".monisyotto").width());
			$(this).find(".monisyotto_tietorivikehys").css("width",$(this).find(".monisyotto").width());
		}
		else {
			monisyotto.hide();
		}
	});
};

$.fn.monisyotto_tietorivi = function() {
	var muokkaus_painike = $(this).find(".monisyotto_muokkaus");
	muokkaus_painike.click(function() {
		var muokattava_rivi = $(this).closest(".monisyotto_tietorivi");
		muokattava_rivi.addClass("monisyotto_muokattava_rivi");
		muokattava_rivi.hide();
		
		var muokkaus_rivi = $("<div class='monisyotto_muokkauskenttarivi'>"
			+ "<div class='monisyotto_kenttakehys'>"
				+ "<input class='monisyotto_muokkauskentta' />"
				+ "<input class='monisyotto_muokkauskentta' />"
			+ "</div>"
			+ "<i class='monisyotto_kenttakuvake monisyotto_hyvaksy fa fa-check' title='Muuta'></i>"
			+ "<i class='monisyotto_kenttakuvake monisyotto_peruuta fa fa-times' title='Peruuta'></i>"
		+ "</div>");
		
		$(this).closest(".monisyotto_arvot .monisyotto_muokattava_rivi").before(muokkaus_rivi);
		muokkaus_rivi.find(".monisyotto_kenttakehys").css("width",muokkaus_rivi.closest(".monisyottokehys").find(".monisyotto").width());
		
		muokkaus_rivi.find(".monisyotto_muokkauskentta").each(function() {
			$(this).change(function() {
				if($(this).hasClass("monisyotto_kenttavirhe")) {
					$(this).removeClass("monisyotto_kenttavirhe");
				}
			});
		});
		
		var muutoskentat = muokkaus_rivi.find(".monisyotto_muokkauskentta");
		var arvokentat = muokattava_rivi.find(".monisyotto_tietorivi_teksti");
		$(muutoskentat[0]).val($(arvokentat[0]).html());
		$(muutoskentat[1]).val($(arvokentat[1]).html());
		
		var muutos_painike = muokkaus_rivi.find(".monisyotto_hyvaksy");
		muutos_painike.click(function() {
			var muutoskentat = $(this).closest(".monisyotto_muokkauskenttarivi").find(".monisyotto_muokkauskentta");
			var arvokentat = $(this).closest(".monisyotto_tietokehys").find(".monisyotto_muokattava_rivi .monisyotto_tietorivi_teksti");
			var kentat = $(this).closest(".monisyottokehys").data("kentat");
			
			if(tarkista_muuttuja($(muutoskentat[0]).val(),kentat[0]) != "" && tarkista_muuttuja($(muutoskentat[1]).val(),kentat[1]) != "") {
				$(arvokentat[0]).html($(muutoskentat[0]).val());
				$(arvokentat[1]).html($(muutoskentat[1]).val());
				$(this).closest(".monisyotto_tietokehys").trigger("tietomuutos");
				$(this).closest(".monisyotto_tietokehys").find(".monisyotto_muokattava_rivi").show();
				$(this).closest(".monisyotto_tietokehys").find(".monisyotto_muokattava_rivi").removeClass("monisyotto_muokattava_rivi");
				$(this).closest(".monisyotto_muokkauskenttarivi").remove();
			}
			else {
				if(tarkista_muuttuja($(muutoskentat[0]).val(),kentat[0]) == "") {
					$(muutoskentat[0]).addClass("monisyotto_kenttavirhe");
				}
				if(tarkista_muuttuja($(muutoskentat[1]).val(),kentat[1]) == "") {
					$(muutoskentat[1]).addClass("monisyotto_kenttavirhe");
				}
			}
		});
		
		var peruuta_muutos_painike = muokkaus_rivi.find(".monisyotto_peruuta");
		peruuta_muutos_painike.click(function() {
			$(this).closest(".monisyotto_tietokehys").find(".monisyotto_muokattava_rivi").show();
			$(this).closest(".monisyotto_tietokehys").find(".monisyotto_muokattava_rivi").removeClass("monisyotto_muokattava_rivi");
			$(this).closest(".monisyotto_muokkauskenttarivi").remove();
		});
	});
	
	var poista_painike = $(this).find(".monisyotto_poista");
	poista_painike.click(function() {
		var monisyotto_tietokehys = $(this).closest(".monisyotto_tietokehys");
		$(this).closest(".monisyotto_tietorivi").remove();
		monisyotto_tietokehys.trigger("tietomuutos");	
	});
};

$.fn.kytkin = function() {
	$(this).click(function() {
		if($(this).data("aktiivinen") == "-1") {
			if($(this).data("edellinen_tila") == "1") {
				$(this).data("aktiivinen","0");
				$(this).data("edellinen_tila","1");
				$(this).removeClass("kytkinkehys_ei_maaritelty");
				$(this).addClass("kytkinkehys_ei_aktiivinen");
				$(this).find(".kytkinvipu").removeClass("kytkinvipu_ei_maaritelty");
				$(this).find(".kytkinvipu").addClass("kytkinvipu_ei_aktiivinen");
			}
			else {
				$(this).data("aktiivinen","1");
				$(this).data("edellinen_tila","0");
				$(this).removeClass("kytkinkehys_ei_maaritelty");
				$(this).addClass("kytkinkehys_aktiivinen");
				$(this).find(".kytkinvipu").removeClass("kytkinvipu_ei_maaritelty");
				$(this).find(".kytkinvipu").addClass("kytkinvipu_aktiivinen");
			}
		}
		else if($(this).data("aktiivinen") == "1") {
			$(this).data("aktiivinen","-1");
			$(this).data("edellinen_tila","1");
			$(this).removeClass("kytkinkehys_aktiivinen");
			$(this).addClass("kytkinkehys_ei_maaritelty");
			$(this).find(".kytkinvipu").removeClass("kytkinvipu_aktiivinen");
			$(this).find(".kytkinvipu").addClass("kytkinvipu_ei_maaritelty");
		}
		else {
			$(this).data("aktiivinen","-1");
			$(this).data("edellinen_tila","0");
			$(this).removeClass("kytkinkehys_ei_aktiivinen");
			$(this).addClass("kytkinkehys_ei_maaritelty");
			$(this).find(".kytkinvipu").removeClass("kytkinvipu_ei_aktiivinen");
			$(this).find(".kytkinvipu").addClass("kytkinvipu_ei_maaritelty");
		}
		
		if($(this).parent().hasClass("sisaltotaulu_solu_virhe")) {
			$(this).parent().removeClass("sisaltotaulu_solu_virhe");
		}
	});
};

$.fn.aikavali = function() {
	var alkupvm_kentta = $(this).find(".aikavali_alkupvm_kehys .aikavali_pvmkentta");
	var loppupvm_kentta = $(this).find(".aikavali_loppupvm_kehys .aikavali_pvmkentta");
	var alkupvm_tyhjennys = $(this).find(".aikavali_alkupvm_kehys .aikavali_pvm_tyhjennys_kuvake");
	var loppupvm_tyhjennys = $(this).find(".aikavali_loppupvm_kehys .aikavali_pvm_tyhjennys_kuvake");
	alkupvm_tyhjennys.hide();
	loppupvm_tyhjennys.hide();
	
	alkupvm_kentta.datepicker({
		dateFormat: "dd.mm.yy",
		monthNames: ["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"],
		dayNamesMin: ["Su","Ma","Ti","Ke","To","Pe","La"],
		showOtherMonths: true,
		numberOfMonths: 1,
		weekHeader: "Vk",
		firstDay: 1,
		prevText:"Edellinen",
		nextText:"Seuraava",
		showWeek: true,
		onSelect: function(pvm) {
			loppupvm_kentta.datepicker("option","minDate",pvm);
			alkupvm_tyhjennys.show();
		}
	});
	
	alkupvm_tyhjennys.click(function() {
		$.datepicker._clearDate($(this).siblings(".aikavali_pvmkentta"));
		$(this).hide();
	});
	
	loppupvm_kentta.datepicker({
		dateFormat: "dd.mm.yy",
		monthNames: ["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"],
		dayNamesMin: ["Su","Ma","Ti","Ke","To","Pe","La"],
		showOtherMonths: true,
		numberOfMonths: 1,
		weekHeader: "Vk",
		firstDay: 1,
		prevText:"Edellinen",
		nextText:"Seuraava",
		showWeek: true,
		onSelect: function(pvm) {
			alkupvm_kentta.datepicker("option","maxDate",pvm);
			loppupvm_tyhjennys.show();
		}
	});
	
	loppupvm_tyhjennys.click(function() {
		$.datepicker._clearDate($(this).siblings(".aikavali_pvmkentta"));
		$(this).hide();
	});
};

$.fn.varivalinta = function() {
	var varivalinta = $(this).find(".varivalinta");
	var leveys = $(this).find(".varikehys").width();
	var varikartta_korkeus = $(this).find(".varikarttakehys").height();
	var varikaista_korkeus = $(this).find(".varikaistakehys").height();
	$(this).find(".varikarttakehys").append("<canvas class='varikartta' width=" + leveys + "px' height='" + varikartta_korkeus + "px'></canvas>");
	$(this).find(".varikaistakehys").append("<canvas class='varikaista' width='" + leveys + "px' height='" + varikaista_korkeus + "px'></canvas>");
	
	var varikartta = $(this).find(".varikartta");
	varikartta.click(function(painiketapahtuma) {
		var varikartta_alue = $(this)[0].getContext("2d");
		var varitiedot = varikartta_alue.getImageData(painiketapahtuma.offsetX,painiketapahtuma.offsetY,1,1).data;
		$(this).closest(".varivalintakehys").find(".varivalinta").css("background-color","rgba(" + varitiedot[0] + "," + varitiedot[1] + "," + varitiedot[2] + ",1)");
		$(this).closest(".varivalintakehys").find(".varivalinta").data("tiedot",varitiedot[0] + "," + varitiedot[1] + "," + varitiedot[2]);
	});
	
	var varikaista = $(this).find(".varikaista");

	var varikaista_alue = varikaista[0].getContext("2d");
	varikaista_alue.rect(0,0,leveys,varikaista_korkeus);
	var varikaista_alue_varitys = varikaista_alue.createLinearGradient(0,0,leveys,0);
	varikaista_alue_varitys.addColorStop(0,"rgba(255,0,0,1)");
	varikaista_alue_varitys.addColorStop(0.17,"rgba(255,255,0,1)");
	varikaista_alue_varitys.addColorStop(0.34,"rgba(0,255,0,1)");
	varikaista_alue_varitys.addColorStop(0.51,"rgba(0,255,255,1)");
	varikaista_alue_varitys.addColorStop(0.68,"rgba(0,0,255,1)");
	varikaista_alue_varitys.addColorStop(0.85,"rgba(255,0,255,1)");
	varikaista_alue_varitys.addColorStop(1,"rgba(255,0,0,1)");
	varikaista_alue.fillStyle = varikaista_alue_varitys;
	varikaista_alue.fill();
	
	varikaista.click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		var leveys = $(this).closest(".varikehys").width();
		var varikartta_korkeus = $(this).closest(".varikehys").find(".varikarttakehys").height();
		var varikartta = $(this).closest(".varikehys").find(".varikartta")[0];
		var varikartta_alue = varikartta.getContext("2d");
		var varikaista_alue = $(this)[0].getContext("2d");
		
		var varitiedot = varikaista_alue.getImageData(painiketapahtuma.offsetX,painiketapahtuma.offsetY,1,1).data;
		varikartta_alue.fillStyle = "rgba(" + varitiedot[0] + "," + varitiedot[1] + "," + varitiedot[2] + ",1)";
		varikartta_alue.fillRect(0,0,leveys,varikartta_korkeus);
		
		var varikartta_alue_varitys_valkoinen = varikartta_alue.createLinearGradient(0,0,leveys,0);
		varikartta_alue_varitys_valkoinen.addColorStop(0,"rgba(255,255,255,1)");
		varikartta_alue_varitys_valkoinen.addColorStop(1,"rgba(255,255,255,0)");
		varikartta_alue.fillStyle = varikartta_alue_varitys_valkoinen;
		varikartta_alue.fillRect(0,0,leveys,varikartta_korkeus);
		
		var varikartta_alue_varitys_musta = varikartta_alue.createLinearGradient(0,0,0,varikartta_korkeus);
		varikartta_alue_varitys_musta.addColorStop(0,"rgba(0,0,0,0)");
		varikartta_alue_varitys_musta.addColorStop(1,"rgba(0,0,0,1)");
		varikartta_alue.fillStyle = varikartta_alue_varitys_musta;
		varikartta_alue.fillRect(0,0,leveys,varikartta_korkeus);
	});
	
	$(this).find(".varikehys").hide();
	
	$(document).click(function(painiketapahtuma) {
		$(".varikehys").hide();
	});
	
	$(this).click(function(painiketapahtuma) {
		painiketapahtuma.stopPropagation();
		var varikehys = $(this).find(".varikehys");
		/*
		if(($(this).position().top + $(this).outerHeight() + varikehys.outerHeight()) > $(this).closest("tbody").outerHeight()) {
			varikehys.css("top",-1 * varikehys.outerHeight());
			varikehys.css({"border-top":"2px solid #000000"},{"border-bottom":"0px solid #000000"});
		}
		else {
			varikehys.css("top",$(this).outerHeight());
			varikehys.css({"border-top":"0px solid #000000"},{"border-bottom":"2px solid #000000"});
		}
		*/
		varikehys.css("top",$(this).outerHeight());
		varikehys.css({"border-top":"0px solid #000000"},{"border-bottom":"2px solid #000000"});
		
		if(varikehys.css("display") == "none") {
			varikehys.show();
		}
		else {
			varikehys.hide();
		}
	});
};

$.fn.siirra_painike = function() {
	var tyyppi = arguments[0];
	
	if(tyyppi == "sisaltotaulu_kategoriat") {
		$(this).click(function() {
			$(this).closest("table").find(".muokattava_rivi").show();
			$(this).closest("table").find(".muokattava_rivi").removeClass("muokattava_rivi");
			$(this).closest("table").find(".sisaltotaulu_muokkausrivi").remove();
	
			luo_ilmoitusviesti("ilmoitus","Siirtotila aktivoitu");
			$(this).closest("tr").addClass("sisaltotaulu_siirtorivi");
			$(this).closest("tbody").find("tr").not(".sisaltotaulu_siirtorivi").addClass("sisaltotaulu_siirtopaikka");
			
			$(this).closest("tbody").find("td:last-child").each(function() {
				$(this).find(".sisaltotaulu_painike").hide();
			});
			
			$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
				$(this).find(".sisaltotaulu_painike").hide();
			});
			
			$(this).parent().append(
				"<i class='sisaltotaulu_painike sisaltotaulu_peruuta_siirto fa fa-times' title='Peruuta'></i>"
			);
			
			$(this).siblings(".sisaltotaulu_peruuta_siirto").click(function() {
				luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").off("click");
				$(this).closest("tbody").find("tr").not(".sisaltotaulu_siirtorivi").removeClass("sisaltotaulu_siirtopaikka");
				
				$(this).closest("tbody").find("td:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				$(this).closest("tr").removeClass("sisaltotaulu_siirtorivi");
				$(this).remove();
			});
			
			$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").click(function() {
				luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").off("click");
				$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				vaihda_kategoria_jarjestysluku($(".sisaltotaulu_siirtorivi"),$(this));
			});
		});	
	}
	else if(tyyppi == "sisaltotaulu_kohteet")
	{
		$(this).click(function() {
			$(this).closest("table").find(".muokattava_rivi").show();
			$(this).closest("table").find(".muokattava_rivi").removeClass("muokattava_rivi");
			$(this).closest("table").find(".sisaltotaulu_muokkausrivi").remove();

			luo_ilmoitusviesti("ilmoitus","Siirtotila aktivoitu");
			$(this).closest("tr").addClass("sisaltotaulu_siirtorivi");
			var valittu_kategoria = $(this).closest("tr").find("td:eq(0)").html();
			
			$(this).closest("tbody").find("tr").not(".sisaltotaulu_siirtorivi").each(function() {
				if(valittu_kategoria == $(this).closest("tr").find("td:eq(0)").html()) {
					$(this).addClass("sisaltotaulu_siirtopaikka");
				}
			});
			
			$(this).closest("tbody").find("td:last-child").each(function() {
				$(this).find(".sisaltotaulu_painike").hide();
			});
			
			$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
				$(this).find(".sisaltotaulu_painike").hide();
			});
			
			$(this).parent().append(
				"<i class='sisaltotaulu_painike sisaltotaulu_peruuta_siirto fa fa-times' title='Peruuta'></i>"
			);
			
			$(this).siblings(".sisaltotaulu_peruuta_siirto").click(function() {
				luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").off("click");
				$(this).closest("tbody").find("tr").not(".sisaltotaulu_siirtorivi").removeClass("sisaltotaulu_siirtopaikka");
				
				$(this).closest("tbody").find("td:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				$(this).closest("tr").removeClass("sisaltotaulu_siirtorivi");
				$(this).remove();
			});
			
			$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").click(function() {
				luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").off("click");
				$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				vaihda_kohde_jarjestysluku($(".sisaltotaulu_siirtorivi"),$(this));
			});
		});	
	}
	else if(tyyppi == "sisaltotaulu_attribuutit") {
		$(this).click(function() {
			$(this).closest("table").find(".muokattava_rivi").show();
			$(this).closest("table").find(".muokattava_rivi").removeClass("muokattava_rivi");
			$(this).closest("table").find(".sisaltotaulu_muokkausrivi").remove();
	
			luo_ilmoitusviesti("ilmoitus","Siirtotila aktivoitu");
			$(this).closest("tr").addClass("sisaltotaulu_siirtorivi");
			$(this).closest("tbody").find("tr").not(".sisaltotaulu_siirtorivi").addClass("sisaltotaulu_siirtopaikka");
			
			$(this).closest("tbody").find("td:last-child").each(function() {
				$(this).find(".sisaltotaulu_painike").hide();
			});
			
			$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
				$(this).find(".sisaltotaulu_painike").hide();
			});
			
			$(this).parent().append(
				"<i class='sisaltotaulu_painike sisaltotaulu_peruuta_siirto fa fa-times' title='Peruuta'></i>"
			);
			
			$(this).siblings(".sisaltotaulu_peruuta_siirto").click(function() {
				luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").off("click");
				$(this).closest("tbody").find("tr").not(".sisaltotaulu_siirtorivi").removeClass("sisaltotaulu_siirtopaikka");
				
				$(this).closest("tbody").find("td:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				$(this).closest("tr").removeClass("sisaltotaulu_siirtorivi");
				$(this).remove();
			});
			
			$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").click(function() {
				luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				$(this).closest("tbody").find(".sisaltotaulu_siirtopaikka").off("click");
				$(this).closest("table").find(".otsikkorivi th:last-child").each(function() {
					$(this).find(".sisaltotaulu_painike").show();
				});
				
				vaihda_attribuutti_jarjestysluku($(".sisaltotaulu_siirtorivi"),$(this));
			});
		});	
	}
}

$.fn.sahkoposti_painike = function() {
	var tyyppi = arguments[0];
	
	if(tyyppi == "sisaltotaulu_viestit") {
		$(this).click(function() {
			var valittu_rivi = $(this).closest("tr");
			var viesti_aihe = valittu_rivi.find("td:eq(0)").html();
			var viesti_sisalto = valittu_rivi.find("td:eq(1)").html();
			window.open("mailto:?to=&subject=" + encodeURIComponent("Viestinvälitys Ulkoile Kokkola palvelusta - " + viesti_aihe) + "&body=" + encodeURIComponent(viesti_sisalto));
		});
	}
};

$.fn.tekstiviesti_painike = function() {
	var tyyppi = arguments[0];
	
	if(tyyppi == "sisaltotaulu_viestit") {
		
	}
};

$.fn.aineisto_painike = function() {
	var tyyppi = arguments[0];
	
	if(tyyppi == "sisaltotaulu_kohteet") {
		$(this).click(function() {
			
		});
	}
};

$.fn.pudotusvalikko = function() {
	var pudotusvalikko = $("<div class='pudotusvalikko'></div>");
	var kehys_id = arguments[0].kehys_id;
	var pudotusvalikko_sisaltotiedot = arguments[0].tiedot;

	for(var i = 0; i < pudotusvalikko_sisaltotiedot.length; i++)
	{
		var pudotusvalikko_otsikkokehys = $("<div id='pudotusvalikko_" + kehys_id + "-" + i + "' class='pudotusvalikko_otsikkokehys pudotuskehys'>"
			+ "<i class='fa fa-caret-right'></i>" 
			+ "<span class='pudotuskehys_otsikko'>" + pudotusvalikko_sisaltotiedot[i].nimi + "</span>"
			+ "</div>"
		);
		
		var pudotusvalikko_sisaltokehys = $("<div class='pudotusvalikko_sisaltokehys'></div>");
		
		pudotusvalikko.append(pudotusvalikko_otsikkokehys);
		pudotusvalikko.append(pudotusvalikko_sisaltokehys);
		$(this).append(pudotusvalikko);
		
		var toimintofunktio = pudotusvalikko_sisaltotiedot[i].toiminto;
		pudotusvalikko_otsikkokehys.data("toiminto",toimintofunktio);
		
		pudotusvalikko_otsikkokehys.click(function() {
			var nykyinen_id = $(this);
			var edellinen_id = "";

			if($(".pudotuskehys_aktiivinen").length > 0) {
				edellinen_id = $(".pudotuskehys_aktiivinen").first();
			}
			
			if(edellinen_id != "") { 
				if($(edellinen_id).prop("id") != $(nykyinen_id).prop("id")) {
					if($(edellinen_id).hasClass("pudotuskehys_avattu")) {
						$(edellinen_id).removeClass("pudotuskehys_aktiivinen");
						$(edellinen_id).addClass("pudotuskehys");
						$(edellinen_id).removeClass("pudotuskehys_avattu");
						$(edellinen_id).find("i").removeClass("fa-caret-down");
						$(edellinen_id).find("i").addClass("fa-caret-right");
						$(edellinen_id).next(".pudotusvalikko_sisaltokehys").removeClass("pudotusvalikko_sisaltokehys_avattu");
					}
					
					$(nykyinen_id).removeClass("pudotuskehys");
					$(nykyinen_id).addClass("pudotuskehys_aktiivinen");
				}
				else {
					$(nykyinen_id).removeClass("pudotuskehys_aktiivinen");
					$(nykyinen_id).addClass("pudotuskehys");
				}
			}
			else {
				$(nykyinen_id).removeClass("pudotuskehys");
				$(nykyinen_id).addClass("pudotuskehys_aktiivinen");
			}
			
			if($(nykyinen_id).hasClass("pudotuskehys_avattu")) {
				$(nykyinen_id).removeClass("pudotuskehys_aktiivinen");
				$(nykyinen_id).addClass("pudotuskehys");
				$(nykyinen_id).removeClass("pudotuskehys_avattu");
				$(nykyinen_id).find("i").removeClass("fa-caret-down");
				$(nykyinen_id).find("i").addClass("fa-caret-right");
				$(nykyinen_id).next(".pudotusvalikko_sisaltokehys").removeClass("pudotusvalikko_sisaltokehys_avattu");
			}
			else {
				$(nykyinen_id).addClass("pudotuskehys_avattu");
				$(nykyinen_id).find("i").removeClass("fa-caret-right");
				$(nykyinen_id).find("i").addClass("fa-caret-down");
				$(nykyinen_id).next(".pudotusvalikko_sisaltokehys").addClass("pudotusvalikko_sisaltokehys_avattu");
				
				var id = $(nykyinen_id).prop("id").replace("pudotusvalikko_","");
				$(nykyinen_id).data("toiminto")(id);
			}
		});
	}
};

$.fn.valilehtinakyma = function() {
	var navigaatiokehys = $("<div class='valilehti_navigaatiokehys'></div>");
	var sisaltokehys = $("<div class='valilehti_sisaltokehys'></div>");
	var nakymat = arguments[0];
	for(var i = 0; i < nakymat.length; i++)
	{
		navigaatiokehys.append("<div id='valilehti_navigaatio_painike_" + i + "' class='valilehti_navigaatiopainike' data-nakyma='" + nakymat[i] + "'>" + nakymat[i] + "</div>");
		sisaltokehys.append("<div id='valilehti_sisaltonakyma_" + i + "' class='valilehti_sisaltonakyma'></div>");
	}

	$(this).append(navigaatiokehys);
	$(this).append(sisaltokehys);
	
	$(".valilehti_navigaatiopainike").click(function() {
		var edellinen_id = "";
		if($(".valilehti_navigaatiopainike_valittu").length > 0) {
			edellinen_id = $(".valilehti_navigaatiopainike_valittu").prop("id").replace("valilehti_navigaatio_painike_","");
		}
		var nykyinen_id = $(this).prop("id").replace("valilehti_navigaatio_painike_","");
		
		if(edellinen_id != nykyinen_id) {
			if(edellinen_id != "") {
				$("#valilehti_navigaatio_painike_" + edellinen_id).removeClass("valilehti_navigaatiopainike_valittu");
				$("#valilehti_navigaatio_painike_" + edellinen_id).addClass("valilehti_navigaatiopainike");
				$("#valilehti_sisaltonakyma_" + edellinen_id).hide();
			}
			
			$("#valilehti_navigaatio_painike_" + nykyinen_id).removeClass("valilehti_navigaatiopainike");
			$("#valilehti_navigaatio_painike_" + nykyinen_id).addClass("valilehti_navigaatiopainike_valittu");
			$("#valilehti_sisaltonakyma_" + nykyinen_id).show();
			
			alusta_nakyma(nykyinen_id,$(this).data("nakyma"));
		}
	});
};

function hae_kartta_kohteet() 
{
	var toiminnon_siirto = $.Deferred();
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kartta_kohteet.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}

				toiminnon_siirto.resolve(tiedot);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kartta_kohde_tiedot() 
{
	var toiminnon_siirto = $.Deferred();
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kartta_kohde_tiedot.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}

				toiminnon_siirto.resolve(tiedot);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kartta_aineisto(k_aineistotunnus)
{
	var toiminnon_siirto = $.Deferred();
	
	if(k_aineistotunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kartta_aineisto.php",
			data: { aineistotunnus:k_aineistotunnus, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				toiminnon_siirto.resolve(tiedot);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function kopioi_kartta_aineisto()
{
	var toiminnon_siirto = $.Deferred();
	
	var k_lahde_aineistotunnus = "";
	var k_kohde_aineistotunnus = "";
	
	if($("#karttavalikko_aineistovalinta_lahde").val() != "") {
		k_lahde_aineistotunnus = $("#karttavalikko_aineistovalinta_lahde").val();
	}
	
	if($("#karttavalikko_aineistovalinta_kohde").val() != "") {
		k_kohde_aineistotunnus = $("#karttavalikko_aineistovalinta_kohde").val();
	}
	
	if(k_lahde_aineistotunnus == "") {
		$("#k_lahde_aineistotunnus").addClass("karttavalikko_kenttavirhe");
		toiminnon_siirto.reject();
		return toiminnon_siirto;
	}
	
	if(k_kohde_aineistotunnus == "") {
		$("#karttavalikko_aineistovalinta_kohde").addClass("karttavalikko_kenttavirhe");
		toiminnon_siirto.reject();
		return toiminnon_siirto;
	}
	
	if(k_kohde_aineistotunnus == k_lahde_aineistotunnus) {
		$("#karttavalikko_aineistovalinta_kohde").addClass("karttavalikko_kenttavirhe");
		toiminnon_siirto.reject();
		return toiminnon_siirto;
	}
	
	if(k_lahde_aineistotunnus != "" && k_kohde_aineistotunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/kopioi_kartta_aineisto.php",
			data: { lahde_aineistotunnus:k_lahde_aineistotunnus, kohde_aineistotunnus:k_kohde_aineistotunnus, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				luo_ilmoitusviesti("ilmoitus","Aineiston kopiointi onnistui");
				$("#karttavalikko_aineistovalinta_lahde").val("");
				$("#karttavalikko_aineistovalinta_kohde").val("");
				
				$.when(hae_kartta_kohde_tiedot()).then(function(kartta_kohde_tiedot) {
					aseta_karttavalikko_kohde_tiedot(kartta_kohde_tiedot);
				});
				
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function tallenna_kartta_aineisto(tiedot)
{
	var toiminnon_siirto = $.Deferred();
	
	var kartta_koordinaatit = "";
	if(tiedot != "") {
		if(tiedot.geometry.type == "Point") {
			kartta_koordinaatit = [];
			kartta_koordinaatit.push(tiedot.geometry.coordinates);
		}
		else if(tiedot.geometry.type == "LineString") {
			kartta_koordinaatit = tiedot.geometry.coordinates;
		}
	}
	
	var valittu_aineistotunnus = $("#karttavalikko_kohde_" + valittu_kohde_id).data("aineistotunnus");

	if(valittu_aineistotunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_kartta_aineisto.php",
			data: { aineistotunnus:valittu_aineistotunnus, koordinaatit:kartta_koordinaatit, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				luo_ilmoitusviesti("ilmoitus","Aineiston tallennus onnistui");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_aineisto(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var a_jarjestysluku = "";
	var a_leveysaste = "";
	var a_pituusaste = "";
	var a_aineistotunnus = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") { 
		a_jarjestysluku = tarkista_muuttuja(hakurivi.find("th:eq(0) input").val(),"ei_tyhjä");
		a_leveysaste = tarkista_muuttuja(hakurivi.find("th:eq(1) input").val(),"ei_tyhjä");
		a_pituusaste = tarkista_muuttuja(hakurivi.find("th:eq(2) input").val(),"ei_tyhjä");
		a_aineistotunnus = tarkista_muuttuja(hakurivi.find("th:eq(3) select").val(),"ei_tyhjä");
	}

	if(a_aineistotunnus != "" && kayttajatunnus != "") {	
		$.ajax({
			method: "POST",
			url: "php/hae_aineisto.php",
			data: { jarjestysluku:a_jarjestysluku, leveysaste:a_leveysaste, pituusaste:a_pituusaste, aineistotunnus:a_aineistotunnus, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				for(var i = 0; i < tiedot.length; i++) 
				{
					var rivitila = "";
					
					var kohde_nimi = "";
					for(var j = 0; j < aineistotunnus_valinnat.length; j++)
					{
						if(tiedot[i].aineistotunnus == aineistotunnus_valinnat[j].id) {
							kohde_nimi = aineistotunnus_valinnat[j].nimi;
							break;
						}
					}
					
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].aineisto_id,
						}, 
						solut: [
							{"arvo":tiedot[i].jarjestysluku,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].leveysaste,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].pituusaste,"tiedot":"","kentta":""},
							{"arvo":kohde_nimi,"tiedot":tiedot[i].aineistotunnus,"kentta":""}
						],
						tallennus: tallenna_aineisto,
						poisto: poista_aineisto
					});
				}
				
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function tallenna_aineisto(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var a_aineisto_id = "";
	var a_jarjestysluku = "";
	var a_leveysaste = "";
	var a_pituusaste = "";
	var a_aineistotunnus = "";

	if("rivi_id" in rivitunniste.data()) {
		a_aineisto_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(a_aineisto_id == "") {
		a_jarjestysluku = tarkista_muuttuja(rivitunniste.find("th:eq(0) input").val(),"numero");
		a_leveysaste = tarkista_muuttuja(rivitunniste.find("th:eq(1) input").val(),"ei_tyhjä");
		a_pituusaste = tarkista_muuttuja(rivitunniste.find("th:eq(2) input").val(),"ei_tyhjä");
		a_aineistotunnus = tarkista_muuttuja(rivitunniste.find("th:eq(3) select").val(),"ei_tyhjä");
		
		if(a_jarjestysluku == "") {
			rivitunniste.find("th:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_leveysaste == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_pituusaste == "") {
			rivitunniste.find("th:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_aineistotunnus == "") {
			rivitunniste.find("th:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		a_jarjestysluku = tarkista_muuttuja(rivitunniste.find("td:eq(0) input").val(),"numero");
		a_leveysaste = tarkista_muuttuja(rivitunniste.find("td:eq(1) input").val(),"ei_tyhjä");
		a_pituusaste = tarkista_muuttuja(rivitunniste.find("td:eq(2) input").val(),"ei_tyhjä");
		a_aineistotunnus = tarkista_muuttuja(rivitunniste.find("td:eq(3) select").val(),"ei_tyhjä");
		
		if(a_jarjestysluku == "") {
			rivitunniste.find("td:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_leveysaste == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_pituusaste == "") {
			rivitunniste.find("td:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_aineistotunnus == "") {
			rivitunniste.find("td:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(a_jarjestysluku != "" && a_leveysaste != "" && a_pituusaste != "" && a_aineistotunnus != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_aineisto.php",
			data: { aineisto_id:a_aineisto_id, jarjestysluku:a_jarjestysluku, leveysaste:a_leveysaste, pituusaste:a_pituusaste, aineistotunnus:a_aineistotunnus, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_aineisto(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var a_aineisto_id = rivitunniste.data("rivi_id");

	if(a_aineisto_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_aineisto.php",
			data: { aineisto_id:a_aineisto_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}

				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_kohde_aineistotunnus_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	aineistotunnus_valinnat = [];
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kohde_aineistotunnus_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				aineistotunnus_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					aineistotunnus_valinnat.push({"id":tiedot[i].id,"nimi":tiedot[i].nimi});
				}	
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kohde_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	kohde_valinnat = [];
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kohde_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				kohde_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					kohde_valinnat.push({"id":tiedot[i].kohde_id,"nimi":tiedot[i].nimi});
				}	
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kohde_tila_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	kohde_tila_valinnat = [];
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kohde_tila_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				kohde_tila_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					kohde_tila_valinnat.push({"tieto1_id":tiedot[i].kohde_id,"tieto2_id":tiedot[i].tila_id});
				}	
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kohde_attribuutti_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	kohde_attribuutti_valinnat = [];
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kohde_attribuutti_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				kohde_attribuutti_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					var attribuutti_tiedot = [];
					for(var j = 0; j < tiedot[i].attribuutti_tiedot.length; j++) 
					{
						attribuutti_tiedot.push({"id":tiedot[i].attribuutti_tiedot[j].attribuutti_id,"nimi":tiedot[i].attribuutti_tiedot[j].attribuutti_nimi,"tiedot":""});
					}
					kohde_attribuutti_valinnat.push({"id":tiedot[i].kohde_id,"nimi":tiedot[i].nimi,"tiedot":attribuutti_tiedot});
				}	
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kohteet(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kategoria_id = "";
	var k_nimi = "";
	var k_kuvaus = "";
	var k_attribuutit = "";
	var k_tila_id = "";
	var k_aineistotunnus = "";
	var k_aktiivinen = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") { 
		k_kategoria_id = tarkista_muuttuja(hakurivi.find("th:eq(0) select").val(),"ei_tyhjä");
		k_nimi = tarkista_muuttuja(hakurivi.find("th:eq(2) input").val(),"ei_tyhjä");
		k_kuvaus = tarkista_muuttuja(hakurivi.find("th:eq(3) input").val(),"ei_tyhjä");
		if(hakurivi.find("th:eq(4) .valintasyotto_tietokehys").data("tiedot").length > 0) {
			k_attribuutit = hakurivi.find("th:eq(4) .valintasyotto_tietokehys").data("tiedot");
		}
		k_tila_id = tarkista_muuttuja(hakurivi.find("th:eq(5) select").val(),"ei_tyhjä"); 
		k_aineistotunnus = tarkista_muuttuja(hakurivi.find("th:eq(6) input").val(),"ei_tyhjä");
		k_aktiivinen = hakurivi.find("th:eq(7) .kytkinkehys").data("aktiivinen");
		
		if(k_aktiivinen == "-1") {
			k_aktiivinen = "";
		}
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_kohteet.php",
			data: { kategoria_id:k_kategoria_id, nimi:k_nimi, kuvaus:k_kuvaus, attribuutit:k_attribuutit, tila_id:k_tila_id, aineistotunnus:k_aineistotunnus, aktiivinen:k_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").closest(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				for(var i = 0; i < tiedot.length; i++) 
				{
					var kohde_attribuutit = [];
					var attribuutit = "";
					var kytkintila = $("<i class='kytkintila fa fa-square-o'></i>");
					var rivitila = "class='sisaltotaulu_ei_aktiivinen_rivi'";
					var aktiivinen = "0";
					if(tiedot[i].aktiivinen == 1) {
						kytkintila = $("<i class='kytkintila fa fa-check-square-o'></i>");
						rivitila = "";
						aktiivinen = "1";
					}
					
					var kategoria_nimi = "";
					for(var j = 0; j < kategoria_valinnat.length; j++)
					{
						if(tiedot[i].kategoria_id == kategoria_valinnat[j].id) {
							kategoria_nimi = kategoria_valinnat[j].nimi;
							break;
						}
					}
					
					var tila_nimi = "";
					for(var j = 0; j < tila_valinnat.length; j++)
					{
						if(tiedot[i].tila_id == tila_valinnat[j].id) {
							tila_nimi = tila_valinnat[j].nimi;
							break;
						}
					}
					
					for(var j = 0; j < tiedot[i].attribuutit.length; j++)
					{
						attribuutit += ", " + tiedot[i].attribuutit[j].nimi + ":" + tiedot[i].attribuutit[j].arvo;
						kohde_attribuutit.push({"tieto1":tiedot[i].attribuutit[j].attribuutti_id,"tieto1_teksti":tiedot[i].attribuutit[j].nimi,"tieto2":tiedot[i].attribuutit[j].arvo});
					}

					if(attribuutit.length > 0) {
						attribuutit = attribuutit.substring(2);
					}
					
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].kohde_id,
						}, 
						solut: [
							{"arvo":kategoria_nimi,"tiedot":tiedot[i].kategoria_id,"kentta":""},
							{"arvo":tiedot[i].jarjestysluku,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].nimi,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].kuvaus,"tiedot":"","kentta":""},
							{"arvo":attribuutit,"tiedot":kohde_attribuutit,"kentta":""},
							{"arvo":tila_nimi,"tiedot":tiedot[i].tila_id,"kentta":""},
							{"arvo":tiedot[i].aineistotunnus,"tiedot":"","kentta":""},
							{"arvo":kytkintila,"tiedot":aktiivinen,"kentta":""},
							{"arvo":"","tiedot":"","kentta":"painike_siirra"}
						],
						tallennus: tallenna_kohde,
						poisto: poista_kohde
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function vaihda_kohde_jarjestysluku(siirtorivi,siirtopaikka)
{
	var toiminnon_siirto = $.Deferred();
	
	var siirtorivi_kohde_id = siirtorivi.data("rivi_id");
	var siirtopaikka_kohde_id = siirtopaikka.data("rivi_id");

	if(siirtorivi_kohde_id != "" && siirtopaikka_kohde_id != "") {
		$.ajax({
			method: "POST",
			url: "php/vaihda_kohde_jarjestysluku.php",
			data: { valittu_kohde_id:siirtorivi_kohde_id, vaihdettava_kohde_id:siirtopaikka_kohde_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				else {
					luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				}
				hae_kohde_valinnat();
				siirtorivi.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function tallenna_kohde(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kohde_id = "";
	var k_kategoria_id = "";
	var k_nimi = "";
	var k_kuvaus = "";
	var k_attribuutit = "";
	var k_tila_id = "";
	var k_aineistotunnus = "";
	var k_aktiivinen = "";

	if("rivi_id" in rivitunniste.data()) {
		k_kohde_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(k_kohde_id == "") {
		k_kategoria_id = tarkista_muuttuja(rivitunniste.find("th:eq(0) select").val(),"ei_tyhjä");
		k_nimi = tarkista_muuttuja(rivitunniste.find("th:eq(2) input").val(),"ei_tyhjä");
		k_kuvaus = tarkista_muuttuja(rivitunniste.find("th:eq(3) input").val(),"ei_tyhjä");
		
		if(rivitunniste.find("th:eq(4) .valintasyotto_tietokehys").data("tiedot").length > 0) {
			k_attribuutit = rivitunniste.find("th:eq(4) .valintasyotto_tietokehys").data("tiedot");
		}
		
		k_tila_id = tarkista_muuttuja(rivitunniste.find("th:eq(5) select").val(),"ei_tyhjä");
		k_aineistotunnus = tarkista_muuttuja(rivitunniste.find("th:eq(6) input").val(),"ei_tyhjä");
		k_aktiivinen = rivitunniste.find("th:eq(7) .kytkinkehys").data("aktiivinen");
		
		if(k_kategoria_id == "") {
			rivitunniste.find("th:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_nimi == "") {
			rivitunniste.find("th:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_tila_id == "") {
			rivitunniste.find("th:eq(5)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_aineistotunnus == "") {
			rivitunniste.find("th:eq(6)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_aktiivinen == "-1") {
			rivitunniste.find("th:eq(7)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		k_kategoria_id = tarkista_muuttuja(rivitunniste.find("td:eq(0) select").val(),"ei_tyhjä");
		k_nimi = tarkista_muuttuja(rivitunniste.find("td:eq(2) input").val(),"ei_tyhjä");
		k_kuvaus = tarkista_muuttuja(rivitunniste.find("td:eq(3) input").val(),"ei_tyhjä");
		
		if(rivitunniste.find("td:eq(4) .valintasyotto_tietokehys").data("tiedot").length > 0) {
			k_attribuutit = rivitunniste.find("td:eq(4) .valintasyotto_tietokehys").data("tiedot");
		}
		
		k_tila_id = tarkista_muuttuja(rivitunniste.find("td:eq(5) select").val(),"ei_tyhjä");
		k_aineistotunnus = tarkista_muuttuja(rivitunniste.find("td:eq(6) input").val(),"ei_tyhjä");
		k_aktiivinen = rivitunniste.find("td:eq(7) .kytkinkehys").data("aktiivinen");
		
		if(k_kategoria_id == "") {
			rivitunniste.find("td:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_nimi == "") {
			rivitunniste.find("td:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_tila_id == "") {
			rivitunniste.find("td:eq(5)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_aineistotunnus == "") {
			rivitunniste.find("td:eq(6)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_aktiivinen == "-1") {
			rivitunniste.find("td:eq(7)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(k_kategoria_id != "" && k_nimi != "" && k_tila_id != "" && k_aineistotunnus != "" && k_aktiivinen != "-1" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_kohde.php",
			data: { kohde_id:k_kohde_id, kategoria_id:k_kategoria_id, nimi:k_nimi, kuvaus:k_kuvaus, attribuutit:k_attribuutit, tila_id:k_tila_id, aineistotunnus:k_aineistotunnus, aktiivinen:k_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				hae_kohde_valinnat();
				hae_kohde_tila_valinnat();
				hae_kohde_attribuutti_valinnat();
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_kohde(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kohde_id = rivitunniste.data("rivi_id");

	if(k_kohde_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_kohde.php",
			data: { kohde_id:k_kohde_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				hae_kohde_valinnat();
				hae_kohde_tila_valinnat();
				hae_kohde_attribuutti_valinnat();
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_viestit(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var v_aihe = "";
	var v_sisalto = "";
	var v_lahettaja = "";
	var v_alkupvm = "";
	var v_loppupvm = "";
	var v_kuitattu = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") {
		v_aihe = tarkista_muuttuja(hakurivi.find("th:eq(0) select").val(),"ei_tyhjä");
		v_sisalto = tarkista_muuttuja(hakurivi.find("th:eq(1) input").val(),"ei_tyhjä");
		v_lahettaja = tarkista_muuttuja(hakurivi.find("th:eq(2) input").val(),"ei_tyhjä");
		v_alkupvm = tarkista_muuttuja(hakurivi.find("th:eq(3) .aikavali_alkupvm_kehys input").val(),"pvm");
		v_loppupvm = tarkista_muuttuja(hakurivi.find("th:eq(3) .aikavali_loppupvm_kehys input").val(),"pvm");
		v_kuitattu = hakurivi.find("th:eq(4) .kytkinkehys").data("aktiivinen");
		
		if(v_kuitattu == "-1") {
			v_kuitattu = "";
		}
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_viestit.php",
			data: { aihe:v_aihe, sisalto:v_sisalto, lahettaja:v_lahettaja, alkupvm:v_alkupvm, loppupvm:v_loppupvm, kuitattu:v_kuitattu, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				for(var i = 0; i < tiedot.length; i++) 
				{
					var rivitila = "";
					var viesti_aihe = "";
					var aktiivinen = "0";
					for(var j = 0; j < viesti_aihe_valinnat.length; j++)
					{
						if(tiedot[i].aihe == viesti_aihe_valinnat[j].id) {
							viesti_aihe = viesti_aihe_valinnat[j].nimi;
							break;
						}
					}
					
					if(tiedot[i].kuitattu != "") {
						aktiivinen = "1";
					}
					
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].viesti_id,
						}, 
						solut: [
							{"arvo":viesti_aihe,"tiedot":tiedot[i].aihe,"kentta":""},
							{"arvo":tiedot[i].sisalto,"tiedot":"","kentta":"ei_muokattava"},
							{"arvo":tiedot[i].lahettaja,"tiedot":"","kentta":"ei_muokattava"},
							{"arvo":tiedot[i].aikaleima,"tiedot":"","kentta":"ei_muokattava"},
							{"arvo":tiedot[i].kuitattu,"tiedot":aktiivinen,"kentta":""},
							{"arvo":"","tiedot":"","kentta":"painike_sahkoposti"}
						],
						tallennus: tallenna_viesti,
						poisto: poista_viesti
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function tallenna_viesti(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();

	var v_viesti_id = "";
	var v_aihe = "";
	var v_sisalto = "";
	var v_lahettaja = "";
	var v_aikaleima = "";
	var v_kuitattu = "";

	if("rivi_id" in rivitunniste.data()) {
		v_viesti_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}

	if(v_viesti_id == "") {
		v_aihe = tarkista_muuttuja(rivitunniste.find("th:eq(0) select").val(),"ei_tyhjä");
		v_sisalto = tarkista_muuttuja(rivitunniste.find("th:eq(1) input").val(),"ei_tyhjä");
		v_lahettaja = tarkista_muuttuja(rivitunniste.find("th:eq(2) input").val(),"ei_tyhjä");
		v_aikaleima = palautaAikaleima();
		if(rivitunniste.find("th:eq(4) .kytkinkehys").data("aktiivinen") == "1") {
			v_kuitattu = palautaAikaleima();
		}
		
		if(v_aihe == "") {
			rivitunniste.find("th:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(v_sisalto == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(rivitunniste.find("th:eq(4) .kytkinkehys").data("aktiivinen") == "-1") {
			rivitunniste.find("th:eq(4)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		v_aihe = tarkista_muuttuja(rivitunniste.find("td:eq(0) select").val(),"ei_tyhjä");
		v_sisalto = tarkista_muuttuja(rivitunniste.find("td:eq(1)").html(),"ei_tyhjä");
		v_lahettaja = tarkista_muuttuja(rivitunniste.find("td:eq(2)").html(),"ei_tyhjä");
		v_aikaleima = tarkista_muuttuja(rivitunniste.find("td:eq(3)").html(),"ei_tyhjä");
		if(rivitunniste.find("td:eq(4) .kytkinkehys").data("aktiivinen") == "1") {
			v_kuitattu = palautaAikaleima();
		}
		
		if(v_aihe == "") {
			rivitunniste.find("td:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(v_sisalto == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(rivitunniste.find("td:eq(4) .kytkinkehys").data("aktiivinen") == "-1") {
			rivitunniste.find("td:eq(4)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(v_aihe != "" && v_sisalto != "" && v_aikaleima != "" && v_kuitattu != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_viesti.php",
			data: { viesti_id:v_viesti_id, aihe:v_aihe, sisalto:v_sisalto, lahettaja:v_lahettaja, aikaleima:v_aikaleima, kuitattu:v_kuitattu, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function poista_viesti(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var v_viesti_id = rivitunniste.data("rivi_id");

	if(v_viesti_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_viesti.php",
			data: { viesti_id:v_viesti_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_tapahtumat(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var t_tyyppi = "";
	var t_kohde_id = "";
	var t_kuvaus = "";
	var t_alkupvm = "";
	var t_loppupvm = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") {
		t_tyyppi = tarkista_muuttuja(hakurivi.find("th:eq(0) select").val(),"ei_tyhjä");
		t_kohde_id = tarkista_muuttuja(hakurivi.find("th:eq(1) select").val(),"ei_tyhjä");
		t_kuvaus = tarkista_muuttuja(hakurivi.find("th:eq(2) input").val(),"ei_tyhjä");
		t_alkupvm = tarkista_muuttuja(hakurivi.find("th:eq(3) .aikavali_alkupvm_kehys input").val(),"pvm");
		t_loppupvm = tarkista_muuttuja(hakurivi.find("th:eq(3) .aikavali_loppupvm_kehys input").val(),"pvm");
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_tapahtumat.php",
			data: { tyyppi:t_tyyppi, kohde_id:t_kohde_id, kuvaus:t_kuvaus, alkupvm:t_alkupvm, loppupvm:t_loppupvm, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				for(var i = 0; i < tiedot.length; i++) 
				{
					var rivitila = "";
					var tyyppi_nimi = "";
					for(var j = 0; j < tapahtuma_tyyppi_valinnat.length; j++)
					{
						if(tiedot[i].tyyppi == tapahtuma_tyyppi_valinnat[j].id) {
							tyyppi_nimi = tapahtuma_tyyppi_valinnat[j].nimi;
							
							if(tapahtuma_tyyppi_valinnat[j].id == 1) {
								rivitila = "class='sisaltotaulu_ei_muokattava'";
							}
							
							break;
						}
					}
					
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].tapahtuma_id,
						}, 
						solut: [
							{"arvo":tyyppi_nimi,"tiedot":tiedot[i].tyyppi,"kentta":""},
							{"arvo":tiedot[i].kohde_nimi,"tiedot":tiedot[i].kohde_id,"kentta":""},
							{"arvo":tiedot[i].kuvaus,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].aikaleima,"tiedot":"","kentta":""}
						],
						tallennus: tallenna_tapahtuma,
						poisto: poista_tapahtuma
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function tallenna_tapahtuma(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();

	var t_tapahtuma_id = "";
	var t_tyyppi = "";
	var t_kohde_id = "";
	var t_kuvaus = "";
	var t_aikaleima = palautaAikaleima();

	if("rivi_id" in rivitunniste.data()) {
		t_tapahtuma_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}

	if(t_tapahtuma_id == "") {
		t_tyyppi = tarkista_muuttuja(rivitunniste.find("th:eq(0) select").val(),"ei_tyhjä");
		t_kohde_id = tarkista_muuttuja(rivitunniste.find("th:eq(1) select").val(),"ei_tyhjä");
		t_kuvaus = rivitunniste.find("th:eq(2) input").val();
		
		if(t_tyyppi == "") {
			rivitunniste.find("th:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(t_kohde_id == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(t_kuvaus == "") {
			rivitunniste.find("th:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		t_tyyppi = tarkista_muuttuja(rivitunniste.find("td:eq(0) select").val(),"ei_tyhjä");
		t_kohde_id = tarkista_muuttuja(rivitunniste.find("td:eq(1) select").val(),"ei_tyhjä");
		t_kuvaus = tarkista_muuttuja(rivitunniste.find("td:eq(2) input").val(),"ei_tyhjä");
		
		if(t_tyyppi == "") {
			rivitunniste.find("td:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(t_kohde_id == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(t_kuvaus == "") {
			rivitunniste.find("td:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(t_tyyppi != "" && t_kohde_id != "" && t_kuvaus != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_tapahtuma.php",
			data: { tapahtuma_id:t_tapahtuma_id, tyyppi:t_tyyppi, kohde_id:t_kohde_id, kuvaus:t_kuvaus, aikaleima:t_aikaleima, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function poista_tapahtuma(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var t_tapahtuma_id = rivitunniste.data("rivi_id");

	if(t_tapahtuma_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_tapahtuma.php",
			data: { tapahtuma_id:t_tapahtuma_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_kategoria_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	kategoria_valinnat = [];
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kategoria_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				kategoria_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					kategoria_valinnat.push({"id":tiedot[i].kategoria_id,"nimi":tiedot[i].nimi});
				}				
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kategoria_tila_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	kategoria_tila_valinnat = [];
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kategoria_tila_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				kategoria_tila_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					kategoria_tila_valinnat.push({"tieto1_id":tiedot[i].kategoria_id,"tieto2_id":tiedot[i].tila_id});
				}				
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kategoriat(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_nimi = "";
	var k_lisatiedot = "";
	var k_tilat = "";
	var k_taso_id = "";
	var k_aktiivinen = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") { 
		k_nimi = tarkista_muuttuja(hakurivi.find("th:eq(1) input").val(),"ei_tyhjä");
		k_lisatiedot = tarkista_muuttuja(hakurivi.find("th:eq(2) input").val(),"ei_tyhjä");
		var k_tilat_tiedot = tarkista_muuttuja(hakurivi.find("th:eq(3) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		
		if(k_tilat_tiedot.length > 0) {
			for(var i = 0; i < k_tilat_tiedot.length; i++)
			{
				k_tilat += ",'" + k_tilat_tiedot[i] + "'"; 
			}
			
			if(k_tilat.length > 0) {
				k_tilat = k_tilat.substring(1);
			}
		}
		
		k_taso_id = tarkista_muuttuja(hakurivi.find("th:eq(4) select").val(),"ei_tyhjä");
		k_aktiivinen = hakurivi.find("th:eq(5) .kytkinkehys").data("aktiivinen");
		
		if(k_aktiivinen == "-1") {
			k_aktiivinen = "";
		}
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_kategoriat.php",
			data: { nimi:k_nimi, lisatiedot:k_lisatiedot, tilat:k_tilat, taso_id:k_taso_id, aktiivinen:k_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}

				for(var i = 0; i < tiedot.length; i++) 
				{
					var kytkintila = $("<i class='kytkintila fa fa-square-o'></i>");
					var rivitila = "class='sisaltotaulu_ei_aktiivinen_rivi'";
					var aktiivinen = "0";
					if(tiedot[i].aktiivinen == 1) {
						kytkintila = $("<i class='kytkintila fa fa-check-square-o'></i>");
						rivitila = "";
						aktiivinen = "1";
					}
					var kategoria_tilat = [];
					var tilat = "";
					for(var j = 0; j < tiedot[i].tilat.length; j++)
					{
						tilat += "," + tiedot[i].tilat[j].nimi;
						kategoria_tilat.push(tiedot[i].tilat[j].tila_id);
					}
					if(tilat.length > 0) {
						tilat = tilat.substring(1);
					}
					
					var taso_nimi = "";
					if(tiedot[i].taso_id != "") {
						for(var j = 0; j < kategoria_valinnat.length; j++) 
						{
							if(tiedot[i].taso_id == kategoria_valinnat[j].id) {
								taso_nimi = kategoria_valinnat[j].nimi;
								break;
							}
						}
					}			
					
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].kategoria_id,
						}, 
						solut: [
							{"arvo":tiedot[i].jarjestysluku,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].nimi,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].lisatiedot,"tiedot":"","kentta":""},
							{"arvo":tilat,"tiedot":kategoria_tilat,"kentta":""},
							{"arvo":taso_nimi,"tiedot":tiedot[i].taso_id,"kentta":""},
							{"arvo":kytkintila,"tiedot":aktiivinen,"kentta":""},
							{"arvo":"","tiedot":"","kentta":"painike_siirra"}
						],
						tallennus: tallenna_kategoria,
						poisto: poista_kategoria
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function vaihda_kategoria_jarjestysluku(siirtorivi,siirtopaikka)
{
	var toiminnon_siirto = $.Deferred();
	
	var siirtorivi_kategoria_id = siirtorivi.data("rivi_id");
	var siirtopaikka_kategoria_id = siirtopaikka.data("rivi_id");

	if(siirtorivi_kategoria_id != "" && siirtopaikka_kategoria_id != "") {
		$.ajax({
			method: "POST",
			url: "php/vaihda_kategoria_jarjestysluku.php",
			data: { valittu_kategoria_id:siirtorivi_kategoria_id, vaihdettava_kategoria_id:siirtopaikka_kategoria_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				else {
					luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				}
				hae_kategoria_valinnat();
				siirtorivi.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function tallenna_kategoria(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kategoria_id = "";
	var k_nimi = "";
	var k_lisatiedot = "";
	var k_tilat = "";
	var k_taso_id = "";
	var k_aktiivinen = "";

	if("rivi_id" in rivitunniste.data()) {
		k_kategoria_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(k_kategoria_id == "") {
		k_nimi = tarkista_muuttuja(rivitunniste.find("th:eq(1) input").val(),"ei_tyhjä");
		k_lisatiedot = rivitunniste.find("th:eq(2) input").val();
		k_tilat = tarkista_muuttuja(rivitunniste.find("th:eq(3) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		k_taso_id = rivitunniste.find("th:eq(4) select").val();
		k_aktiivinen = rivitunniste.find("th:eq(5) .kytkinkehys").data("aktiivinen");
		
		if(k_nimi == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_tilat == "") {
			rivitunniste.find("th:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_aktiivinen == "-1") {
			rivitunniste.find("th:eq(5)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		k_nimi = tarkista_muuttuja(rivitunniste.find("td:eq(1) input").val(),"ei_tyhjä");
		k_lisatiedot = rivitunniste.find("td:eq(2) input").val();
		k_tilat = tarkista_muuttuja(rivitunniste.find("td:eq(3) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		k_taso_id = rivitunniste.find("td:eq(4) select").val();
		k_aktiivinen = tarkista_muuttuja(rivitunniste.find("td:eq(5) .kytkinkehys").data("aktiivinen"));
		
		if(k_nimi == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_tilat == "") {
			rivitunniste.find("td:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_aktiivinen == "-1") {
			rivitunniste.find("td:eq(5)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_taso_id == k_kategoria_id) {
			rivitunniste.find("td:eq(4)").addClass("sisaltotaulu_solu_virhe");
			toiminnon_siirto.reject();
			return toiminnon_siirto;
		}
	}

	if(k_nimi != "" && k_aktiivinen != "-1" && k_tilat != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_kategoria.php",
			data: { kategoria_id:k_kategoria_id, nimi:k_nimi, lisatiedot:k_lisatiedot, tilat:k_tilat, taso_id:k_taso_id, aktiivinen:k_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				var sisaltotaulu = rivitunniste.closest("table");
				$.when(hae_kategoria_valinnat()).then(function() {
					sisaltotaulu.sisaltotaulu_otsikkosolu_paivitys({
						solut: [
							{"solu":4,"kentta":"valintakentta","tiedot":kategoria_valinnat,"linkitys":[]}
						]
					});
				});
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_kategoria(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kategoria_id = rivitunniste.data("rivi_id");

	if(k_kategoria_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_kategoria.php",
			data: { kategoria_id:k_kategoria_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				var sisaltotaulu = rivitunniste.closest("table");
				$.when(hae_kategoria_valinnat()).then(function() {
					sisaltotaulu.sisaltotaulu_otsikkosolu_paivitys({
						solut: [
							{"solu":4,"kentta":"valintakentta","tiedot":kategoria_valinnat,"linkitys":[]}
						]
					});
				});
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_tila_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	tila_valinnat = [];	
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_tila_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				tila_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					tila_valinnat.push({"id":tiedot[i].tila_id,"nimi":tiedot[i].nimi,"vari":tiedot[i].vari});
				}
				
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_tilat(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var ti_nimi = "";
	var ti_vari = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") {
		ti_nimi = tarkista_muuttuja(hakurivi.find("th:eq(0) input").val(),"ei_tyhjä");
		ti_vari = tarkista_muuttuja(hakurivi.find("th:eq(1) .varivalinta").data("tiedot"),"ei_tyhjä");
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_tilat.php",
			data: { nimi:ti_nimi, vari:ti_vari, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				for(var i = 0; i < tiedot.length; i++) 
				{
					var rivitila = "";
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].tila_id,
						}, 
						solut: [
							{"arvo":tiedot[i].nimi,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].vari,"tiedot":"","kentta":"varitila"}
						],
						tallennus: tallenna_tila,
						poisto: poista_tila
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}


function tallenna_tila(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var ti_tila_id = "";
	var ti_nimi = "";
	var ti_vari = "";

	if("rivi_id" in rivitunniste.data()) {
		ti_tila_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(ti_tila_id == "") {
		ti_nimi = tarkista_muuttuja(rivitunniste.find("th:eq(0) input").val(),"ei_tyhjä");
		ti_vari = tarkista_muuttuja(rivitunniste.find("th:eq(1) .varivalinta").data("tiedot"),"ei_tyhjä");
		
		if(ti_nimi == "") {
			rivitunniste.find("th:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(ti_vari == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		ti_nimi = tarkista_muuttuja(rivitunniste.find("td:eq(0) input").val(),"ei_tyhjä");
		ti_vari = tarkista_muuttuja(rivitunniste.find("td:eq(1) .varivalinta").data("tiedot"),"ei_tyhjä");
		
		if(ti_nimi == "") {
			rivitunniste.find("td:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(ti_vari == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(ti_nimi != "" && ti_vari != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_tila.php",
			data: { tila_id:ti_tila_id, nimi:ti_nimi, vari:ti_vari, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				hae_tila_valinnat();
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_tila(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var ti_tila_id = rivitunniste.data("rivi_id");

	if(ti_tila_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_tila.php",
			data: { tila_id:ti_tila_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				hae_tila_valinnat();
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_attribuutti_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	attribuutti_valinnat = [];	
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_attribuutti_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}

				attribuutti_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					attribuutti_valinnat.push({"id":tiedot[i].attribuutti_id,"nimi":tiedot[i].nimi});
				}	
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_attribuutit(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var a_nimi = "";
	var a_kuvaus = "";
	var a_tyyppi = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") {
		a_nimi = tarkista_muuttuja(hakurivi.find("th:eq(1) input").val(),"ei_tyhjä");
		a_kuvaus = tarkista_muuttuja(hakurivi.find("th:eq(2) input").val(),"ei_tyhjä");
		a_tyyppi = tarkista_muuttuja(hakurivi.find("th:eq(3) select").val(),"ei_tyhjä");
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_attribuutit.php",
			data: { nimi:a_nimi, kuvaus:a_kuvaus, tyyppi:a_tyyppi, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				for(var i = 0; i < tiedot.length; i++) 
				{
					var rivitila = "";
					var tyyppi_nimi = "";
					for(var j = 0; j < attribuutti_tyyppi_valinnat.length; j++)
					{
						if(tiedot[i].tyyppi == attribuutti_tyyppi_valinnat[j].id) {
							tyyppi_nimi = attribuutti_tyyppi_valinnat[j].nimi;
							break;
						}
					}
					
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].attribuutti_id,
						}, 
						solut: [
							{"arvo":tiedot[i].jarjestysluku,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].nimi,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].kuvaus,"tiedot":"","kentta":""},
							{"arvo":tyyppi_nimi,"tiedot":tiedot[i].tyyppi,"kentta":""},
							{"arvo":"","tiedot":"","kentta":"painike_siirra"}
						],
						tallennus: tallenna_attribuutti,
						poisto: poista_attribuutti
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function vaihda_attribuutti_jarjestysluku(siirtorivi,siirtopaikka)
{
	var toiminnon_siirto = $.Deferred();
	
	var siirtorivi_attribuutti_id = siirtorivi.data("rivi_id");
	var siirtopaikka_attribuutti_id = siirtopaikka.data("rivi_id");

	if(siirtorivi_attribuutti_id != "" && siirtopaikka_attribuutti_id != "") {
		$.ajax({
			method: "POST",
			url: "php/vaihda_attribuutti_jarjestysluku.php",
			data: { valittu_attribuutti_id:siirtorivi_attribuutti_id, vaihdettava_attribuutti_id:siirtopaikka_attribuutti_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				else {
					luo_ilmoitusviesti("ilmoitus","Siirtotila de-aktivoitu");
				}
				siirtorivi.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function tallenna_attribuutti(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var a_attribuutti_id = "";
	var a_nimi = "";
	var a_kuvaus = "";
	var a_tyyppi = "";

	if("rivi_id" in rivitunniste.data()) {
		a_attribuutti_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(a_attribuutti_id == "") {
		a_nimi = tarkista_muuttuja(rivitunniste.find("th:eq(1) input").val(),"ei_tyhjä");
		a_kuvaus = tarkista_muuttuja(rivitunniste.find("th:eq(2) input").val(),"ei_tyhjä");
		a_tyyppi = tarkista_muuttuja(rivitunniste.find("th:eq(3) select").val(),"ei_tyhjä");
		
		if(a_nimi == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_kuvaus == "") {
			rivitunniste.find("th:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_tyyppi == "") {
			rivitunniste.find("th:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		a_nimi = tarkista_muuttuja(rivitunniste.find("td:eq(1) input").val(),"ei_tyhjä");
		a_kuvaus = tarkista_muuttuja(rivitunniste.find("td:eq(2) input").val(),"ei_tyhjä");
		a_tyyppi = tarkista_muuttuja(rivitunniste.find("td:eq(3) select").val(),"ei_tyhjä");
		
		if(a_nimi == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_kuvaus == "") {
			rivitunniste.find("td:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(a_tyyppi == "") {
			rivitunniste.find("td:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(a_nimi != "" && a_kuvaus != "" && a_tyyppi != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_attribuutti.php",
			data: { attribuutti_id:a_attribuutti_id, nimi:a_nimi, kuvaus:a_kuvaus, tyyppi:a_tyyppi, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				hae_attribuutti_valinnat();
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_attribuutti(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var a_attribuutti_id = rivitunniste.data("rivi_id");

	if(a_attribuutti_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_attribuutti.php",
			data: { attribuutti_id:a_attribuutti_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				hae_attribuutti_valinnat();
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_kayttajat(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_nimi = "";
	var k_puhelin = "";
	var k_sahkoposti = "";
	var k_tunnus = "";
	var k_ryhma = "";
	var k_oikeudet = "";
	var k_kohteet = "";
	var k_aktiivinen = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") {
		k_nimi = tarkista_muuttuja(hakurivi.find("th:eq(0) input").val(),"ei_tyhjä");
		k_puhelin = hakurivi.find("th:eq(1) input").val();
		k_sahkoposti = hakurivi.find("th:eq(2) input").val();
		k_tunnus = tarkista_muuttuja(hakurivi.find("th:eq(3) input").val(),"ei_tyhjä");
		k_ryhma = hakurivi.find("th:eq(5) input").val();
		k_aktiivinen = hakurivi.find("th:eq(8) .kytkinkehys").data("aktiivinen");
		
		var k_oikeus_tiedot = tarkista_muuttuja(hakurivi.find("th:eq(6) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		
		if(k_oikeus_tiedot.length > 0) {
			for(var i = 0; i < k_oikeus_tiedot.length; i++)
			{
				k_oikeudet += ",'" + k_oikeus_tiedot[i] + "'"; 
			}
			
			if(k_oikeudet.length > 0) {
				k_oikeudet = k_oikeudet.substring(1);
			}
		}
		
		var k_kohde_tiedot = tarkista_muuttuja(hakurivi.find("th:eq(7) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		
		if(k_kohde_tiedot.length > 0) {
			for(var i = 0; i < k_kohde_tiedot.length; i++)
			{
				k_kohteet += ",'" + k_kohde_tiedot[i] + "'"; 
			}
			
			if(k_kohteet.length > 0) {
				k_kohteet = k_kohteet.substring(1);
			}
		}
		
		if(k_aktiivinen == "-1") {
			k_aktiivinen = "";
		}
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_kayttajat.php",
			data: { nimi:k_nimi, puhelin:k_puhelin, sahkoposti:k_sahkoposti, tunnus:k_tunnus, ryhma:k_ryhma, oikeudet:k_oikeudet, kohteet:k_kohteet, aktiivinen:k_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				for(var i = 0; i < tiedot.length; i++) 
				{
					var kytkintila = $("<i class='kytkintila fa fa-square-o'></i>");
					var rivitila = "class='sisaltotaulu_ei_aktiivinen_rivi'";
					var aktiivinen = "0";
					if(tiedot[i].aktiivinen == 1) {
						kytkintila = $("<i class='kytkintila fa fa-check-square-o'></i>");
						rivitila = "";
						aktiivinen = "1";
					}
					var kayttaja_oikeudet = [];
					var oikeudet = "";
					for(var j = 0; j < tiedot[i].oikeudet.length; j++)
					{
						for(var k = 0; k < oikeus_valinnat.length; k++)
						{
							if(tiedot[i].oikeudet[j].oikeus_id == oikeus_valinnat[k].id) {
								oikeudet += ", " + oikeus_valinnat[k].nimi;
								kayttaja_oikeudet.push(tiedot[i].oikeudet[j].oikeus_id);
							}
						}
					}
					if(oikeudet.length > 0) {
						oikeudet = oikeudet.substring(2);
					}
					
					oikeudet = kayttaja_oikeudet.length + " kpl";
					
					var kayttaja_kohteet = [];
					var kohteet = "";
					for(var j = 0; j < tiedot[i].kohteet.length; j++)
					{
						for(var k = 0; k < kohde_valinnat.length; k++)
						{
							if(tiedot[i].kohteet[j].kohde_id == kohde_valinnat[k].id) {
								kohteet += ", " + kohde_valinnat[k].nimi;
								kayttaja_kohteet.push(tiedot[i].kohteet[j].kohde_id);
							}
						}
					}
					if(kohteet.length > 0) {
						kohteet = kohteet.substring(2);
					}
					
					kohteet = kayttaja_kohteet.length + " kpl";
					
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].kayttaja_id
						}, 
						solut: [
							{"arvo":tiedot[i].nimi,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].puhelin,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].sahkoposti,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].tunnus,"tiedot":"","kentta":""},
							{"arvo":"","tiedot":"","kentta":""},
							{"arvo":tiedot[i].ryhma,"tiedot":"","kentta":""},
							{"arvo":oikeudet,"tiedot":kayttaja_oikeudet,"kentta":""},
							{"arvo":kohteet,"tiedot":kayttaja_kohteet,"kentta":""},
							{"arvo":kytkintila,"tiedot":aktiivinen,"kentta":""}
						],
						tallennus: tallenna_kayttaja,
						poisto: poista_kayttaja
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function tallenna_kayttaja(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kayttaja_id = "";
	var k_nimi = "";
	var k_puhelin = "";
	var k_sahkoposti = "";
	var k_tunnus = "";
	var k_salasana = "";
	var k_ryhma = "";
	var k_oikeudet = "";
	var k_kohteet = "";
	var k_aktiivinen = "";

	if("rivi_id" in rivitunniste.data()) {
		k_kayttaja_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(k_kayttaja_id == "") {
		k_nimi = tarkista_muuttuja(rivitunniste.find("th:eq(0) input").val(),"ei_tyhjä");
		k_puhelin = rivitunniste.find("th:eq(1) input").val();
		k_sahkoposti = rivitunniste.find("th:eq(2) input").val();
		k_tunnus = tarkista_muuttuja(rivitunniste.find("th:eq(3) input").val(),"ei_tyhjä");
		k_salasana = tarkista_muuttuja(rivitunniste.find("th:eq(4) input").val(),"ei_tyhjä");
		k_ryhma = rivitunniste.find("th:eq(5) input").val();
		k_oikeudet = tarkista_muuttuja(rivitunniste.find("th:eq(6) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		k_kohteet = tarkista_muuttuja(rivitunniste.find("th:eq(7) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		k_aktiivinen = rivitunniste.find("th:eq(8) .kytkinkehys").data("aktiivinen");
		
		if(k_nimi == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
	
		if(k_tunnus == "") {
			rivitunniste.find("th:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_salasana == "") {
			rivitunniste.find("th:eq(4)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(k_aktiivinen == "-1") {
			rivitunniste.find("th:eq(8)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		k_nimi = tarkista_muuttuja(rivitunniste.find("td:eq(0) input").val(),"ei_tyhjä");
		k_puhelin = rivitunniste.find("td:eq(1) input").val();
		k_sahkoposti = rivitunniste.find("td:eq(2) input").val();
		k_tunnus = tarkista_muuttuja(rivitunniste.find("td:eq(3) input").val(),"ei_tyhjä");
		k_salasana = tarkista_muuttuja(rivitunniste.find("td:eq(4) input").val(),"ei_tyhjä");
		k_ryhma = rivitunniste.find("td:eq(5) input").val();
		k_oikeudet = tarkista_muuttuja(rivitunniste.find("td:eq(6) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		k_kohteet = tarkista_muuttuja(rivitunniste.find("td:eq(7) .monivalinta_valinnat").data("valitut_idt"),"ei_tyhjä");
		k_aktiivinen = rivitunniste.find("td:eq(8) .kytkinkehys").data("aktiivinen");
		
		if(k_nimi == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
	
		if(k_tunnus == "") {
			rivitunniste.find("td:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}

		if(k_aktiivinen == "-1") {
			rivitunniste.find("td:eq(8)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(k_nimi != "" && k_aktiivinen != "-1" && kayttajatunnus != "" && ((k_kayttaja_id == "" && k_salasana != "") || (k_kayttaja_id != ""))) {
		$.ajax({
			method: "POST",
			url: "php/tallenna_kayttaja.php",
			data: { kayttaja_id:k_kayttaja_id, nimi:k_nimi, puhelin:k_puhelin, sahkoposti:k_sahkoposti, tunnus:k_tunnus, salasana:k_salasana, ryhma:k_ryhma, oikeudet:k_oikeudet, kohteet:k_kohteet, aktiivinen:k_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_kayttaja(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kayttaja_id = rivitunniste.data("rivi_id");

	if(k_kayttaja_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_kayttaja.php",
			data: { kayttaja_id:k_kayttaja_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_laite_attribuutti_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	laite_attribuutti_valinnat = [];	
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_laite_attribuutti_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				laite_attribuutti_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					laite_attribuutti_valinnat.push({"id":tiedot[i].laite_attribuutti_id,"nimi":tiedot[i].nimi + " / " + tiedot[i].paivitysvali + " min"});
				}
				
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_laitteet(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var l_laitetunnus = "";
	var l_kuvaus = "";
	var l_attribuutit = "";
	var l_aktiivinen = "";
	
	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") {
		l_laitetunnus = tarkista_muuttuja(hakurivi.find("th:eq(0) input").val(),"ei_tyhjä");
		l_kuvaus = hakurivi.find("th:eq(1) input").val();
		/*
		if(hakurivi.find("th:eq(2) .monivalintasyotto_tietokehys").data("tiedot").length > 0) {
			l_attribuutit = hakurivi.find("th:eq(2) .valintasyotto_tietokehys").data("tiedot");
		}
		*/
		
		l_aktiivinen = hakurivi.find("th:eq(3) .kytkinkehys").data("aktiivinen");
		
		if(l_aktiivinen == "-1") {
			l_aktiivinen = "";
		}
	}

	if(kayttajatunnus != "") {	
		$.ajax({
			method: "POST",
			url: "php/hae_laitteet.php",
			data: { laitetunnus:l_laitetunnus, kuvaus:l_kuvaus, attribuutit:l_attribuutit, aktiivinen:l_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
					
				for(var i = 0; i < tiedot.length; i++) 
				{
					var kytkintila = $("<i class='kytkintila fa fa-square-o'></i>");
					var rivitila = "class='sisaltotaulu_ei_aktiivinen_rivi'";
					var aktiivinen = "0";
					if(tiedot[i].aktiivinen == 1) {
						kytkintila = $("<i class='kytkintila fa fa-check-square-o'></i>");
						rivitila = "";
						aktiivinen = "1";
					}
					var attribuutit = "";
					var attribuutti_tiedot = [];
				
					for(var j = 0; j < tiedot[i].attribuutit.length; j++)
					{
						attribuutit += ", " + tiedot[i].attribuutit[j].nimi + ":" + tiedot[i].attribuutit[j].paivitysvali;
						attribuutti_tiedot.push({"tieto1":tiedot[i].attribuutit[j].attribuutti_id,"tieto1_teksti":tiedot[i].attribuutit[j].nimi,"tieto2":tiedot[i].attribuutit[j].paivitysvali});
					}
					if(attribuutit.length > 0) {
						attribuutit = attribuutit.substring(2);
					}
					
					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].laite_id
						}, 
						solut: [
							{"arvo":tiedot[i].laitetunnus,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].kuvaus,"tiedot":"","kentta":""},
							{"arvo":attribuutit,"tiedot":attribuutti_tiedot,"kentta":""},
							{"arvo":kytkintila,"tiedot":aktiivinen,"kentta":""}
						],
						tallennus: tallenna_laite,
						poisto: poista_laite
					});
				}

				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function tallenna_laite(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var l_laite_id = "";
	var l_laitetunnus = "";
	var l_kuvaus = "";
	var l_attribuutit = "";
	var l_aktiivinen = "";

	if("rivi_id" in rivitunniste.data()) {
		l_laite_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(l_laite_id == "") {
		l_laitetunnus = tarkista_muuttuja(rivitunniste.find("th:eq(0) input").val(),"ei_tyhjä");
		l_kuvaus = rivitunniste.find("th:eq(1) input").val();
		/*
		if(rivitunniste.find("th:eq(2) .valintasyotto_tietokehys").data("tiedot").length > 0) {
			l_attribuutit = rivitunniste.find("th:eq(2) .valintasyotto_tietokehys").data("tiedot");
		}
		*/
		l_aktiivinen = tarkista_muuttuja(rivitunniste.find("th:eq(3) .kytkinkehys").data("aktiivinen"));
		
		if(l_laitetunnus == "") {
			rivitunniste.find("th:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(l_aktiivinen == "-1") {
			rivitunniste.find("th:eq(4)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		l_laitetunnus = tarkista_muuttuja(rivitunniste.find("td:eq(0) input").val(),"ei_tyhjä");
		l_kuvaus = rivitunniste.find("td:eq(1) input").val();
		/*
		if(rivitunniste.find("td:eq(2) .valintasyotto_tietokehys").data("tiedot").length > 0) {
			l_attribuutit = rivitunniste.find("td:eq(2) .valintasyotto_tietokehys").data("tiedot");
		}
		*/
		l_aktiivinen = tarkista_muuttuja(rivitunniste.find("td:eq(3) .kytkinkehys").data("aktiivinen"));
		
		if(l_laitetunnus == "") {
			rivitunniste.find("td:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}

		if(l_aktiivinen == "-1") {
			rivitunniste.find("td:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(l_laitetunnus != "" && l_aktiivinen != "-1" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_laite.php",
			data: { laite_id:l_laite_id, laitetunnus:l_laitetunnus, kuvaus:l_kuvaus, aktiivinen:l_aktiivinen, attribuutit:l_attribuutit,kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				hae_laite_attribuutti_valinnat();
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_laite(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var l_laite_id = rivitunniste.data("rivi_id");

	if(l_laite_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_laite.php",
			data: { laite_id:l_laite_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				hae_laite_attribuutti_valinnat();
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_huoltoviestit(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var hv_kohde_id = "";
	var hv_tila_id = "";
	var hv_ohjaus = "";
	var hv_aktiivinen = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") { 
		hv_kohde_id = hakurivi.find("th:eq(0) select").val();
		hv_tila_id = hakurivi.find("th:eq(1) select").val();
		hv_ohjaus = hakurivi.find("th:eq(2) input").val();
		hv_aktiivinen = hakurivi.find("th:eq(3) .kytkinkehys").data("aktiivinen");
		
		if(hv_aktiivinen == "-1") {
			hv_aktiivinen = "";
		}
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_huoltoviestit.php",
			data: { kohde_id:hv_kohde_id, tila_id:hv_tila_id, ohjaus:hv_ohjaus, aktiivinen:hv_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}

				for(var i = 0; i < tiedot.length; i++) 
				{
					var kytkintila = $("<i class='kytkintila fa fa-square-o'></i>");
					var rivitila = "class='sisaltotaulu_ei_aktiivinen_rivi'";
					var aktiivinen = "0";
					if(tiedot[i].aktiivinen == 1) {
						kytkintila = $("<i class='kytkintila fa fa-check-square-o'></i>");
						rivitila = "";
						aktiivinen = "1";
					}
					
					var kohde_nimi = "";
					for(var j = 0; j < kohde_valinnat.length; j++)
					{
						if(tiedot[i].kohde_id == kohde_valinnat[j].id) {
							kohde_nimi = kohde_valinnat[j].nimi;
							break;
						}
					}
					
					var tila_nimi = "";
					for(var j = 0; j < tila_valinnat.length; j++)
					{
						if(tiedot[i].tila_id == tila_valinnat[j].id) {
							tila_nimi = tila_valinnat[j].nimi;
							break;
						}
					}
					

					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].huoltoviesti_id,
						}, 
						solut: [
							{"arvo":kohde_nimi,"tiedot":tiedot[i].kohde_id,"kentta":""},
							{"arvo":tila_nimi,"tiedot":tiedot[i].tila_id,"kentta":""},
							{"arvo":tiedot[i].ohjaus,"tiedot":"","kentta":""},
							{"arvo":kytkintila,"tiedot":aktiivinen,"kentta":""}
						],
						tallennus: tallenna_huoltoviesti,
						poisto: poista_huoltoviesti
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function tallenna_huoltoviesti(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var hv_huoltoviesti_id = "";
	var hv_kohde_id = "";
	var hv_tila_id = "";
	var hv_ohjaus = "";
	var hv_aktiivinen = "";

	if("rivi_id" in rivitunniste.data()) {
		hv_huoltoviesti_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(hv_huoltoviesti_id == "") {
		hv_kohde_id = tarkista_muuttuja(rivitunniste.find("th:eq(0) select").val(),"ei_tyhjä");
		hv_tila_id = tarkista_muuttuja(rivitunniste.find("th:eq(1) select").val(),"ei_tyhjä");
		hv_ohjaus = tarkista_muuttuja(rivitunniste.find("th:eq(2) input").val(),"ei_tyhjä");
		hv_aktiivinen = rivitunniste.find("th:eq(3) .kytkinkehys").data("aktiivinen");
		
		if(hv_kohde_id == "") {
			rivitunniste.find("th:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
	
		if(hv_tila_id == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(hv_ohjaus == "") {
			rivitunniste.find("th:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(hv_aktiivinen == "-1") {
			rivitunniste.find("th:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		hv_kohde_id = tarkista_muuttuja(rivitunniste.find("td:eq(0) select").val(),"ei_tyhjä");
		hv_tila_id = tarkista_muuttuja(rivitunniste.find("td:eq(1) select").val(),"ei_tyhjä");
		hv_ohjaus = tarkista_muuttuja(rivitunniste.find("td:eq(2) input").val(),"ei_tyhjä");
		hv_aktiivinen = rivitunniste.find("td:eq(3) .kytkinkehys").data("aktiivinen");
		
		if(hv_kohde_id == "") {
			rivitunniste.find("td:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
	
		if(hv_tila_id == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(hv_ohjaus == "") {
			rivitunniste.find("td:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
		
		if(hv_aktiivinen == "-1") {
			rivitunniste.find("td:eq(3)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(hv_kohde_id != "" && hv_tila_id != "" && hv_ohjaus != "" && hv_aktiivinen != "-1" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_huoltoviesti.php",
			data: { huoltoviesti_id:hv_huoltoviesti_id, kohde_id:hv_kohde_id, tila_id:hv_tila_id, ohjaus:hv_ohjaus, aktiivinen:hv_aktiivinen, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_huoltoviesti(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var hv_huoltoviesti_id = rivitunniste.data("rivi_id");

	if(hv_huoltoviesti_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_huoltoviesti.php",
			data: { huoltoviesti_id:hv_huoltoviesti_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function hae_kaannos_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	kaannos_valinnat = [];
	if(kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/hae_kaannos_valinnat.php",
			data: { kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;

				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				kaannos_valinnat = [];
				for(var i = 0; i < tiedot.length; i++)
				{
					//kaannos_valinnat.push({"id":tiedot[i].kategoria_id,"nimi":tiedot[i].nimi});
				}				
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function hae_kaannokset(sisaltotaulu)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kieli = "";
	var k_tyyppi = "";
	var k_kaannoskohde = "";
	var k_teksti = "";

	var hakurivi = $(sisaltotaulu).find(".sisaltotaulu_hakurivi"); 
	if(hakurivi.css("display") != "none") { 
		k_kieli = hakurivi.find("th:eq(0) select").val();
		var k_kaannos_valinta = hakurivi.find("th:eq(1) select").val();
		k_teksti = hakurivi.find("th:eq(2) input").val();
		
		console.log(k_kaannos_valinta);
		if(k_kaannos_valinta != "") {
			
		}
	}

	if(kayttajatunnus != "") {
		luo_latausruutu();
		
		$.ajax({
			method: "POST",
			url: "php/hae_kaannokset.php",
			data: { kieli:k_kieli, tyyppi:k_tyyppi, kaannoskohde:k_kaannoskohde, teksti:k_teksti, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				var lukumaarat = palvelinvastaus.lukumaarat;
				if(vastaustila.virhe == 1) {
					$("#hallintanakyma").find(".latausruutu").remove();
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}

				for(var i = 0; i < tiedot.length; i++) 
				{
					var rivitila = "";
					
					var kieli = "";
					for(var j = 0; j < kieli_valinnat.length; j++)
					{
						if(tiedot[i].kieli == kieli_valinnat[j].id) {
							kieli = kieli_valinnat[j].nimi;
							break;
						}
					}
					
					var kaannos_teksti = "";
					/*
					for(var j = 0; j < kaannos_valinnat.length; j++)
					{
						if(tiedot[i].kohde_id == kohde_valinnat[j].id) {
							kohde_nimi = kohde_valinnat[j].nimi;
							break;
						}
					}
					*/
					

					$(sisaltotaulu).sisaltotaulurivi({
						rivitiedot: {
							"rivitila":rivitila,
							"rivinumero":i,
							"rivi_id":tiedot[i].kaannos_id,
						}, 
						solut: [
							{"arvo":kieli,"tiedot":tiedot[i].kieli,"kentta":""},
							{"arvo":kaannos_teksti,"tiedot":"","kentta":""},
							{"arvo":tiedot[i].teksti,"tiedot":"","kentta":""}
						],
						tallennus: tallenna_kaannos,
						poisto: poista_kaannos
					});
				}
				
				$("#hallintanakyma").find(".latausruutu").remove();
				toiminnon_siirto.resolve(lukumaarat);
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function tallenna_kaannos(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kaannos_id = "";
	var k_kieli = "";
	var k_tyyppi = "";
	var k_kaannoskohde = "";
	var k_teksti = "";

	if("rivi_id" in rivitunniste.data()) {
		k_kaannos_id = tarkista_muuttuja(rivitunniste.data("rivi_id") + "","numero");
	}
	
	if(k_kaannos_id == "") {
		k_kieli = tarkista_muuttuja(rivitunniste.find("th:eq(0) select").val(),"ei_tyhjä");
		var k_kaannos_valinta = tarkista_muuttuja(rivitunniste.find("th:eq(1) select").val(),"ei_tyhjä");
		k_teksti = tarkista_muuttuja(rivitunniste.find("th:eq(2) input").val(),"ei_tyhjä");
		
		if(k_kieli == "") {
			rivitunniste.find("th:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
		
		console.log(k_kaannos_valinta);
		if(k_kaannos_valinta == "") {
			rivitunniste.find("th:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		else {
			
		}
		
		if(k_teksti == "") {
			rivitunniste.find("th:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
	}
	else {
		k_kieli = tarkista_muuttuja(rivitunniste.find("td:eq(0) select").val(),"ei_tyhjä");
		var k_kaannos_valinta = tarkista_muuttuja(rivitunniste.find("td:eq(1) select").val(),"ei_tyhjä");
		k_teksti = tarkista_muuttuja(rivitunniste.find("td:eq(2) input").val(),"ei_tyhjä");
		
		if(k_kieli == "") {
			rivitunniste.find("td:eq(0)").addClass("sisaltotaulu_solu_virhe");
		}
	
		console.log(k_kaannos_valinta);
		if(k_kaannos_valinta == "") {
			rivitunniste.find("td:eq(1)").addClass("sisaltotaulu_solu_virhe");
		}
		else {
			
		}
		
		if(k_teksti == "") {
			rivitunniste.find("td:eq(2)").addClass("sisaltotaulu_solu_virhe");
		}
	}

	if(k_kieli != "" && k_tyyppi != "" && k_kaannoskohde != "" && k_teksti != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/tallenna_kaannos.php",
			data: { kaannos_id:k_kaannos_id, kieli:k_kieli, tyyppi:k_tyyppi, kaannoskohde:k_kaannoskohde, teksti:k_teksti, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				hae_kaannos_valinnat();
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function poista_kaannos(rivitunniste)
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kaannos_id = rivitunniste.data("rivi_id");

	if(k_kaannos_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/poista_kaannos.php",
			data: { kaannos_id:k_kaannos_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				hae_kaannos_valinnat();
				rivitunniste.closest("table").trigger("sisalto_paivitys");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function kohdetilaruutu_poista_virhe()
{
	$(".kohdetilaruutu_valinta").removeClass("kohdetilaruutu_kenttavirhe");
}

function aseta_kohteen_tila()
{
	var toiminnon_siirto = $.Deferred();
	
	var k_kohde_id = $(".kohdetilaruutu_kohde_id").html();
	var k_tila_id = $(".kohdetilaruutu_valinta").val();
	
	if(k_tila_id == "") {
		$(".kohdetilaruutu_valinta").addClass("kohdetilaruutu_kenttavirhe");
	}

	if(k_kohde_id != "" && k_tila_id != "" && kayttajatunnus != "") {
		$.ajax({
			method: "POST",
			url: "php/aseta_kohde_tila.php",
			data: { kohde_id:k_kohde_id, tila_id:k_tila_id, kayttaja:kayttajatunnus },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.rivitiedot;
				
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				$(".kohdetilaruutu_teksti").html("");
				$(".kohdetilaruutu_valinta").html("");
				$(".kohdetilaruutu_kohde_id").html("");
				kohdetilaruutu.close();
				
				$.when(hae_kartta_kohde_tiedot()).then(function(kartta_kohde_tiedot) {
					aseta_karttavalikko_kohde_tiedot(kartta_kohde_tiedot);
				});
				
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}
	
	return toiminnon_siirto;
}

function sulje_kohdetilaruutu()
{
	$(".kohdetilaruutu_teksti").html("");
	$(".kohdetilaruutu_valinta").html("");
	$(".kohdetilaruutu_kohde_id").html("");
	kohdetilaruutu.close();
}

function luo_latausruutu()
{
	var latausruutu = $(
		"<div class='latausruutu'>"
			+ "<i class='latausruutu_kuvake fa fa-spinner fa-pulse'></i>"
			+ "<span class='latausruutu_teksti'>Ladataan...</span>"
		+ "</div>"
	);
	
	$("#hallintanakyma").append(latausruutu);
	latausruutu.css({"margin-left":(-1 * latausruutu.outerWidth() / 2) + "px"},{"margin-top":(-1 * latausruutu.outerHeight() / 2) + "px"});
}

function luo_poistoruutu(rivitunniste,poistofunktio)
{
	rivitunniste.addClass("sisaltotaulu_poistorivi");
	var poistoruutu = $(
		"<div class='poistoruutu'>"
			+ "<i class='poistoruutu_kuvake fa fa-warning'></i>"
			+ "<span class='poistoruututeksti'>Poistetaanko valittu rivi?</span>"
			+ "<div class='poistoruutu_painikekehys'>"
				+ "<button class='poistoruutu_peruuta_painike poistoruutu_painike'>Peruuta</button>"
				+ "<button class='poistoruutu_poista_painike poistoruutu_painike'>Poista</button>"
			+ "</div>"
		+ "</div>"
	);
	
	poistoruutu.find(".poistoruutu_poista_painike").click(function() {
		poistofunktio(rivitunniste);
		$(this).closest(".poistoruutu").remove();
	});
	
	poistoruutu.find(".poistoruutu_peruuta_painike").click(function() {
		rivitunniste.removeClass("sisaltotaulu_poistorivi");
		$(this).closest(".poistoruutu").remove();
	});
	
	$("#hallintanakyma").append(poistoruutu);
	poistoruutu.css({"margin-left":(-1 * poistoruutu.outerWidth() / 2) + "px"},{"margin-top":(-1 * poistoruutu.outerHeight() / 2) + "px"});
}

function nayta_kuva(kuva)
{
	window.open(kuva.prop("src"));
}

function luo_ilmoitusviesti(tyyppi,teksti)
{
	var ilmoituskuvake = "";
	var ilmoitustaustavari = "";
	var ilmoituskesto = 0;
	
	switch(tyyppi)
	{
		case "ilmoitus":
			ilmoitustaustavari = "#f0ad4e";
			ilmoituskuvake = "fa-info-circle";
			ilmoituskesto = 5000;
		break;
		
		case "virhe":
			ilmoitustaustavari = "#d9534f";
			ilmoituskuvake = "fa-warning";
			ilmoituskesto = 4000;
		break;
		
		case "lataus":
			ilmoitustaustavari = "#a3eccd";
			ilmoituskuvake = "fa-spinner fa-spin";
			ilmoituskesto = 0;
		break;
		
		default:
			ilmoitustaustavari = "#ffffff";
			ilmoituskuvake = "fa-info";
			ilmoituskesto = 3000;
	}
	
	var ilmoitusviesti = $(
		"<div class='ilmoitusviesti' style='display:none; background-color:" + ilmoitustaustavari + ";'>"
			+ "<i class='ilmoitusviesti_kuvake fa " + ilmoituskuvake + "'></i>"
			+ "<span class='ilmoitusviestiteksti'>" + teksti + "</span>"
		+ "</div>"
	);

	if($("#hallintanakyma .ilmoitusviesti").length > 0) {
		var edellinen_viesti_korkeus = $("#hallintanakyma .ilmoitusviesti:first").outerHeight() + 5;
		var edellinen_viesti_positio = parseFloat($("#hallintanakyma .ilmoitusviesti:first").css("bottom"));
		$("#hallintanakyma .ilmoitusviesti:first").before(ilmoitusviesti);
		$(ilmoitusviesti).css({"bottom":edellinen_viesti_positio + edellinen_viesti_korkeus});
	}
	else {
		$("#hallintanakyma").append(ilmoitusviesti);
		$(ilmoitusviesti).css({"bottom":"10px"});
	}

	$(ilmoitusviesti).fadeIn(1000);
	$(ilmoitusviesti).click(function() {
		$(this).fadeOut(1000,function() {
			var viesti_korkeus = $(this).outerHeight() + 5;
			$(this).prevAll(".ilmoitusviesti").each(function() {
				var viesti_positio = parseFloat($(this).css("bottom"));
				viesti_positio -= viesti_korkeus;
				$(this).css({"bottom":viesti_positio});
			});
			$(this).remove();
		});
	});
	
	if(ilmoituskesto > 0) {
		setTimeout(function() {
			if($("#hallintanakyma .ilmoitusviesti").index($(ilmoitusviesti)) != -1) {
				$(ilmoitusviesti).fadeOut(1000,function() {
					var viesti_korkeus = $(this).outerHeight() + 5;
					$(this).prevAll(".ilmoitusviesti").each(function() {
						var viesti_positio = parseFloat($(this).css("bottom"));
						viesti_positio -= viesti_korkeus;
						$(this).css({"bottom":viesti_positio});
					});
					$(this).remove();
				});
			}
		}, ilmoituskesto);
	}
	
	return ilmoitusviesti;
}

function palautaAikaleima(viikonpaiva)
{
	var tanaan = new Date();
	var tunnit = tanaan.getHours();
	var minuutit = tanaan.getMinutes();
	var sekunnit = tanaan.getSeconds();
	var paiva = tanaan.getDate();
	var kuukausi = tanaan.getMonth() + 1;
	var vuosi = tanaan.getFullYear();
	
	if(tunnit <= 9) { tunnit = '0' + tunnit; }
	if(minuutit <= 9) { minuutit = '0' + minuutit; }
	if(sekunnit <= 9) { sekunnit = '0' + sekunnit; }
	if(paiva <= 9) { paiva = '0' + paiva; }
	if(kuukausi <= 9) { kuukausi = '0' + kuukausi; }
	
	return paiva + "." + kuukausi + "." + vuosi + " " + tunnit + ":" + minuutit + ":" + sekunnit;
}

function tarkista_muuttuja(arvo,tyyppi)
{
	var tarkistettu_arvo = "";
	
	switch(tyyppi)
	{
		case "ei_tyhjä":
			if(arvo.length > 0) {
				tarkistettu_arvo = arvo;
			}
		break;
		
		case "numero":
			if(arvo.match(/^\d+$/)) {
				tarkistettu_arvo = arvo;
			}
		break;
		
		case "sähköposti":
			if(arvo.match(/@{1}/)) {
				tarkistettu_arvo = arvo;
			}
		break;
		
		case "teksti":
			tarkistettu_arvo = arvo;
		break;
		
		case "puhelin":
			tarkistettu_arvo = arvo;
		break;
		
		case "pvm":
			tarkistettu_arvo = arvo;
		break;
		
		default: tarkistettu_arvo = arvo;
	}
	
	return tarkistettu_arvo;
}