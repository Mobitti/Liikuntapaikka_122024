<?php
$dbuname = "uhuolto";
$dbpass = "Pl2AjLu9oF0PklK4X3F3ymhGMuKyRQcE";
//$dbpass = "SNecX9Son679k8JQXNxI1u9l8M0dozuj";
$dbname = "ulkoile_kokkola_2";
$dbhost = "localhost";
?>