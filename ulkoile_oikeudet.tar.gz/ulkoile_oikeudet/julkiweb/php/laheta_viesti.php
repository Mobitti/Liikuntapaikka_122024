<?php
require_once "config.php";
require_once "yleisfunktiot.php";

try
{
	$tiedot = array();
	$rivi_tiedot = array();
	
	if(!tarkista_parametri("aihe",false,"id")
	|| !tarkista_parametri("sisalto",false,"teksti")
	|| !tarkista_parametri("lahettaja",true,"teksti")
	|| !tarkista_parametri("aikaleima",false,"aikaleima")) {
		$tila_tieto["virhe"] = 1;
		$tila_tieto["viesti"] = "Parametrivirhe";
		$tiedot["tila"] = $tila_tieto;
		echo json_encode($tiedot);
		return;
	}
	
	$yhteys = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass); 
	$yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$yhteys->query("SET NAMES utf8");
	
	$aikaleima = kaanna_fi_aikaleima($_POST["aikaleima"]);
	
	$sql = "INSERT INTO viesti (viesti_id, aihe, sisalto, lahettaja, aikaleima, kuitattu) VALUES (NULL, :aihe, :sisalto, :lahettaja, :aikaleima, NULL)";
	$arvot = $yhteys->prepare($sql);
	$arvot->bindParam(":aihe", $_POST["aihe"]);
	$arvot->bindParam(":sisalto", $_POST["sisalto"]);
	$arvot->bindParam(":lahettaja", $_POST["lahettaja"]);
	$arvot->bindParam(":aikaleima", $aikaleima);
	$arvot->execute();
	
	if($arvot->rowCount() > 0) {
		$tyyppi = "";
		if($_POST["aihe"] == 1) {
			$tyyppi = "kysely";
		}
		else if($_POST["aihe"] == 2) {
			$tyyppi = "pyyntö";
		}
		else if($_POST["aihe"] == 3) {
			$tyyppi = "palaute";
		}
		
		$lahettaja = "From: info";
		$vastaanottaja = "liikunta@kokkola.fi";
		$aihe = "Uusi viesti ulkoilupalvelussa";
		$viesti = "Ulkoilupalveluun on saapunut uusi " . $tyyppi;
		
		$sposti_lahetys = mail($vastaanottaja,$aihe,$viesti,$lahettaja);
	}
	
	$rivi_tieto["nimi"] = "Viesti";
	$rivi_tieto["kpl"] = $arvot->rowCount();
	$rivi_tieto["sposti"] = $sposti_lahetys;
	array_push($rivi_tiedot,$rivi_tieto);
	

	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 0;
	$tila_tieto["viesti"] = "";
	$tiedot["tila"] = $tila_tieto;
	$tiedot["rivitiedot"] = $rivi_tiedot;
	echo json_encode($tiedot);
}
catch(PDOException $e)
{
	$yhteys = null; 
	$arvot = null;
	
	$tila_tieto["virhe"] = 1;
	$tila_tieto["viesti"] = $e->getMessage();
	$tiedot["tila"] = $tila_tieto;
	echo json_encode($tiedot);
}
?>