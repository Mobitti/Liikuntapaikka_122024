<?php

include 'config.php';

    try
    {
        $con = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuname, $dbpass);
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $con->query('SET NAMES utf8');

        $sql = "SELECT time,payload, port FROM track WHERE port = 1";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        
        //while (($laitteet = $stmt->fetch(PDO::FETCH_OBJ)))
        //{
            $laitteet = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $json = json_encode($laitteet);        
            echo $json;
            //echo $laitteet->payload;
            //echo $laitteet->port;
        //}        
    }
    catch(PDOException $e)
    {
        echo $e->getMessage();
    }



?>