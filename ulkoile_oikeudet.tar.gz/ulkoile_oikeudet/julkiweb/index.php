<!DOCTYPE html>
<html lang="fi">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maxium-scale=1.0,user-scalable=no">
		<title>Ulkoile</title>
		<link rel="Stylesheet" href="css/font-awesome.min.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet-sidebar.css" />
		<link rel="Stylesheet" href="leaflet/css/Leaflet.PolylineMeasure.css" />
		<link rel="Stylesheet" href="leaflet/css/Leaflet.Weather.css" />
		<link rel="Stylesheet" href="leaflet/css/Leaflet.Dialog.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet-slider.css" />
		<link rel="Stylesheet" href="leaflet/css/leaflet-beautify-marker-icon.css" />
		<link rel="Stylesheet" href="leaflet/css/L.Control.Locate.min.css" />
		<link rel="Stylesheet" href="leaflet/css/L.Control.MousePosition.css" />
		<link rel="Stylesheet" href="css/normalize.css" />
		<link rel="Stylesheet" href="css/stylesheet.css" />
		
		<script src="js/jquery-3.2.1.min.js"></script>
		<script src="leaflet/js/leaflet.js"></script>
		<script src="leaflet/js/proj4.min.js"></script>
		<script src="leaflet/js/proj4leaflet.js"></script>
		<script src="leaflet/js/leaflet-sidebar.js"></script>
		<script src="leaflet/js/Leaflet.Weather.js"></script>
		<script src="leaflet/js/Leaflet.PolylineMeasure.js"></script>
		<script src="leaflet/js/Leaflet.Dialog.js"></script>
		<script src="leaflet/js/leaflet-slider.js"></script>
		<script src="leaflet/js/leaflet-beautify-marker-icon.js"></script>
		<script src="leaflet/js/L.Control.Locate.js"></script>
		<script src="leaflet/js/L.Control.MousePosition.js"></script>
		<script src="js/core.js"></script>
		<!--
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-749740-38"></script>
		-->
		<script type="text/javascript">
			/*
			<!-- Global site tag (gtag.js) - Google Analytics -->
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());
			gtag('config', 'UA-749740-38');
			*/
			$(document).ready(function() {
				alusta_karttanakyma();
			});
		</script>
	</head>
	<body>
		<div class="karttanakyma"></div>
	</body>
</html>