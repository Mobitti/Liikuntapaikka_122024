/*************************************************************** MUUTTUJAT *************************************************************************************/
var viesti_aihe_valinnat = [
	{"id":1,"nimi":"Kysely"},
	{"id":2,"nimi":"Pyyntö"},
	{"id":3,"nimi":"Palaute"}
];

var tila_valinnat = [];

var karttakomponentti = "";
var karttavalikko = "";
var karttaaineistotaso = "";
var karttaaineisto = [];
var karttapiirtotaso = "";
var karttapiirtoohjaus = "";
var karttalapinakyvyys = "";
var karttaruutu = "";
var valittu_kohde_id = "";
var nykyinen_karttataso = "";


var kategoria_aineisto_taso = "";

/*************************************************************** FUNKTIOT **************************************************************************************/
function alusta_karttanakyma()
{
	$.when(hae_kartta_kohde_tiedot(),hae_tila_valinnat()).then(function(kartta_kohde_tiedot) {
		$(".karttanakyma").append(
			"<div id='karttavalikko' class='sidebar collapsed'>"
				+ "<div class='logo_kehys'>"
					+ "<img class='logo_kuvake' src='css/images/kokkola_logo.gif' />"
				+ "</div>"
				+ "<div class='sidebar-tabs'>"
					+ "<ul>"
						+ "<li><a id='kohteet' href='#karttavalikko_kohdevalikko'><i class='fa fa-map-signs' title='Liikuntapaikat / Aktivitetsplatser'></i></a></li>"
						+ "<li><a id='viestit' href='#karttavalikko_viestinta'><i class='fa fa-edit' title='Ota yhteyttä / Ta kontakt'></i></a></li>"
						+ "<li><a id='ohjeet' href='#karttavalikko_ohjeet'><i class='fa fa-question-circle-o' title='Ohjeet / Hjälp'></i></a></li>"
					+ "</ul>"
				+ "</div>"
				+ "<div class='sidebar-content'>"
					+ "<div class='sidebar-pane karttavalikko_valikko' id='karttavalikko_kohdevalikko'>"
						+ "<h1 class='sidebar-header'>"
							+ "Liikuntapaikat / Aktivitetsplatser"
							+ "<span class='sidebar-close'><i class='fa fa-caret-left'></i></span>"
						+ "</h1>"
						+ "<div id='karttavalikko_kategoriakohteet' class='karttavalikko_sisalto'></div>"
						+ "<div class='karttavalikko_tilat'></div>"
					+ "</div>"
					+ "<div class='sidebar-pane' id='karttavalikko_viestinta'>"
						+ "<h1 class='sidebar-header'>"
							+ "Ota yhteyttä / Ta kontakt"
							+ "<span class='sidebar-close'><i class='fa fa-caret-left'></i></span>"
						+ "</h1>"
						+ "<div class='karttavalikko_viestintakehys'>"
							+ "<div class='karttavalikko_viestinta_kehys'>"
								+ "<span class='karttavalikko_viestintateksti'>Aihe / Ämne</span>"
								+ "<select class='karttavalikko_viestinta_aihe'>"
									+ "<option value=''>Valitse / Välj</option>"
									+ "<option value='1'>Kysely / Förfråga</option>"
									+ "<option value='2'>Pyyntö / Begäran</option>"
									+ "<option value='3'>Palaute / Feedback</option>"
								+ "</select>"
							+ "</div>"
							+ "<div class='karttavalikko_viestinta_kehys'>"
								+ "<textarea class='karttavalikko_viestinta_sisalto' placeholder='Kuvaus / Beskrivning'></textarea>"
							+ "</div>"
							+ "<div class='karttavalikko_viestinta_kehys'>"
								+ "<i class='karttavalikko_viestinta_kuvake fa fa-address-book-o'></i>"
								+ "<input class='karttavalikko_viestinta_lahettaja' value='' placeholder='Puhelin/Telefon - Sähköposti/E-post'/>"
							+ "</div>"
							+ "<div class='karttavalikko_painike'>"
								+ "<i class='fa fa-envelope-o' title='Lähetä / Skicka'></i>"
							+ "</div>"
						+ "</div>"
					+ "</div>"
					+ "<div class='sidebar-pane' id='karttavalikko_ohjeet'>"
						+ "<h1 class='sidebar-header'>"
							+ "Ohjeet / Hjälp"
							+ "<span class='sidebar-close'><i class='fa fa-caret-left'></i></span>"
						+ "</h1>"
						+ "<div>"
							+ "<div class='karttavalikko_ohjeet_kielipainike_kehys'>"
								+ "<div class='karttavalikko_kielipainike_fi' title='fi'></div>"
								+ "<div class='karttavalikko_kielipainike_se' title='se'></div>"
							+ "</div>"
							+ "<span class='karttavalikko_ohjeet_teksti'></span>"
						+ "</div>"
					+ "</div>"
				+ "</div>"
			+ "</div>"
			+ "<div id='karttakomponentti' class='karttakomponentti sidebar-map'></div>"
		);
		
		$(".karttavalikko_kielipainike_fi").click(function() {
			aseta_ohje_kieli("fi");
		});
		
		$(".karttavalikko_kielipainike_se").click(function() {
			aseta_ohje_kieli("se");
		});
		
		for(var i = 0; i < tila_valinnat.length; i++)
		{
			$(".karttavalikko_tilat").append(
				"<div class='karttavalikko_tila_kehys'>"
					+ "<i class='karttavalikko_tila_kuvake fa fa-square' style='color:rgb(" + tila_valinnat[i].vari + ")'></i>"
					+ "<span class='karttavalikko_tila_teksti'>" + tila_valinnat[i].nimi + "</span>"
				+ "</div>"
			);
		}
		
		$(".karttavalikko_viestinta_aihe").change(function() {
			$(this).removeClass("karttavalikko_kenttavirhe");
		});
		
		$(".karttavalikko_viestinta_sisalto").change(function() {
			$(this).removeClass("karttavalikko_kenttavirhe");
		});
		
		$(".karttavalikko_painike").click(function() {
			laheta_viesti();
		});

		karttakomponentti = L.map("karttakomponentti", {
			crs: new L.Proj.CRS("urn:ogc:def:crs:EPSG::3877","+proj=tmerc +lat_0=0 +lon_0=23 +k=1 +x_0=23500000 +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs",{
				resolutions: [
					8192, 4096, 2048, 1024, 512, 256, 128,
					64, 32, 16, 8, 4, 2, 1, 0.5
				]
			}),
			maxBounds: L.latLngBounds(L.latLng(63.12,22.54),L.latLng(64.12,25.10)),
			attributionControl: false,
			zoomControl: false
		});
		
		var opaskartta = L.tileLayer.wms("https://kartta.kokkola.fi/TeklaOgcWeb/WMS.ashx?", {
			layers: 'Opaskartta', 
			format: 'image/png',
			maxZoom: 13,
			minZoom: 7
		});

		var ilmakuva = L.tileLayer.wms("https://kartta.kokkola.fi/TeklaOgcWeb/WMS.ashx?", {
			layers: 'Ilmakuva',
			format: 'image/png',
			minZoom: 8
		});

		var peruskartta = L.tileLayer.wms("https://kartta.kokkola.fi/TeklaOgcWeb/WMS.ashx?", {
			layers: 'Peruskartta',
			format: 'image/png',
			minZoom: 7
		});

		karttakomponentti.addLayer(opaskartta);
		nykyinen_karttataso = opaskartta;
		karttakomponentti.setView([63.85, 23.25],9);
		
		var tasot = {"Opaskartta / Guidekarta":opaskartta,"Ilmakuva / Flygbild":ilmakuva,"Peruskartta / Grundkarta":peruskartta};
		karttaaineistotaso = L.featureGroup().addTo(karttakomponentti);
		L.control.layers(tasot,{"Aineisto / Material":karttaaineistotaso},{position:"topleft"}).addTo(karttakomponentti);
		if(L.Browser.touch) {
			$(".leaflet-control-layers-toggle").css({
				"width":"30px",
				"height":"30px",
				"line-height":"30px"
			});
		}
		else {
			$(".leaflet-control-layers-toggle").css({
				"width":"26px",
				"height":"26px",
				"line-height":"26px"
			});
		}
		karttalapinakyvyys = L.control.slider(
			function(lapinakyvyys) { 
				$(karttalapinakyvyys.slider).val(lapinakyvyys);
				nykyinen_karttataso.setOpacity(lapinakyvyys/100); 
			}, {
			size: "200px",
			position:"topleft",
			min:0,
			max:100,
			step:10,
			value:100,
			title:"Kartan läpinäkyvyys / Kartans genomskinlighet",
			logo:"<i class='fa fa-adjust'></i>",
			showValue:true
		}).addTo(karttakomponentti);
		if(L.Browser.touch) {
			$(".leaflet-control-slider-toggle").css({
				"width":"30px",
				"height":"30px",
				"line-height":"30px",
			});
		}
		else {
			$(".leaflet-control-slider-toggle").css({
				"width":"26px",
				"height":"26px",
				"line-height":"26px",
			});
			$(".leaflet-control-slider").css({
				"border":"none",
			});
		}
		
		L.control.zoom({zoomInTitle:"Lähennä / Zooma in", zoomOutTitle:"Loitonna / Zooma ut"}).addTo(karttakomponentti);
		L.control.locate({
			flyTo: true,
			locateOptions: {
				enableHighAccuracy: true
			},
			strings: {
				title:"Missä olen / Var är jag",
				metersUnit:"m",
				popup:"<b>{coordinates}</b></br> Olet {distance} {unit} tästä pisteestä / Du är {distance} {unit} från detta punkt",
				outsideMapBoundsMsg:"Olet kartan rajojen ulkopuolella / Du är utanför kartans gränser"
			},
			onLocationError: function(paikannusvirhe,ohjain) {
				if(paikannusvirhe.code == 1) {
					luo_ilmoitusviesti("virhe","Ei oikeuksia käyttää paikannusta. Inga rättigheter att använda positionering");
				}
				else if(paikannusvirhe.code == 2) {
					luo_ilmoitusviesti("virhe","Sijaintivirhe. Positionsfel");
				}
				else {
					luo_ilmoitusviesti("virhe","Sijaintitietoja ei löytnyt. Ingen positionsinformation hittades");
				}
			}
		}).addTo(karttakomponentti);
		var tulostusPainike = $(
			"<div class='leaflet-control-print-button leaflet-control leaflet-bar'>"
			+ "<a href='#' title='Tulosta / Skriv ut'><i class='fa fa-print'></i></a>"
		);
		$(".leaflet-top.leaflet-left").append(tulostusPainike);
		
		window.onbeforeprint = function() {
			$("#karttavalikko").hide();
			$(".leaflet-control").hide();
			$(".leaflet-control-scale").show();
		};
		
		window.onafterprint = function() {
			$("#karttavalikko").show();
			$(".leaflet-control").show();
			$(".leaflet-control-weather").hide();
		};
		
		var tulostusTapahtuma = window.matchMedia("print");
		if(tulostusTapahtuma.addEventListener) {
			tulostusTapahtuma.addEventListener("change",function(tapahtuma) {
				if(tapahtuma.matches) {
					$("#karttavalikko").hide();
					$(".leaflet-control").hide();
					$(".leaflet-control-scale").show();
				}
				else {
					$("#karttavalikko").show();
					$(".leaflet-control").show();
					$(".leaflet-control-weather").hide();
				}
			});
		}
		else if(tulostusTapahtuma.attachEvent) {
			tulostusTapahtuma.attachEvent("change",function(tapahtuma) {
				if(tapahtuma.matches) {
					$("#karttavalikko").hide();
					$(".leaflet-control").hide();
					$(".leaflet-control-scale").show();
				}
				else {
					$("#karttavalikko").show();
					$(".leaflet-control").show();
					$(".leaflet-control-weather").hide();
				}
			});
		}
		
		L.DomEvent.disableClickPropagation($(".leaflet-control-print-button")[0]);
		L.DomEvent.disableClickPropagation($(".leaflet-control-print-button a")[0]);
		$(".leaflet-control-print-button a").click(function() {
			window.print();
		});
		
		L.control.polylineMeasure({position:"topleft", imperial:false}).addTo(karttakomponentti);
		var saaPainike = $(
			"<div class='leaflet-control-weather-button leaflet-control leaflet-bar'>"
			+ "<a href='#' title='Sää / Väder'><i class='fa fa-sun-o'></i></a>"
		);
		$(".leaflet-top.leaflet-left").append(saaPainike);
		L.DomEvent.disableClickPropagation($(".leaflet-control-weather-button")[0]);
		L.DomEvent.disableClickPropagation($(".leaflet-control-weather-button a")[0]);
		$(".leaflet-control-weather-button a").click(function() {
			if($(".leaflet-control-weather").css("display") == "none") {
				$(".leaflet-control-weather").show();
			}
			else {
				$(".leaflet-control-weather").hide();
			}
		})
		L.control.weather({lang:"fi", units:"metric", cityid:"651951", appid:"e565305875183227d1923fda2a77e904"}).addTo(karttakomponentti);
		$(".leaflet-control-weather").hide();
		L.control.scale({position:"bottomright", imperial:false}).addTo(karttakomponentti);
		$(".leaflet-control-scale").css({"clear":"none"});
		L.control.mousePosition({position:"bottomright",emptystring:"Ei saatavilla / Otillgänglig"}).addTo(karttakomponentti);
		$(".leaflet-control-mouseposition").css({"clear":"none"});
		karttaruutu = L.control.dialog({initOpen:false, size:[550,75], anchor:[5,450]}).addTo(karttakomponentti);
		karttavalikko = L.control.sidebar("karttavalikko").addTo(karttakomponentti);
		karttavalikko.on("closing",function() {
			$(".logo_kuvake").hide();
		});
		karttavalikko.on("opening",function() {
			$(".logo_kuvake").show();
		});
		$(".sidebar-tabs").css({"top":"100px"});
		$(".sidebar-content").css({"top":"100px"});

		karttalapinakyvyys.setValue(60);
		nykyinen_karttataso.setOpacity(60/100); 
		
		karttakomponentti.on("baselayerchange", function(tapahtuma) {
			if(tapahtuma.layer.options.layers == "Opaskartta") {
				karttalapinakyvyys.setValue(60);
				nykyinen_karttataso = tapahtuma.layer;
				nykyinen_karttataso.setOpacity(60/100); 
			}
			else {
				karttalapinakyvyys.setValue(100);
				nykyinen_karttataso = tapahtuma.layer;
				nykyinen_karttataso.setOpacity(1);
			}	
		});
	
		karttakomponentti.on("dialog:closed",function() { 
			
		});
		
		var karttakohde_piste = L.icon({
			iconUrl: "css/images/mapmarker.png",
			iconSize: [40,40],
			iconAnchor: [20,39]
		});
		
		var kategoria_tiedot = kartta_kohde_tiedot[0].kategoria_tiedot;
		var kohde_tiedot = kartta_kohde_tiedot[0].kohde_tiedot;
		
		var karttavalikko_kategoriat = [];
		for(var i = 0; i < kategoria_tiedot.length; i++)
		{
			var karttavalikko_kategoria_nakyvyys = $("<i class='karttavalikko_kategoria_nakyvyys fa fa-plus'></i>");
			
			var karttavalikko_kategoria = $("<div id='karttavalikko_kategoria_" + kategoria_tiedot[i].kategoria_id + "' class='karttavalikko_kategoria'>"
				+ "<span class='karttavalikko_kategoria_teksti'>" + kategoria_tiedot[i].nimi + "</span>"
				+ "<div class='karttavalikko_kohteet'></div>"
				+ "<div class='karttavalikko_alakategoriat'></div>"
			+ "</div>");
			
			karttavalikko_kategoria.prepend(karttavalikko_kategoria_nakyvyys);
			
			karttavalikko_kategoria_nakyvyys.click(function(painiketapahtuma) {
				painiketapahtuma.stopPropagation();
				if($(this).hasClass("fa-plus")) {
					$(this).removeClass("fa-plus");
					$(this).addClass("fa-minus");
					
					$(this).closest(".karttavalikko_kategoria").children(".karttavalikko_alakategoriat").show();
					$(this).closest(".karttavalikko_kategoria").children(".karttavalikko_kohteet").show();
				}
				else {
					$(this).removeClass("fa-minus");
					$(this).addClass("fa-plus");
					
					$(this).closest(".karttavalikko_kategoria").find(".karttavalikko_alakategoriat").hide();
					$(this).closest(".karttavalikko_kategoria").find(".karttavalikko_kohteet").hide();
					$(this).closest(".karttavalikko_kategoria").find(".fa-minus").removeClass("fa-minus").addClass("fa-plus");
				}
			});
			
			$('#karttavalikko_kategoriakohteet').append(karttavalikko_kategoria);
			karttavalikko_kategoria.find(".karttavalikko_alakategoriat").hide();
			karttavalikko_kategoria.find(".karttavalikko_kohteet").hide();
			
			karttavalikko_kategoriat.push(karttavalikko_kategoria);
		}

		for(var i = 0; i < kategoria_tiedot.length; i++)
		{
			if(kategoria_tiedot[i].taso_id != 0) { 
				$('#karttavalikko_kategoria_' + kategoria_tiedot[i].kategoria_id).appendTo($('#karttavalikko_kategoria_' + kategoria_tiedot[i].taso_id + " > .karttavalikko_alakategoriat"));
				
				if(screen.width >= 768) {
					var taso_siirto = $('#karttavalikko_kategoria_' + kategoria_tiedot[i].kategoria_id).parents(".karttavalikko_kategoria").length * 10;
					$('#karttavalikko_kategoria_' + kategoria_tiedot[i].kategoria_id).css({"margin-left":taso_siirto + "px"});
				}
			}
		}
		
		for(var i = 0; i < kohde_tiedot.length; i++)
		{
			var karttavalikko_kohde_nakyvyys = $("<i class='karttavalikko_kohde_nakyvyys fa fa-square-o'></i>");
			var karttavalikko_kohde_tila_teksti = kohde_tiedot[i].tila_nimi;
			if(kohde_tiedot[i].huoltotapahtuma.length > 0) {
				karttavalikko_kohde_tila_teksti += ", " + kohde_tiedot[i].huoltotapahtuma[0].aikaleima;
			}
			
			var karttavalikko_kohde = $(
				"<div id='karttavalikko_kohde_" + kohde_tiedot[i].kohde_id + "' class='karttavalikko_kohde'>"
					+ "<span class='karttavalikko_kohde_teksti'>" + kohde_tiedot[i].nimi + "</span>"
					+ "<i class='karttavalikko_kohde_tila fa fa-square' style='color:rgb(" + kohde_tiedot[i].tila_vari + ")' title='" + karttavalikko_kohde_tila_teksti + "'></i>"
					+ "<div class='karttavalikko_kohde_lisatiedot'>"
						+ "<span class='karttavalikko_kohde_lisatieto_teksti'>" + karttavalikko_kohde_tila_teksti + "</span>"
						+ "<span class='karttavalikko_kohde_lisatieto_teksti'>" + kohde_tiedot[i].kuvaus + "</span>"
						+ "<div class='karttavalikko_kohde_attribuutit'></div>"
					+ "</div>"
				+ "</div>"
			);
			
			var kohde_attribuutit = kohde_tiedot[i].attribuutit;
			for(var j = 0; j < kohde_attribuutit.length; j++)
			{
				if(kohde_attribuutit[j].tyyppi == 1) {
					karttavalikko_kohde.children(".karttavalikko_kohde_lisatiedot").children(".karttavalikko_kohde_attribuutit").append(
						"<div class='karttavalikko_kohde_attribuutti'>"
							+ "<span class='karttavalikko_kohde_attribuutti_nimi'>" + kohde_attribuutit[j].nimi + ":</span>"
							+ "<span class='karttavalikko_kohde_attribuutti_arvo'>" + kohde_attribuutit[j].arvo + "</span>"
						+ "</div>"
					);
				}
				
				if(kohde_attribuutit[j].tyyppi == 2 || kohde_attribuutit[j].tyyppi == 3) {
					karttavalikko_kohde.children(".karttavalikko_kohde_lisatiedot").children(".karttavalikko_kohde_attribuutit").append(
						"<div class='karttavalikko_kohde_attribuutti'>"
							+ "<a class='karttavalikko_kohde_attribuutti_linkki' href='" + kohde_attribuutit[j].arvo + "' target='_blank'>" + kohde_attribuutit[j].nimi + "</a>"
						+ "</div>"
					);
				}
				/*
				if(kohde_attribuutit[j].tyyppi == 3) {
					karttavalikko_kohde.children(".karttavalikko_kohde_lisatiedot").children(".karttavalikko_kohde_attribuutit").append(
						"<div class='karttavalikko_kohde_attribuutti'>"
							+ "<a class='karttavalikko_kohde_attribuutti_linkki' href='" + kohde_attribuutit[j].arvo + "' target='_blank'>" + kohde_attribuutit[j].nimi + "</a>" 
						+ "</div>"
					);
				}
				*/
			}
			
			karttavalikko_kohde.data("kohde_id",kohde_tiedot[i].kohde_id);
			karttavalikko_kohde.data("aineistotunnus",kohde_tiedot[i].aineistotunnus);
			karttavalikko_kohde.data("aineisto",kohde_tiedot[i].aineisto);
			karttavalikko_kohde.data("attribuutit",kohde_tiedot[i].attribuutit);
			karttavalikko_kohde.data("kuvaus",kohde_tiedot[i].kuvaus);
			karttavalikko_kohde.data("vari",kohde_tiedot[i].tila_vari);
			karttavalikko_kohde.data("tila",karttavalikko_kohde_tila_teksti);
			
			karttavalikko_kohde.prepend(karttavalikko_kohde_nakyvyys);
			
			$("#karttavalikko_kategoria_" + kohde_tiedot[i].kategoria_id).children(".karttavalikko_kohteet").append(karttavalikko_kohde);
			
			karttavalikko_kohde.children(".karttavalikko_kohde_lisatiedot").hide();

			karttavalikko_kohde.children(".karttavalikko_kohde_teksti").click(function() {
				if($(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_lisatiedot").css("display") == "none") {
					$(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_lisatiedot").show();
				}
				else {
					$(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_lisatiedot").hide();
				}
			});
			
			karttavalikko_kohde_nakyvyys.click(function(painiketapahtuma) {
				painiketapahtuma.stopPropagation();
				var kohde = $(this).closest(".karttavalikko_kohde");
				var kohde_id = kohde.data("kohde_id");
				var kohde_aineisto = kohde.data("aineisto");
				var kohde_kuvaus = kohde.data("kuvaus");
				var kohde_nimi = $(this).closest(".karttavalikko_kohde").children(".karttavalikko_kohde_teksti").html();
				var kohde_vari = kohde.data("vari");
				var kohde_tila = "";
				if(kohde.data("tila") != "") {
					kohde_tila = kohde.data("tila");
				}
				
				var kohde_attribuutti_tiedot = kohde.data("attribuutit");
				var kohde_attribuutti_lista = "";
				
				for(var j = 0; j < kohde_attribuutti_tiedot.length; j++)
				{
					if(j == 0) {
						kohde_attribuutti_lista += "<ul class='karttakohde_ruutu_lista'>";
					}
					
					if(kohde_attribuutti_tiedot[j].tyyppi == 1) {
						kohde_attribuutti_lista += "<li>" + kohde_attribuutti_tiedot[j].nimi + ": " + kohde_attribuutti_tiedot[j].arvo + "</li>"
					}
					else if(kohde_attribuutti_tiedot[j].tyyppi == 2) {
						kohde_attribuutti_lista += "<li class='karttavalikko_ei_lista_merkintaa'><a href='" + kohde_attribuutti_tiedot[j].arvo + "' target='_blank'>" + kohde_attribuutti_tiedot[j].nimi + "<a></li>";
					}
					else if(kohde_attribuutti_tiedot[j].tyyppi == 3) {
						kohde_attribuutti_lista += "<li class='karttavalikko_ei_lista_merkintaa'><img class='karttavalikko_kohde_attribuutti_kuva' src='" + kohde_attribuutti_tiedot[j].arvo + "' onclick='nayta_kuva($(this))' /></li>";
					}
					
					if(j == kohde_attribuutti_tiedot.length - 1) {
						kohde_attribuutti_lista += "</ul>";
					}
				}
				
				if($(this).hasClass("fa-check-square-o")) {
					$(this).removeClass("fa-check-square-o");
					$(this).addClass("fa-square-o");
					if(kohde_id in karttaaineisto) {
						var kartta_kohde_aineisto = karttaaineisto[kohde_id];
						for(var j = 0; j < kartta_kohde_aineisto.length; j++)
						{
							karttaaineistotaso.removeLayer(kartta_kohde_aineisto[j]);
						}
					}
				}
				else {
					$(this).removeClass("fa-square-o");
					$(this).addClass("fa-check-square-o");
					
					if(screen.width < 768) {
						karttavalikko.close();
					} 
					
					if(kohde_aineisto.length == 1) {
						var kartta_kohde = L.marker([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste], { 
							icon: L.BeautifyIcon.icon({
								icon: 'circle',
								iconShape: 'marker',
								textColor: "#fff",
								borderColor: "rgb(" + kohde_vari + ")",
								backgroundColor: "rgb(" + kohde_vari + ")"
							})
						});
						kartta_kohde.bindPopup("<b>" + kohde_nimi + "</b></br>" + kohde_kuvaus + "</br>" + kohde_tila + "</br>" + kohde_attribuutti_lista);
						karttaaineistotaso.addLayer(kartta_kohde);
						karttaaineisto[kohde_id] = [kartta_kohde];
						karttakomponentti.setView([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste]);
						kartta_kohde.openPopup();
					}
					else if(kohde_aineisto.length > 1) {
						var pisteet = [];
						for(var j = 0; j < kohde_aineisto.length; j++)
						{
							pisteet.push([kohde_aineisto[j].leveysaste,kohde_aineisto[j].pituusaste]);
						}
						var kartta_kohde_alku = L.marker([kohde_aineisto[0].leveysaste,kohde_aineisto[0].pituusaste], {
							icon: karttakohde_piste
							/*L.BeautifyIcon.icon({
								icon: 'flag',
								iconShape: 'marker',
								textColor: "green"
								
							})
							*/
						});
						var kartta_kohde_loppu = L.marker([kohde_aineisto[kohde_aineisto.length - 1].leveysaste,kohde_aineisto[kohde_aineisto.length - 1].pituusaste], {
							icon: karttakohde_piste
							/*L.BeautifyIcon.icon({
								icon: 'flag-checkered',
								iconShape: 'marker',
								textColor: "red"
							})
							*/
						});
						var kartta_kohde = L.polyline(pisteet, { "color":"rgb(" + kohde_vari + ")" });
						kartta_kohde.bindPopup("<b>" + kohde_nimi + "</b></br>" + kohde_kuvaus + "</br>" + kohde_tila + "</br>" + kohde_attribuutti_lista);
						karttaaineistotaso.addLayer(kartta_kohde);
						karttaaineistotaso.addLayer(kartta_kohde_alku);
						karttaaineistotaso.addLayer(kartta_kohde_loppu);
						karttaaineisto[kohde_id] = [kartta_kohde,kartta_kohde_alku,kartta_kohde_loppu];
						karttakomponentti.setView(kartta_kohde.getBounds().getCenter());
						//karttakomponentti.fitBounds(kartta_kohde.getBounds());
						kartta_kohde.openPopup(kartta_kohde.getBounds().getCenter());
					}
				}
			});
		}
		
		karttavalikko.open("karttavalikko_kohdevalikko");
		aseta_ohje_kieli("fi");
	});
}

function hae_tila_valinnat()
{
	var toiminnon_siirto = $.Deferred();
	
	tila_valinnat = [];	

	$.ajax({
		method: "POST",
		url: "php/hae_tila_valinnat.php",
		data: {},
		dataType: "json",
		error: function(pyynto,tila,virhe) {
			toiminnon_siirto.reject();
		},
		success: function(palvelinvastaus,tila,pyynto) {
			var vastaustila = palvelinvastaus.tila;
			var tiedot = palvelinvastaus.rivitiedot;
			
			if(vastaustila.virhe == 1) {
				luo_ilmoitusviesti("virhe",vastaustila.viesti);
				return;
			}
			
			tila_valinnat = [];
			for(var i = 0; i < tiedot.length; i++)
			{
				tila_valinnat.push({"id":tiedot[i].tila_id,"nimi":tiedot[i].nimi,"vari":tiedot[i].vari});
			}
			
			toiminnon_siirto.resolve();
		}
	});

	return toiminnon_siirto;
}

function hae_kartta_kohde_tiedot() 
{
	var toiminnon_siirto = $.Deferred();

	$.ajax({
		method: "POST",
		url: "php/hae_kartta_kohde_tiedot.php",
		data: {},
		dataType: "json",
		error: function(pyynto,tila,virhe) {
			toiminnon_siirto.reject();
		},
		success: function(palvelinvastaus,tila,pyynto) {
			var vastaustila = palvelinvastaus.tila;
			var tiedot = palvelinvastaus.rivitiedot;

			if(vastaustila.virhe == 1) {
				luo_ilmoitusviesti("virhe",vastaustila.viesti);
				return;
			}

			toiminnon_siirto.resolve(tiedot);
		}
	});

	return toiminnon_siirto;
}

function laheta_viesti()
{
	var toiminnon_siirto = $.Deferred();

	var v_aihe = "";
	var v_sisalto = "";
	var v_lahettaja = "";
	var v_aikaleima = "";

	v_aihe = tarkista_muuttuja($(".karttavalikko_viestinta_aihe").val(),"ei_tyhjä");
	v_sisalto = tarkista_muuttuja($(".karttavalikko_viestinta_sisalto").val(),"ei_tyhjä");
	v_lahettaja = tarkista_muuttuja($(".karttavalikko_viestinta_lahettaja").val(),"ei_tyhjä");
	v_aikaleima = palautaAikaleima();
	
	if(v_aihe == "") {
		$(".karttavalikko_viestinta_aihe").addClass("karttavalikko_kenttavirhe");
	}
	
	if(v_sisalto == "") {
		$(".karttavalikko_viestinta_sisalto").addClass("karttavalikko_kenttavirhe");
	}

	if(v_aihe != "" && v_sisalto != "" && v_aikaleima != "") {
		$.ajax({
			method: "POST",
			url: "php/laheta_viesti.php",
			data: { aihe:v_aihe, sisalto:v_sisalto, lahettaja:v_lahettaja, aikaleima:v_aikaleima },
			dataType: "json",
			error: function(pyynto,tila,virhe) {
				toiminnon_siirto.reject();
			},
			success: function(palvelinvastaus,tila,pyynto) {
				var vastaustila = palvelinvastaus.tila;
				var tiedot = palvelinvastaus.tiedot;
				if(vastaustila.virhe == 1) {
					luo_ilmoitusviesti("virhe",vastaustila.viesti);
					return;
				}
				
				$(".karttavalikko_viestinta_aihe").val("");
				$(".karttavalikko_viestinta_sisalto").val("");
				$(".karttavalikko_viestinta_lahettaja").val("");
				luo_ilmoitusviesti("ilmoitus","Viesti lähetetty");
				toiminnon_siirto.resolve();
			}
		});
	}
	else {
		toiminnon_siirto.reject();
	}

	return toiminnon_siirto;
}

function aseta_ohje_kieli(kieli)
{
	switch(kieli)
	{
		case "fi":
			$(".karttavalikko_ohjeet_teksti").html(
				"<span class='karttavalikko_ohje_otsikko'>Kartan tasot</span>"
				+ "<span class='karttavalikko_ohje_teksti'>Kartan tasoa voidaan vaihtaa <img class='karttavalikko_ohje_kuvake' src='leaflet/css/images/layers.png' /> ikonista. Tasoista löytyy opaskartta, ilmakuva sekä peruskartta.</span>"
				+ "<span class='karttavalikko_ohje_otsikko'>Kartan läpinäkyvyys</span>"
				+ "<span class='karttavalikko_ohje_teksti'>Kartan läpinäkyvyyttä voidaan säätää valitsemmalla <i class='fa fa-adjust'></i> ja liuttamalla hiirellä liukukytkimessä. Kartan läpinäkyvyys tummenee tai vaaleenee.</span>"
				+ "<span class='karttavalikko_ohje_otsikko'>Kartan zoomaus</span>"
				+ "<span class='karttavalikko_ohje_teksti'>Karttaa voidaan zoomata joko kartan + / - painikkeella tai hiiren rullalla tai painamalla Shift-näppäin pohjaan ja valitsemalla hiirellä näytettävä alue kartalla</span>"
				+ "<span class='karttavalikko_ohje_otsikko'>Kartan siirtäminen</span>"
				+ "<span class='karttavalikko_ohje_teksti'>Karttaa voidaan siirtää (näkymä toiseen kohtaan) joko nuolipainikkeilla tai painamalla hiiren vasen painike pohjaan ja siirtämällä hiirellä.</span>"
				+ "<span class='karttavalikko_ohje_otsikko'>Paikannus</span>"
				+ "<span class='karttavalikko_ohje_teksti'>Paikannus kytketään päälle <i class='fa fa-map-marker'></i> painikkeesta. Paikannus tarvitsee oikeudet laitteelta/selaimelta jotta sijainti voidaan hakea.</span>"
				+ "<span class='karttavalikko_ohje_otsikko'>Tulostus</span>"
				+ "<span class='karttavalikko_ohje_teksti'><i class='fa fa-print'></i> tulostaa karttanäkymän. Huomioi tulostusasetukset. Voit myös valita tulostuksen esikatselun selaimen valikosta.</span>"
				+ "<span class='karttavalikko_ohje_otsikko'>Mittaus</span>"
				+ "<span class='karttavalikko_ohje_teksti'><i class='fa fa-arrows-h'></i> siirrytään mittaustilaan, jolloin hiirtä painamalla karttaan muodostuu piste. Painamalla karttassa seuraavaan kohtaa, mitataan näiden pisteiden välinen etäisyys ja se esitetään käyttäjälle. Mittaus lopetetaan painamalla viimeisintä pistettä.</span>"
				+ "<span class='karttavalikko_ohje_otsikko'>Sää</span>"
				+ "<span class='karttavalikko_ohje_teksti'>Säätiedot saa näkyviin <i class='fa fa-sun-o'></i> painikkeesta.</span>"
			);
		break;
		
		case "se":
			$(".karttavalikko_ohjeet_teksti").html(
				"<span class='karttavalikko_ohje_otsikko'>Samma på svenska</span>"
			);
		break;
	}
	
}

function nayta_kuva(kuva)
{
	window.open(kuva.prop("src"));
}

function luo_ilmoitusviesti(tyyppi,teksti)
{
	var ilmoituskuvake = "";
	var ilmoitustaustavari = "";
	var ilmoituskesto = 0;
	
	switch(tyyppi)
	{
		case "ilmoitus":
			ilmoitustaustavari = "#b4ff94";
			ilmoituskuvake = "fa-info-circle";
			ilmoituskesto = 5000;
		break;
		
		case "virhe":
			ilmoitustaustavari = "#d9534f";
			ilmoituskuvake = "fa-warning";
			ilmoituskesto = 4000;
		break;
		
		default:
			ilmoitustaustavari = "#ffffff";
			ilmoituskuvake = "fa-info";
			ilmoituskesto = 3000;
	}
	
	var ilmoitusviesti = $(
		"<div class='ilmoitusviesti' style='display:none; background-color:" + ilmoitustaustavari + ";'>"
			+ "<i class='ilmoitusviesti_kuvake fa " + ilmoituskuvake + "'></i>"
			+ "<span class='ilmoitusviestiteksti'>" + teksti + "</span>"
		+ "</div>"
	);

	if($(".karttanakyma .ilmoitusviesti").length > 0) {
		var edellinen_viesti_korkeus = $(".karttanakyma .ilmoitusviesti:first").outerHeight() + 5;
		var edellinen_viesti_positio = parseFloat($(".karttanakyma .ilmoitusviesti:first").css("bottom"));
		$(".karttanakyma .ilmoitusviesti:first").before(ilmoitusviesti);
		$(ilmoitusviesti).css({"bottom":edellinen_viesti_positio + edellinen_viesti_korkeus});
	}
	else {
		$(".karttanakyma").append(ilmoitusviesti);
		$(ilmoitusviesti).css({"bottom":"10px"});
	}

	$(ilmoitusviesti).fadeIn(1000);
	$(ilmoitusviesti).click(function() {
		$(this).fadeOut(1000,function() {
			var viesti_korkeus = $(this).outerHeight() + 5;
			$(this).prevAll(".ilmoitusviesti").each(function() {
				var viesti_positio = parseFloat($(this).css("bottom"));
				viesti_positio -= viesti_korkeus;
				$(this).css({"bottom":viesti_positio});
			});
			$(this).remove();
		});
	});
	
	if(ilmoituskesto > 0) {
		setTimeout(function() {
			if($(".karttanakyma .ilmoitusviesti").index($(ilmoitusviesti)) != -1) {
				$(ilmoitusviesti).fadeOut(1000,function() {
					var viesti_korkeus = $(this).outerHeight() + 5;
					$(this).prevAll(".ilmoitusviesti").each(function() {
						var viesti_positio = parseFloat($(this).css("bottom"));
						viesti_positio -= viesti_korkeus;
						$(this).css({"bottom":viesti_positio});
					});
					$(this).remove();
				});
			}
		}, ilmoituskesto);
	}
}

function palautaAikaleima(viikonpaiva)
{
	var tanaan = new Date();
	var tunnit = tanaan.getHours();
	var minuutit = tanaan.getMinutes();
	var sekunnit = tanaan.getSeconds();
	var paiva = tanaan.getDate();
	var kuukausi = tanaan.getMonth() + 1;
	var vuosi = tanaan.getFullYear();
	
	if(tunnit <= 9) { tunnit = '0' + tunnit; }
	if(minuutit <= 9) { minuutit = '0' + minuutit; }
	if(sekunnit <= 9) { sekunnit = '0' + sekunnit; }
	if(paiva <= 9) { paiva = '0' + paiva; }
	if(kuukausi <= 9) { kuukausi = '0' + kuukausi; }
	
	return paiva + "." + kuukausi + "." + vuosi + " " + tunnit + ":" + minuutit + ":" + sekunnit;
}

function tarkista_muuttuja(arvo,tyyppi)
{
	var tarkistettu_arvo = "";
	
	switch(tyyppi)
	{
		case "ei_tyhjä":
			if(arvo.length > 0) {
				tarkistettu_arvo = arvo;
			}
		break;
		
		case "numero":
			if(arvo.match(/^\d+$/)) {
				tarkistettu_arvo = arvo;
			}
		break;
		
		case "sähköposti":
			if(arvo.match(/@{1}/)) {
				tarkistettu_arvo = arvo;
			}
		break;
		
		case "teksti":
			tarkistettu_arvo = arvo;
		break;
		
		case "puhelin":
			tarkistettu_arvo = arvo;
		break;
		
		case "pvm":
			tarkistettu_arvo = arvo;
		break;
		
		default: tarkistettu_arvo = arvo;
	}
	
	return tarkistettu_arvo;
}